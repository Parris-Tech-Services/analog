import React, { useState } from 'react';
import { Swords, User, Zap, AlertTriangle, Shield, CheckCircle2, Sparkles, HeartHandshake } from 'lucide-react';
import { LoreEntry } from '../types';

interface CampaignViewProps {
  entries: LoreEntry[];
  onSelectEntry: (entry: LoreEntry) => void;
}

export const CampaignView: React.FC<CampaignViewProps> = ({
  entries,
  onSelectEntry,
}) => {
  const [selectedChoice, setSelectedChoice] = useState<string | null>('expose');

  const choices = [
    {
      id: 'expose',
      title: '1. Expose the Grey Hour Coverup (Archivist Path)',
      faction: 'The Archivists',
      summary: 'Broadcast Node 04\'s unredacted logs across every Midstack clinic and school terminal.',
      consequences: [
        'Concord Five legitimacy shatters instantly; mass strikes shut down Thorne transit lifts.',
        'Breakers launch emergency martial law; Enforcer sibling is ordered to execute Weaver leaders.',
        'Water purification lines in The Works are left unmonitored during riots, exacerbating the water crisis.',
      ],
      waterImpact: -5.0,
      stabilityImpact: 'Cataclysmic Fracture',
    },
    {
      id: 'cradle',
      title: '2. Preserve & Awaken the 40,000 Neural Scans (Cradle Path)',
      faction: 'The Cradle Faithful',
      summary: 'Air-gap Node 04 in the deep subterranean Relic Vault to protect the pre-Blight neural scans as living human souls.',
      consequences: [
        'Blocks weaponization of the Blight decision model by both Breakers and Archivists.',
        'Sparks open conflict with The Cut, who view keeping the digital scans as heresy.',
        'Priya\'s Enforcer sibling tracks the hardwire signal, setting up a face-to-face confrontation at the Relic Vault.',
      ],
      waterImpact: 0,
      stabilityImpact: 'Sub-Tier Schism',
    },
    {
      id: 'cut',
      title: '3. Incinerate Node 04 & Burn the Spire Grid (The Cut Path)',
      faction: 'The Cut',
      summary: 'Use high-intensity thermite charges to destroy Node 04 and detonate EMPs across Midstack distribution hubs.',
      consequences: [
        'Destroys the Blight predictive model forever.',
        'Collapses hospital life-support systems in Sector 22-B, causing massive civilian casualties.',
        'Priya\'s sibling is permanently incapacitated during the EMP blast.',
      ],
      waterImpact: -10.0,
      stabilityImpact: 'Total Dark Age',
    },
    {
      id: 'bargain',
      title: '4. Bargain with the Sibling & Negotiate Blight Ceasefire',
      faction: 'Priya & Enforcer Sibling',
      summary: 'Priya contacts her sibling directly on a secure analog line, offering the Blight decision model in exchange for clean water and sibling amnesty.',
      consequences: [
        'Secures a temporary clean water pipeline to Haven-04 and Sector 22-B.',
        'Weaver Archivists brand Priya a traitor to the resistance.',
        'Halcyon Systems uses the Blight decision model to solidify total spire supremacy.',
      ],
      waterImpact: +15.0,
      stabilityImpact: 'Fragile Ceasefire',
    },
  ];

  const currentChoice = choices.find((c) => c.id === selectedChoice) || choices[0];

  return (
    <div className="space-y-6 font-mono">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-rose-500/10 border border-rose-500/30 text-rose-400 font-mono text-xs font-bold">
              NARRATIVE CAMPAIGN ENGINE
            </span>
            <span className="text-xs font-mono text-slate-500">Node 04 Decision Sandbox</span>
          </div>
          <h2 className="text-xl md:text-2xl font-mono font-bold text-white tracking-tight mt-1">
            Priya Osei & The Node 04 Dilemmas
          </h2>
        </div>
      </div>

      {/* Characters Dossier Header */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl border border-emerald-500/30 bg-slate-900/90 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
              <User className="w-4 h-4" /> PRIYA OSEI (WEAVER SPLICE-TECH)
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">SUB-TIERS</span>
          </div>
          <p className="text-xs text-slate-300 font-sans leading-relaxed">
            Shift-nurse in Midstack Clinic 04 and covert Weaver splice-tech. Discovered Node 04 with Haven-04 Archivists while searching for salvaged medical components.
          </p>
        </div>

        <div className="p-4 rounded-xl border border-sky-500/30 bg-slate-900/90 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
              <Shield className="w-4 h-4" /> THE ENFORCER SIBLING
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-sky-500/20 text-sky-300">HALCYON CROWN</span>
          </div>
          <p className="text-xs text-slate-300 font-sans leading-relaxed">
            Priya's estranged sibling, taken into corporate wardship as a child. Rising Halcyon enforcer ordered to secure or destroy Node 04 at all costs.
          </p>
        </div>
      </div>

      {/* The 4 Dilemmas */}
      <div className="space-y-4">
        <div className="text-xs font-bold text-slate-400">CHOOSE NARRATIVE PATH FOR NODE 04:</div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {choices.map((c) => {
            const isSelected = selectedChoice === c.id;
            return (
              <div
                key={c.id}
                onClick={() => setSelectedChoice(c.id)}
                className={`p-4 rounded-xl border transition cursor-pointer space-y-2 ${
                  isSelected
                    ? 'bg-slate-900 border-rose-500 text-rose-300 ring-1 ring-rose-500/40 shadow-xl'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div className="font-bold text-sm text-white flex items-center justify-between">
                  <span>{c.title}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                    {c.faction}
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-sans">{c.summary}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Simulation Result Box */}
      {currentChoice && (
        <div className="p-5 rounded-xl border border-rose-500/40 bg-slate-900/90 space-y-3 shadow-2xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
              <Zap className="w-4 h-4" /> CAMPAIGN SIMULATION RESULTS: {currentChoice.title}
            </span>
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-200">
              STABILITY: {currentChoice.stabilityImpact}
            </span>
          </div>

          <div className="space-y-2 text-xs font-sans text-slate-200">
            <span className="font-mono font-bold text-amber-400">RIPPLE CONSEQUENCES:</span>
            <ul className="space-y-1.5 list-disc list-inside">
              {currentChoice.consequences.map((cons, idx) => (
                <li key={idx} className="leading-relaxed">{cons}</li>
              ))}
            </ul>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
            <span>Clean Water Capacity Impact:</span>
            <span className={`font-bold ${currentChoice.waterImpact >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {currentChoice.waterImpact >= 0 ? `+${currentChoice.waterImpact}%` : `${currentChoice.waterImpact}%`}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
