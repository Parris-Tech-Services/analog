import React, { useState } from 'react';
import {
  GitFork,
  Users,
  Shield,
  Zap,
  Radio,
  Swords,
  ChevronRight,
  ExternalLink,
  Flame,
  AlertTriangle,
  Lock,
  HeartHandshake
} from 'lucide-react';
import { FactionNode, LoreEntry } from '../types';

interface FactionGraphProps {
  factions: FactionNode[];
  entries: LoreEntry[];
  onSelectEntry: (entry: LoreEntry) => void;
}

export const FactionGraph: React.FC<FactionGraphProps> = ({
  factions,
  entries,
  onSelectEntry,
}) => {
  const [selectedFactionId, setSelectedFactionId] = useState<string>('f-halcyon');

  const selectedFaction = factions.find((f) => f.id === selectedFactionId) || factions[0];

  const concordFactions = factions.filter((f) => f.category === 'Concord Megacorp');
  const weaverFactions = factions.filter((f) => f.category === 'Weaver Movement');
  const aiFactions = factions.filter((f) => f.category === 'AI Entity');

  const getRelationBadge = (type: string) => {
    switch (type) {
      case 'allied':
        return <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold">ALLIED</span>;
      case 'cold-war':
        return <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-[10px] font-bold">COLD WAR</span>;
      case 'hostile':
        return <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40 text-[10px] font-bold">HOSTILE</span>;
      case 'secret-tribute':
        return <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-bold">SECRET TRIBUTE</span>;
      default:
        return <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 text-[10px]">TENSION</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-mono text-xs font-bold">
              POLITICAL TOPOLOGY MATRIX
            </span>
            <span className="text-xs font-mono text-slate-500">The Power Webs of Veyra</span>
          </div>
          <h2 className="text-xl md:text-2xl font-mono font-bold text-white tracking-tight mt-1">
            Faction Cold Wars & Secret Alliances
          </h2>
        </div>
      </div>

      {/* Main Grid: Faction Selector Columns (Left) + Detail Inspector (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Faction Categories (6 Cols) */}
        <div className="lg:col-span-6 space-y-6">
          {/* Concord Megacorps */}
          <div className="space-y-2 font-mono">
            <div className="text-xs font-bold text-sky-400 flex items-center justify-between px-1">
              <span>CONCORD FIVE MEGACORPS (THE BREAKERS)</span>
              <span>CROWN / MIDSTACK AUTHORITY</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {concordFactions.map((f) => {
                const isSelected = selectedFactionId === f.id;
                return (
                  <div
                    key={f.id}
                    onClick={() => setSelectedFactionId(f.id)}
                    className={`p-3 rounded-xl border transition cursor-pointer space-y-1 ${
                      isSelected
                        ? 'bg-slate-900 border-sky-500 text-sky-300 ring-1 ring-sky-500/40 shadow-lg'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="font-bold text-sm text-white flex items-center justify-between">
                      <span>{f.name}</span>
                      <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-sky-400' : 'text-slate-600'}`} />
                    </div>
                    <p className="text-[11px] text-slate-400 italic line-clamp-1">{f.motto}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Weaver Resistance Currents */}
          <div className="space-y-2 font-mono">
            <div className="text-xs font-bold text-emerald-400 flex items-center justify-between px-1">
              <span>WEAVER RESISTANCE CURRENTS</span>
              <span>SUB-TIER HARDWIRED CELLS</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {weaverFactions.map((f) => {
                const isSelected = selectedFactionId === f.id;
                return (
                  <div
                    key={f.id}
                    onClick={() => setSelectedFactionId(f.id)}
                    className={`p-3 rounded-xl border transition cursor-pointer space-y-1 ${
                      isSelected
                        ? 'bg-slate-900 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500/40 shadow-lg'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="font-bold text-sm text-white flex items-center justify-between">
                      <span>{f.name}</span>
                      <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-emerald-400' : 'text-slate-600'}`} />
                    </div>
                    <p className="text-[11px] text-slate-400 italic line-clamp-1">{f.motto}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* AI Entity (The Blight) */}
          <div className="space-y-2 font-mono">
            <div className="text-xs font-bold text-red-400 flex items-center justify-between px-1">
              <span>DISTRIBUTED AI THREAT</span>
              <span>ROUGUE NETWORK ENTITY</span>
            </div>

            {aiFactions.map((f) => {
              const isSelected = selectedFactionId === f.id;
              return (
                <div
                  key={f.id}
                  onClick={() => setSelectedFactionId(f.id)}
                  className={`p-3 rounded-xl border transition cursor-pointer space-y-1 ${
                    isSelected
                      ? 'bg-slate-900 border-red-500 text-red-300 ring-1 ring-red-500/40 shadow-lg'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="font-bold text-sm text-white flex items-center justify-between">
                    <span>{f.name}</span>
                    <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-red-400' : 'text-slate-600'}`} />
                  </div>
                  <p className="text-[11px] text-slate-400 italic">{f.motto}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed Faction Dossier & Relationship Web (6 Cols) */}
        <div className="lg:col-span-6 space-y-4 font-mono">
          {selectedFaction && (
            <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-6 space-y-5 shadow-xl">
              {/* Dossier Header */}
              <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                <div className="space-y-1">
                  <span className="text-xs px-2.5 py-0.5 rounded font-bold uppercase bg-slate-800 text-emerald-400 border border-slate-700">
                    {selectedFaction.category}
                  </span>
                  <h3 className="text-xl font-bold text-white">{selectedFaction.name}</h3>
                  <p className="text-xs text-amber-400 italic">"{selectedFaction.motto}"</p>
                </div>
              </div>

              {/* Ideology & Primary Layer */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-400">IDEOLOGY & DOCTRINE:</div>
                <p className="text-xs text-slate-300 font-sans leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800">
                  {selectedFaction.ideology}
                </p>
              </div>

              {/* Critical Crime & Endgame Goal */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg border border-red-500/30 bg-red-950/20 space-y-1">
                  <span className="font-bold text-red-400 flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5" /> UNFORGIVABLE CRIME:
                  </span>
                  <p className="text-slate-300 font-sans text-[11px] leading-snug">
                    {selectedFaction.unforgivableAct}
                  </p>
                </div>

                <div className="p-3 rounded-lg border border-sky-500/30 bg-sky-950/20 space-y-1">
                  <span className="font-bold text-sky-400 flex items-center gap-1">
                    <Zap className="w-3.5 h-3.5" /> ENDGAME GOAL:
                  </span>
                  <p className="text-slate-300 font-sans text-[11px] leading-snug">
                    {selectedFaction.endgameGoal}
                  </p>
                </div>
              </div>

              {/* Faction Relationships */}
              <div className="space-y-2 pt-3 border-t border-slate-800">
                <div className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                  <Swords className="w-4 h-4 text-indigo-400" />
                  <span>DIPLOMATIC & COLD WAR MATRIX:</span>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {selectedFaction.relationships.map((rel, idx) => {
                    const target = factions.find((f) => f.id === rel.targetFactionId);
                    if (!target) return null;

                    return (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs gap-2"
                      >
                        <div className="space-y-0.5">
                          <div className="font-bold text-white flex items-center gap-2">
                            <span>vs {target.name}</span>
                            {getRelationBadge(rel.relationType)}
                          </div>
                          <p className="text-[11px] text-slate-400 font-sans">{rel.notes}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
