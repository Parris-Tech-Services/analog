import React, { useState, useEffect } from 'react';
import { X, Save, Plus, Tag, Link2, Sparkles } from 'lucide-react';
import { LoreEntry, LoreCategory, CanonStatus } from '../types';

interface EntryEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entry: Partial<LoreEntry>) => void;
  existingEntry?: LoreEntry | null;
  allEntries: LoreEntry[];
}

const CATEGORIES: LoreCategory[] = [
  'Factions',
  'Characters',
  'Locations',
  'Technology',
  'History',
  'Culture & Belief',
  'Resources & Economy',
  'The Blight',
  'Concepts',
];

export const EntryEditorModal: React.FC<EntryEditorModalProps> = ({
  isOpen,
  onClose,
  onSave,
  existingEntry,
  allEntries,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<LoreCategory>('Concepts');
  const [summary, setSummary] = useState('');
  const [body, setBody] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [canonStatus, setCanonStatus] = useState<CanonStatus>('canon');
  const [selectedConnections, setSelectedConnections] = useState<string[]>([]);

  useEffect(() => {
    if (existingEntry) {
      setTitle(existingEntry.title || '');
      setCategory(existingEntry.category || 'Concepts');
      setSummary(existingEntry.summary || '');
      setBody(existingEntry.body || '');
      setTagsInput(existingEntry.tags ? existingEntry.tags.join(', ') : '');
      setCanonStatus(existingEntry.canonStatus || 'canon');
      setSelectedConnections(existingEntry.connections || []);
    } else {
      setTitle('');
      setCategory('Concepts');
      setSummary('');
      setBody('');
      setTagsInput('');
      setCanonStatus('canon');
      setSelectedConnections([]);
    }
  }, [existingEntry, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !summary.trim() || !body.trim()) {
      alert('Please fill in Title, Summary, and Body text.');
      return;
    }

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    const slugId = existingEntry
      ? existingEntry.id
      : title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    onSave({
      id: slugId || `entry-${Date.now()}`,
      title,
      category,
      summary,
      body,
      tags,
      canonStatus,
      connections: selectedConnections,
      updatedAt: new Date().toISOString(),
      createdAt: existingEntry ? existingEntry.createdAt : new Date().toISOString(),
    });

    onClose();
  };

  const toggleConnection = (id: string) => {
    if (selectedConnections.includes(id)) {
      setSelectedConnections(selectedConnections.filter((c) => c !== id));
    } else {
      setSelectedConnections([...selectedConnections, id]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold">
              {existingEntry ? 'EDIT CODEX RECORD' : 'CREATE NEW CODEX ENTRY'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 font-mono text-xs">
          {/* Title & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 space-y-1">
              <label className="text-slate-300 font-bold">ENTRY TITLE *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Sacrificed Sector 09"
                className="w-full px-3 py-2 rounded bg-slate-950 border border-slate-800 text-white focus:border-emerald-500 focus:outline-none"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-bold">CATEGORY *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as LoreCategory)}
                className="w-full px-3 py-2 rounded bg-slate-950 border border-slate-800 text-white focus:border-emerald-500 focus:outline-none"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Summary */}
          <div className="space-y-1">
            <label className="text-slate-300 font-bold">SUMMARY (1-2 sentences) *</label>
            <input
              type="text"
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="Brief summary for card views..."
              className="w-full px-3 py-2 rounded bg-slate-950 border border-slate-800 text-white focus:border-emerald-500 focus:outline-none"
              required
            />
          </div>

          {/* Body Text */}
          <div className="space-y-1">
            <label className="text-slate-300 font-bold">FULL LORE TEXT / BODY *</label>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={6}
              placeholder="Detailed lore text..."
              className="w-full px-3 py-2 rounded bg-slate-950 border border-slate-800 text-white focus:border-emerald-500 focus:outline-none font-sans text-sm"
              required
            />
          </div>

          {/* Tags & Canon Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-bold">TAGS (comma-separated)</label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="Blight, Hardwired, Sacrificed"
                className="w-full px-3 py-2 rounded bg-slate-950 border border-slate-800 text-white focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-bold">CANON STATUS</label>
              <select
                value={canonStatus}
                onChange={(e) => setCanonStatus(e.target.value as CanonStatus)}
                className="w-full px-3 py-2 rounded bg-slate-950 border border-slate-800 text-white focus:border-emerald-500 focus:outline-none"
              >
                <option value="canon">Verified Canon</option>
                <option value="provisional">Provisional / Speculative</option>
                <option value="in-world-propaganda">In-World Corporate Propaganda</option>
                <option value="restricted">Restricted / Classified</option>
              </select>
            </div>
          </div>

          {/* Connect Other Lore Entries */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800">
            <label className="text-slate-300 font-bold flex items-center gap-1.5">
              <Link2 className="w-3.5 h-3.5 text-emerald-400" />
              CONNECTED LORE ENTRIES (Cross-Links)
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-2 rounded bg-slate-950 border border-slate-800">
              {allEntries
                .filter((e) => !existingEntry || e.id !== existingEntry.id)
                .map((e) => {
                  const isSelected = selectedConnections.includes(e.id);
                  return (
                    <button
                      type="button"
                      key={e.id}
                      onClick={() => toggleConnection(e.id)}
                      className={`px-2 py-1 rounded text-[11px] transition ${
                        isSelected
                          ? 'bg-emerald-500 text-slate-950 font-bold'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {isSelected ? '✓ ' : '+ '}
                      {e.title}
                    </button>
                  );
                })}
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 transition flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>Save Record</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
