import React, { useState } from 'react';
import {
  Shield,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Cpu,
  Lock,
  Search,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { WorldRule } from '../types';

interface RulesEngineProps {
  rules: WorldRule[];
}

export const RulesEngine: React.FC<RulesEngineProps> = ({ rules }) => {
  const [selectedDomain, setSelectedDomain] = useState<string>('ALL');

  // Contradiction Checker Form State
  const [testLoreProposal, setTestLoreProposal] = useState('');
  const [checkResult, setCheckResult] = useState<{
    isValid: boolean;
    issues: string[];
    recommendations: string[];
  } | null>(null);

  const filteredRules = rules.filter(
    (r) => selectedDomain === 'ALL' || r.domain === selectedDomain
  );

  const handleRunContradictionCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testLoreProposal.trim()) return;

    const lower = testLoreProposal.toLowerCase();
    const issues: string[] = [];
    const recommendations: string[] = [];

    // Rule 1: Wireless infection rule
    if (lower.includes('wireless') && (lower.includes('weaver') || lower.includes('sub-tier') || lower.includes('open air'))) {
      issues.push('VIOLATION OF THE 40–90 SECOND INFECTION RULE: Any wireless device exposed to open air in Veyra is compromised by the Blight within 90 seconds.');
      recommendations.push('Reframe the technology as hardwired copper, air-gapped, or modified with surgical "deaf" hardware.');
    }

    // Rule 2: Destroying Blight Mainframe
    if (lower.includes('kill the blight') || lower.includes('destroy mainframe') || lower.includes('blow up core')) {
      issues.push('VIOLATION OF DISTRIBUTED AI RULE: The Blight is a distributed intelligence with no core mainframe.');
      recommendations.push('Instead of destroying a core, focus on localized firewall containment or negotiating processing tribute.');
    }

    // Rule 3: Replicating Water Purification
    if (lower.includes('clean water generator') && lower.includes('sub-tier')) {
      issues.push('VIOLATION OF WATER MONOPOLY RULE: Station 09 in The Works holds the only large-scale water purification tech in Veyra.');
      recommendations.push('Make the sub-tiers siphoning water via illegal taps, or relying on minimal condensate from hydroponic pods.');
    }

    // Rule 4: Leaving the city easily
    if (lower.includes('drove outside') || lower.includes('fled the wall')) {
      issues.push('VIOLATION OF PERIMETER WALL RULE: Perimeter walls are guarded by Thorne Logistics Marshals requiring Crown Exit Permits.');
      recommendations.push('Incorporate a high-stakes checkpoint breach or clandestine smuggling route.');
    }

    setCheckResult({
      isValid: issues.length === 0,
      issues,
      recommendations: issues.length === 0 ? ['This lore proposal conforms strictly to all 5 canonical physical & tech constraints!'] : recommendations,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-bold">
              CANONICAL CONSTRAINT ENGINE
            </span>
            <span className="text-xs font-mono text-slate-500">World Bible Rules Validation</span>
          </div>
          <h2 className="text-xl md:text-2xl font-mono font-bold text-white tracking-tight mt-1">
            Hard World Rules & Contradiction Validator
          </h2>
        </div>
      </div>

      {/* Interactive Contradiction Checker Tool */}
      <div className="p-5 rounded-xl border border-amber-500/30 bg-slate-900/90 space-y-4 font-mono shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-white">LORE CONTRADICTION VALIDATOR</h3>
          </div>
          <span className="text-xs text-slate-400">Test new scene or tech ideas against canon</span>
        </div>

        <form onSubmit={handleRunContradictionCheck} className="space-y-3">
          <textarea
            value={testLoreProposal}
            onChange={(e) => setTestLoreProposal(e.target.value)}
            rows={3}
            placeholder="Type a proposed lore addition, e.g., 'A Weaver cell deploys wireless reconnaissance drones in the Midstack to hack a corporate server...'"
            className="w-full px-3 py-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:border-amber-500 focus:outline-none font-sans"
          />

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition flex items-center gap-1.5"
            >
              <Shield className="w-4 h-4" />
              <span>Validate Proposal Against Canon</span>
            </button>
          </div>
        </form>

        {checkResult && (
          <div className={`p-4 rounded-lg border text-xs space-y-2 ${
            checkResult.isValid
              ? 'bg-emerald-950/30 border-emerald-500/50 text-emerald-300'
              : 'bg-red-950/30 border-red-500/50 text-red-300'
          }`}>
            <div className="font-bold flex items-center gap-2 text-sm">
              {checkResult.isValid ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>PROPOSAL CONFORMS TO CANON RULES</span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                  <span>CONTRADICTION DETECTED IN LORE PROPOSAL</span>
                </>
              )}
            </div>

            {checkResult.issues.map((issue, idx) => (
              <p key={idx} className="font-bold text-red-300">• {issue}</p>
            ))}

            <div className="pt-2 border-t border-slate-800 text-slate-300">
              <span className="font-bold text-amber-400">RECOMMENDED FIXES: </span>
              {checkResult.recommendations.map((rec, idx) => (
                <span key={idx} className="font-sans block mt-1">• {rec}</span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Domain Filters */}
      <div className="flex items-center gap-2 font-mono text-xs">
        <span className="text-slate-400 font-bold pr-1">Filter Domain:</span>
        {['ALL', 'Technology', 'Blight', 'Resource', 'Society & Law'].map((d) => (
          <button
            key={d}
            onClick={() => setSelectedDomain(d)}
            className={`px-3 py-1 rounded transition ${
              selectedDomain === d
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {d}
          </button>
        ))}
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono">
        {filteredRules.map((rule) => (
          <div
            key={rule.id}
            className="rounded-xl border border-slate-800 bg-slate-900/90 p-5 space-y-3 shadow-lg hover:border-slate-700 transition"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-amber-400 uppercase">
                {rule.domain}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                HARD CONSTRAINT
              </span>
            </div>

            <h3 className="text-base font-bold text-white">{rule.title}</h3>

            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 space-y-1">
                <span className="text-slate-400 font-bold text-[10px]">HARD CONSTRAINT:</span>
                <p className="text-slate-200 font-sans leading-snug">{rule.hardConstraint}</p>
              </div>

              <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 space-y-1">
                <span className="text-red-400 font-bold text-[10px]">CONSEQUENCES:</span>
                <p className="text-slate-300 font-sans leading-snug">{rule.consequences}</p>
              </div>

              <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 space-y-1">
                <span className="text-emerald-400 font-bold text-[10px]">CANONICAL EXCEPTIONS:</span>
                <p className="text-slate-300 font-sans leading-snug">{rule.exceptionsOrLoopholes}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
