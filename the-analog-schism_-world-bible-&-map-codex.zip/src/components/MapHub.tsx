import React, { useState } from 'react';
import {
  MapPin,
  Layers,
  Activity,
  Shield,
  Droplet,
  Zap,
  Radio,
  Eye,
  AlertOctagon,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Search,
  CheckCircle2,
  Lock,
  Compass
} from 'lucide-react';
import { MapLayer, DistrictZone, TransitRoute, LoreEntry } from '../types';
import { SEED_LAYERS } from '../data/seedData';

interface MapHubProps {
  zones: DistrictZone[];
  routes: TransitRoute[];
  entries: LoreEntry[];
  onSelectEntry: (entry: LoreEntry) => void;
}

export const MapHub: React.FC<MapHubProps> = ({
  zones,
  routes,
  entries,
  onSelectEntry,
}) => {
  const [mapMode, setMapMode] = useState<'stack' | 'schematic' | 'inspector'>('stack');
  const [selectedLayerId, setSelectedLayerId] = useState<string>('sub-tiers');
  const [selectedZoneId, setSelectedZoneId] = useState<string>('zone-weaver-haven4');
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>(null);

  // Map Overlay Toggles for Schematic View
  const [overlay, setOverlay] = useState<'factions' | 'water' | 'power' | 'blight' | 'tribute' | 'checkpoints'>('factions');

  const selectedLayer = SEED_LAYERS.find((l) => l.id === selectedLayerId) || SEED_LAYERS[0];
  const selectedZone = zones.find((z) => z.id === selectedZoneId) || zones[0];
  const selectedRoute = routes.find((r) => r.id === selectedRouteId);

  const zonesInSelectedLayer = zones.filter((z) => z.layerId === selectedLayerId);

  const getFactionColor = (faction: string) => {
    if (faction.includes('Halcyon')) return 'bg-sky-500 text-sky-950 border-sky-400';
    if (faction.includes('Vireo')) return 'bg-teal-500 text-teal-950 border-teal-400';
    if (faction.includes('Ferrous')) return 'bg-amber-500 text-amber-950 border-amber-400';
    if (faction.includes('Aldergate')) return 'bg-purple-500 text-purple-950 border-purple-400';
    if (faction.includes('Thorne')) return 'bg-indigo-500 text-indigo-950 border-indigo-400';
    if (faction.includes('Weaver')) return 'bg-emerald-500 text-emerald-950 border-emerald-400';
    if (faction.includes('Cradle')) return 'bg-cyan-500 text-cyan-950 border-cyan-400';
    if (faction.includes('Blight')) return 'bg-red-600 text-white border-red-400';
    return 'bg-slate-700 text-slate-200 border-slate-600';
  };

  const getBlightSeverityColor = (layerId: string, isSacrificial: boolean) => {
    if (isSacrificial) return '#ef4444'; // Red
    if (layerId === 'dead-grid') return '#dc2626';
    if (layerId === 'sub-tiers' || layerId === 'floodline') return '#f59e0b'; // Amber
    if (layerId === 'works' || layerId === 'midstack') return '#eab308';
    return '#10b981'; // Appeased / Safe
  };

  return (
    <div className="space-y-6">
      {/* Header Bar & View Modes */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold">
              100% CANON ACCURATE MAP SYSTEM
            </span>
            <span className="text-xs font-mono text-slate-500">Veyra Cartography</span>
          </div>
          <h2 className="text-xl md:text-2xl font-mono font-bold text-white tracking-tight mt-1">
            Spatial Topology & Layer Cross-Section
          </h2>
        </div>

        {/* Mode Switcher */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 font-mono text-xs">
          <button
            onClick={() => setMapMode('stack')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition ${
              mapMode === 'stack'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Vertical Stack</span>
          </button>

          <button
            onClick={() => setMapMode('schematic')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition ${
              mapMode === 'schematic'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>District Topology Map</span>
          </button>

          <button
            onClick={() => setMapMode('inspector')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 transition ${
              mapMode === 'inspector'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Zone Inspector</span>
          </button>
        </div>
      </div>

      {/* MODE 1: VERTICAL CITY STACK (100% LORE CROSS-SECTION) */}
      {mapMode === 'stack' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Vertical Stack Selector Sidebar (7 Cols) */}
          <div className="lg:col-span-7 space-y-3">
            <div className="text-xs font-mono text-slate-400 flex items-center justify-between px-1">
              <span>VERTICAL ALTITUDE / DEPTH RANGE</span>
              <span>SELECT LAYER TO INSPECT</span>
            </div>

            <div className="space-y-2 font-mono">
              {SEED_LAYERS.map((layer) => {
                const isSelected = selectedLayerId === layer.id;
                const layerZones = zones.filter((z) => z.layerId === layer.id);

                return (
                  <div
                    key={layer.id}
                    onClick={() => {
                      setSelectedLayerId(layer.id);
                      if (layerZones.length > 0) setSelectedZoneId(layerZones[0].id);
                    }}
                    className={`p-4 rounded-xl border transition cursor-pointer relative overflow-hidden ${
                      isSelected
                        ? 'bg-slate-900 border-emerald-500/60 shadow-lg shadow-emerald-950/40 ring-1 ring-emerald-500/30'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/90'
                    }`}
                  >
                    {/* Left Color Accent Bar */}
                    <div
                      className="absolute left-0 top-0 bottom-0 w-1.5"
                      style={{ backgroundColor: layer.accentColor }}
                    />

                    <div className="pl-2 flex flex-col md:flex-row md:items-center justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span
                            className="text-xs px-2 py-0.5 rounded font-bold uppercase border"
                            style={{
                              borderColor: `${layer.accentColor}50`,
                              color: layer.accentColor,
                              backgroundColor: `${layer.accentColor}15`,
                            }}
                          >
                            {layer.altitudeRange}
                          </span>
                          <h3 className="text-base font-bold text-white">{layer.name}</h3>
                        </div>
                        <p className="text-xs text-slate-400 line-clamp-1">{layer.description}</p>
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-400">
                        <div className="text-right">
                          <div className="text-slate-300 font-semibold">{layer.primaryFaction}</div>
                          <div className="text-[11px] text-slate-500">Pop: {layer.populationShare}</div>
                        </div>
                        <ChevronRight className={`w-4 h-4 transition ${isSelected ? 'text-emerald-400 translate-x-1' : 'text-slate-600'}`} />
                      </div>
                    </div>

                    {/* Zone Badges inside Layer */}
                    <div className="pl-2 mt-2 pt-2 border-t border-slate-800/60 flex flex-wrap gap-1.5">
                      {layerZones.map((z) => (
                        <span
                          key={z.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedLayerId(layer.id);
                            setSelectedZoneId(z.id);
                          }}
                          className={`text-[11px] px-2 py-0.5 rounded transition ${
                            selectedZoneId === z.id
                              ? 'bg-emerald-500 text-slate-950 font-bold'
                              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                          }`}
                        >
                          {z.isSacrificialTribute && '⚠️ '}
                          {z.name}
                        </span>
                      ))}
                      {layerZones.length === 0 && (
                        <span className="text-[11px] text-slate-500 italic">No registered static districts</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Layer Details & District Inspector (5 Cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* Layer Info Card */}
            <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-xs font-mono text-emerald-400 font-bold uppercase">
                    PHYSICAL LAYER SPECS
                  </span>
                  <h3 className="text-lg font-mono font-bold text-white">{selectedLayer.name}</h3>
                </div>
                <span className="text-xs font-mono px-2 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300">
                  {selectedLayer.altitudeRange}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                <div className="p-2.5 rounded bg-slate-800/60 border border-slate-700/60 space-y-0.5">
                  <span className="text-slate-400 text-[10px]">SURVEILLANCE LEVEL</span>
                  <div className="font-bold text-slate-200">{selectedLayer.surveillanceLevel}</div>
                </div>

                <div className="p-2.5 rounded bg-slate-800/60 border border-slate-700/60 space-y-0.5">
                  <span className="text-slate-400 text-[10px]">HAZARD RATING</span>
                  <div className={`font-bold ${
                    selectedLayer.hazardRating === 'Lethal' || selectedLayer.hazardRating === 'Critical'
                      ? 'text-red-400'
                      : 'text-emerald-400'
                  }`}>
                    {selectedLayer.hazardRating}
                  </div>
                </div>

                <div className="col-span-2 p-2.5 rounded bg-slate-800/60 border border-slate-700/60 space-y-0.5">
                  <span className="text-slate-400 text-[10px]">TECH ENVIRONMENT</span>
                  <div className="font-medium text-slate-200">{selectedLayer.techEnvironment}</div>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed font-sans border-t border-slate-800/80 pt-3">
                {selectedLayer.description}
              </p>
            </div>

            {/* Selected Zone Deep-Dive Card */}
            {selectedZone && (
              <div className="rounded-xl border border-emerald-500/30 bg-slate-900/90 p-5 space-y-4 shadow-lg">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-emerald-400" />
                    <div>
                      <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">
                        DISTRICT INSPECTION
                      </span>
                      <h4 className="text-base font-mono font-bold text-white">{selectedZone.name}</h4>
                    </div>
                  </div>

                  {selectedZone.isSacrificialTribute && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-500/20 border border-red-500/50 text-red-400 font-bold animate-pulse">
                      SACRIFICED TRIBUTE
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-2 rounded bg-slate-800/80">
                    <span className="text-slate-400 text-[10px]">CONTROL:</span>
                    <div className="font-bold text-slate-200">{selectedZone.controllingFaction}</div>
                  </div>
                  <div className="p-2 rounded bg-slate-800/80">
                    <span className="text-slate-400 text-[10px]">WATER STATUS:</span>
                    <div className="font-bold text-amber-400">{selectedZone.waterStatus}</div>
                  </div>
                  <div className="p-2 rounded bg-slate-800/80">
                    <span className="text-slate-400 text-[10px]">TECH LEVEL:</span>
                    <div className="font-bold text-slate-200">{selectedZone.techLevel}</div>
                  </div>
                  <div className="p-2 rounded bg-slate-800/80">
                    <span className="text-slate-400 text-[10px]">POPULATION:</span>
                    <div className="font-bold text-slate-200">{selectedZone.populationEstimate}</div>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  {selectedZone.description}
                </p>

                {/* Linked Lore Connections */}
                {selectedZone.linkedEntryIds.length > 0 && (
                  <div className="space-y-1.5 border-t border-slate-800 pt-3">
                    <span className="text-[11px] font-mono text-slate-400 font-semibold">
                      LINKED LORE ENTRIES:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedZone.linkedEntryIds.map((id) => {
                        const entry = entries.find((e) => e.id === id);
                        if (!entry) return null;
                        return (
                          <button
                            key={id}
                            onClick={() => onSelectEntry(entry)}
                            className="text-xs font-mono px-2 py-1 rounded bg-slate-800 border border-slate-700 text-emerald-400 hover:text-emerald-300 hover:border-emerald-500/50 transition flex items-center gap-1"
                          >
                            <span>{entry.title}</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODE 2: TACTICAL DISTRICT TOPOLOGY & SCHEMATIC MAP */}
      {mapMode === 'schematic' && (
        <div className="space-y-4">
          {/* Overlay Selector Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl border border-slate-800 bg-slate-900/90 font-mono text-xs">
            <span className="text-slate-400 font-bold flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-emerald-400" />
              ACTIVE MAP OVERLAYS:
            </span>

            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setOverlay('factions')}
                className={`px-2.5 py-1 rounded border transition ${
                  overlay === 'factions' ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Faction Control
              </button>
              <button
                onClick={() => setOverlay('water')}
                className={`px-2.5 py-1 rounded border transition ${
                  overlay === 'water' ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Water Conduits
              </button>
              <button
                onClick={() => setOverlay('power')}
                className={`px-2.5 py-1 rounded border transition ${
                  overlay === 'power' ? 'bg-sky-500/20 border-sky-500 text-sky-300 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Power / Fiber Grid
              </button>
              <button
                onClick={() => setOverlay('blight')}
                className={`px-2.5 py-1 rounded border transition ${
                  overlay === 'blight' ? 'bg-red-500/20 border-red-500 text-red-300 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Blight Severity
              </button>
              <button
                onClick={() => setOverlay('tribute')}
                className={`px-2.5 py-1 rounded border transition ${
                  overlay === 'tribute' ? 'bg-purple-500/20 border-purple-500 text-purple-300 font-bold' : 'border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Sacrificial Tribute
              </button>
            </div>
          </div>

          {/* SVG Vector Topology Schematic Container */}
          <div className="relative rounded-xl border border-slate-800 bg-slate-950 p-6 min-h-[500px] overflow-hidden flex flex-col justify-between">
            {/* Grid Background Pattern */}
            <div
              className="absolute inset-0 opacity-15 pointer-events-none"
              style={{
                backgroundImage: 'radial-gradient(#38bdf8 1px, transparent 1px)',
                backgroundSize: '24px 24px',
              }}
            />

            {/* Horizontal Altitude Reference Lines */}
            <div className="absolute inset-x-0 top-[15%] border-b border-sky-500/20 text-[10px] font-mono text-sky-400/60 px-4">
              Crown Spire Horizon (+1000m)
            </div>
            <div className="absolute inset-x-0 top-[38%] border-b border-indigo-500/20 text-[10px] font-mono text-indigo-400/60 px-4">
              Midstack Residential Floor (+200m)
            </div>
            <div className="absolute inset-x-0 top-[55%] border-b border-amber-500/20 text-[10px] font-mono text-amber-400/60 px-4">
              Works Surface Level (0m)
            </div>
            <div className="absolute inset-x-0 top-[72%] border-b border-emerald-500/20 text-[10px] font-mono text-emerald-400/60 px-4">
              Sub-Tiers Hardwire Level (-400m)
            </div>
            <div className="absolute inset-x-0 top-[85%] border-b border-red-500/30 text-[10px] font-mono text-red-400/60 px-4">
              Floodline Marker (-800m) // Sacrificed Dead Grid Below
            </div>

            {/* SVG Transit Connection Lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
              {routes.map((route) => {
                const origZone = zones.find((z) => z.id === route.originZoneId);
                const destZone = zones.find((z) => z.id === route.destZoneId);
                if (!origZone || !destZone) return null;

                const isSelected = selectedRouteId === route.id;

                let strokeColor = '#475569';
                if (route.routeType === 'water-conduit') strokeColor = '#f59e0b';
                if (route.routeType === 'secret-fiber-run') strokeColor = '#10b981';
                if (route.routeType === 'vertical-lift') strokeColor = '#38bdf8';
                if (route.status === 'sealed') strokeColor = '#ef4444';

                return (
                  <g key={route.id}>
                    <line
                      x1={`${origZone.coordinates.x}%`}
                      y1={`${origZone.coordinates.y}%`}
                      x2={`${destZone.coordinates.x}%`}
                      y2={`${destZone.coordinates.y}%`}
                      stroke={strokeColor}
                      strokeWidth={isSelected ? 3 : 2}
                      strokeDasharray={route.isCovert ? '4,4' : undefined}
                      className="opacity-70 transition-all"
                    />
                  </g>
                );
              })}
            </svg>

            {/* District Node Elements */}
            <div className="relative z-20 w-full h-[450px]">
              {zones.map((zone) => {
                const isSelected = selectedZoneId === zone.id;

                let nodeStyle = 'border-slate-700 bg-slate-900 text-slate-200';
                if (overlay === 'factions') {
                  nodeStyle = getFactionColor(zone.controllingFaction);
                } else if (overlay === 'blight') {
                  if (zone.isSacrificialTribute) nodeStyle = 'bg-red-600 text-white border-red-400 animate-pulse';
                  else nodeStyle = 'bg-slate-800 text-slate-200 border-emerald-500/50';
                } else if (overlay === 'water') {
                  if (zone.waterStatus.includes('Critical')) nodeStyle = 'bg-amber-500/20 text-amber-300 border-amber-500';
                  else if (zone.waterStatus.includes('Abundant')) nodeStyle = 'bg-sky-500/20 text-sky-300 border-sky-500';
                  else nodeStyle = 'bg-emerald-500/20 text-emerald-300 border-emerald-500';
                }

                return (
                  <div
                    key={zone.id}
                    onClick={() => setSelectedZoneId(zone.id)}
                    style={{
                      left: `${zone.coordinates.x}%`,
                      top: `${zone.coordinates.y}%`,
                    }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer p-2 rounded-lg border font-mono text-xs transition-all shadow-lg ${
                      isSelected ? 'ring-2 ring-emerald-400 scale-110 z-30' : 'hover:scale-105 z-20'
                    } ${nodeStyle}`}
                  >
                    <div className="flex items-center gap-1.5 font-bold whitespace-nowrap">
                      {zone.isSacrificialTribute && <AlertOctagon className="w-3.5 h-3.5 text-red-300" />}
                      <span>{zone.name}</span>
                    </div>
                    <div className="text-[10px] opacity-80 whitespace-nowrap">
                      {zone.controllingFaction}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Route Legend Bar */}
            <div className="relative z-20 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs font-mono text-slate-400 gap-2">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1">
                  <span className="w-3 h-0.5 bg-sky-400" /> Crown Vertical Lift
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-0.5 bg-amber-400" /> Water Conduit
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-0.5 bg-emerald-400 border-dashed" /> Weaver Fiber Run
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-0.5 bg-red-500" /> Sealed Containment
                </span>
              </div>
              <span>Click node to select district</span>
            </div>
          </div>
        </div>
      )}

      {/* MODE 3: ZONE & ROUTE INSPECTOR */}
      {mapMode === 'inspector' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Zones List */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-5 space-y-3">
            <h3 className="text-sm font-mono font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-400" />
              Canonical Districts ({zones.length})
            </h3>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {zones.map((z) => (
                <div
                  key={z.id}
                  onClick={() => setSelectedZoneId(z.id)}
                  className={`p-3 rounded-lg border transition cursor-pointer font-mono text-xs space-y-1 ${
                    selectedZoneId === z.id
                      ? 'bg-emerald-500/10 border-emerald-500 text-emerald-300'
                      : 'bg-slate-800/50 border-slate-700/60 hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span>{z.name}</span>
                    <span className="text-[10px] text-slate-400">{z.layerId.toUpperCase()}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">Control: {z.controllingFaction}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Routes List */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-5 space-y-3">
            <h3 className="text-sm font-mono font-bold text-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-sky-400" />
              Transit & Infrastructure Corridors ({routes.length})
            </h3>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {routes.map((r) => {
                const orig = zones.find((z) => z.id === r.originZoneId);
                const dest = zones.find((z) => z.id === r.destZoneId);

                return (
                  <div
                    key={r.id}
                    onClick={() => setSelectedRouteId(r.id)}
                    className={`p-3 rounded-lg border transition cursor-pointer font-mono text-xs space-y-1 ${
                      selectedRouteId === r.id
                        ? 'bg-sky-500/10 border-sky-500 text-sky-300'
                        : 'bg-slate-800/50 border-slate-700/60 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold">
                      <span>{r.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        {r.routeType}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Connects: {orig?.name} ➔ {dest?.name}
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-1">{r.description}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
