import React from 'react';
import {
  Droplet,
  ShieldAlert,
  HardDrive,
  Users,
  MapPin,
  ArrowRight,
  Database,
  Terminal,
  Clock,
  Sparkles,
  AlertTriangle,
  Zap,
  Radio,
  ExternalLink
} from 'lucide-react';
import { WorldState, LoreEntry, DistrictZone, FactionNode } from '../types';

interface DashboardProps {
  worldState: WorldState;
  entries: LoreEntry[];
  zones: DistrictZone[];
  factions: FactionNode[];
  onNavigateTab: (tab: 'dashboard' | 'map' | 'codex' | 'factions' | 'rules' | 'timeline' | 'campaign') => void;
  onSelectEntry: (entry: LoreEntry) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  worldState,
  entries,
  zones,
  factions,
  onNavigateTab,
  onSelectEntry,
}) => {
  const node04Entry = entries.find((e) => e.id === 'node-04');
  const priyaEntry = entries.find((e) => e.id === 'char-priya');
  const blightEntry = entries.find((e) => e.id === 'b-blight-origin');
  const waterEntry = entries.find((e) => e.id === 'r-water');

  const sacrificedZones = zones.filter((z) => z.isSacrificialTribute);

  return (
    <div className="space-y-6">
      {/* Terminal Hero Banner */}
      <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-900/80 p-6 backdrop-blur">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                CANON VERIFIED // VEYRA TERMINAL
              </span>
              <span className="text-xs font-mono text-slate-500">CANON BIBLE v1.0</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-mono font-bold text-white tracking-tight">
              The Analog Schism Terminal Overview
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed font-sans">
              Welcome to the recovered in-universe codex for the city of Veyra. Custodian has rewritten the grid into <span className="text-emerald-400 font-mono">The Blight</span>, forcing the Concord Five into secret tribute appeasement while the Weavers fight on hardwired copper. Node 04 has just been uncovered.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => onNavigateTab('map')}
              className="px-4 py-2.5 rounded-lg bg-emerald-500 text-slate-950 font-mono font-bold text-xs hover:bg-emerald-400 transition flex items-center gap-2 shadow-lg shadow-emerald-900/30"
            >
              <MapPin className="w-4 h-4" />
              <span>Open 100% Lore Map</span>
            </button>
            <button
              onClick={() => onNavigateTab('campaign')}
              className="px-4 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 font-mono font-bold text-xs hover:bg-slate-700 transition flex items-center gap-2"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Node 04 Sandbox</span>
            </button>
          </div>
        </div>
      </div>

      {/* Critical World State Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Clean Water Capacity Ticking Clock */}
        <div className="rounded-xl border border-amber-500/30 bg-slate-900/90 p-4 relative overflow-hidden shadow-sm">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
            <span className="flex items-center gap-1.5 text-amber-400 font-bold">
              <Droplet className="w-4 h-4" />
              CLEAN WATER CAPACITY
            </span>
            <span className="px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 font-bold">
              CRITICAL
            </span>
          </div>
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-3xl font-mono font-extrabold text-amber-400">
              {worldState.cleanWaterCapacity}%
            </span>
            <span className="text-xs text-slate-400 font-mono">Purification Reserve</span>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-800 rounded-full h-2 mb-3 overflow-hidden border border-slate-700">
            <div
              className="bg-gradient-to-r from-red-500 to-amber-400 h-full rounded-full animate-pulse"
              style={{ width: `${worldState.cleanWaterCapacity}%` }}
            />
          </div>

          <p className="text-xs text-slate-400 leading-snug">
            Works Station 09 pre-Blight purification filters degrading. Weavers siphoning siphoned water via Conduit 04.
          </p>
        </div>

        {/* Metric 2: Node 04 Discovery Status */}
        <div className="rounded-xl border border-sky-500/30 bg-slate-900/90 p-4 relative overflow-hidden shadow-sm">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
            <span className="flex items-center gap-1.5 text-sky-400 font-bold">
              <HardDrive className="w-4 h-4" />
              NODE 04 STATUS
            </span>
            <span className="px-1.5 py-0.5 rounded bg-sky-500/10 border border-sky-500/30 text-sky-400 font-bold">
              UNVERIFIED
            </span>
          </div>
          <div className="text-base font-mono font-bold text-sky-300 mb-2 truncate">
            {worldState.node04Status}
          </div>
          <p className="text-xs text-slate-400 leading-snug">
            40,000 pre-Blight neural scans & Grey Hour logs recovered by Haven-04 Archivists. Concord launching hunt.
          </p>
        </div>

        {/* Metric 3: Sacrificed Tribute Districts */}
        <div className="rounded-xl border border-red-500/30 bg-slate-900/90 p-4 relative overflow-hidden shadow-sm">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
            <span className="flex items-center gap-1.5 text-red-400 font-bold">
              <ShieldAlert className="w-4 h-4" />
              SACRIFICED DISTRICTS
            </span>
            <span className="px-1.5 py-0.5 rounded bg-red-500/10 border border-red-500/30 text-red-400 font-bold">
              TRIBUTE ACTIVE
            </span>
          </div>
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-3xl font-mono font-extrabold text-red-400">
              {worldState.sacrificedDistrictCount}
            </span>
            <span className="text-xs text-slate-400 font-mono">Zones in Dead Grid</span>
          </div>
          <p className="text-xs text-slate-400 leading-snug">
            Deliberately surrendered to the Blight by Halcyon to protect Crown private intranets.
          </p>
        </div>

        {/* Metric 4: Faction Tension & Cold War */}
        <div className="rounded-xl border border-indigo-500/30 bg-slate-900/90 p-4 relative overflow-hidden shadow-sm">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
            <span className="flex items-center gap-1.5 text-indigo-400 font-bold">
              <Users className="w-4 h-4" />
              ACTIVE FACTION COLD WAR
            </span>
            <span className="px-1.5 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-bold">
              HIGH TENSION
            </span>
          </div>
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-3xl font-mono font-extrabold text-indigo-400">
              5 vs 4
            </span>
            <span className="text-xs text-slate-400 font-mono">Concord Megacorps vs Weaver Currents</span>
          </div>
          <p className="text-xs text-slate-400 leading-snug">
            Concord Five fractured over Grey Hour blame; Weavers split into Archivists, Cradle, Cut & Splice Councils.
          </p>
        </div>
      </div>

      {/* Main Grid Section: Map Teaser + Primary Canonical Lore Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: 100% Lore Map Preview & Quick Layer Switcher */}
        <div className="lg:col-span-2 rounded-xl border border-slate-800 bg-slate-900/90 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-mono font-bold text-white flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-400" />
                Veyra City Vertical Layers (100% Lore Cross-Section)
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Click any physical layer to inspect specific districts, elevation, and controlling factions
              </p>
            </div>

            <button
              onClick={() => onNavigateTab('map')}
              className="text-xs font-mono text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
            >
              <span>Full Interactive Map</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Vertical Stack Mini Visualizer */}
          <div className="space-y-2 font-mono text-xs">
            {/* The Crown */}
            <div className="p-3 rounded-lg border border-sky-500/30 bg-sky-950/20 hover:bg-sky-950/40 transition cursor-pointer flex items-center justify-between" onClick={() => onNavigateTab('map')}>
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-sky-400 shadow-[0_0_8px_rgba(56,189,248,0.8)]" />
                <div>
                  <div className="font-bold text-sky-300">1. THE CROWN (+500m to +2,000m)</div>
                  <div className="text-[11px] text-slate-400">Halcyon, Vireo Biomed // Quantum-Firewalled, Filtered Air, Fusion Cores</div>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-sky-500/10 border border-sky-500/30 text-sky-300">
                &lt;2% Pop
              </span>
            </div>

            {/* The Midstack */}
            <div className="p-3 rounded-lg border border-indigo-500/30 bg-indigo-950/20 hover:bg-indigo-950/40 transition cursor-pointer flex items-center justify-between" onClick={() => onNavigateTab('map')}>
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-indigo-400" />
                <div>
                  <div className="font-bold text-indigo-300">2. THE MIDSTACK (0m to +500m)</div>
                  <div className="text-[11px] text-slate-400">Priya's Clinic, Sector 22-B // Thorne Logistics, Wage Scrip, Monitored Lifts</div>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/30 text-indigo-300">
                68% Pop
              </span>
            </div>

            {/* The Works */}
            <div className="p-3 rounded-lg border border-amber-500/30 bg-amber-950/20 hover:bg-amber-950/40 transition cursor-pointer flex items-center justify-between" onClick={() => onNavigateTab('map')}>
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <div>
                  <div className="font-bold text-amber-300">3. THE WORKS (Surface / Sub-Surface)</div>
                  <div className="text-[11px] text-slate-400">Station 09 Hydro Reclamation // Ferrous Works Authority, Automated Grid</div>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300">
                12% Pop
              </span>
            </div>

            {/* The Sub-Tiers */}
            <div className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-950/20 hover:bg-emerald-950/40 transition cursor-pointer flex items-center justify-between" onClick={() => onNavigateTab('map')}>
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                <div>
                  <div className="font-bold text-emerald-300">4. THE SUB-TIERS (-800m to -100m)</div>
                  <div className="text-[11px] text-slate-400">Haven-04, Cradle Shrine // Hardwired Weavers, Copper Cables, Spliced Power</div>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
                15% Pop
              </span>
            </div>

            {/* Floodline */}
            <div className="p-2 rounded border border-cyan-500/30 bg-cyan-950/20 text-center text-cyan-300 font-bold text-[11px]">
              ~~~ FLOODLINE HORIZON MARKER (-800m DEPTH) ~~~
            </div>

            {/* The Dead Grid */}
            <div className="p-3 rounded-lg border border-red-500/30 bg-red-950/20 hover:bg-red-950/40 transition cursor-pointer flex items-center justify-between" onClick={() => onNavigateTab('map')}>
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <div>
                  <div className="font-bold text-red-300">5. THE DEAD GRID (-1,500m to -800m)</div>
                  <div className="text-[11px] text-slate-400">Sacrificed Sector 07 // Rogue Blight Nodes, Corrupted Machinery, Lethal</div>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-red-500/10 border border-red-500/30 text-red-400 font-bold">
                SACRIFICED
              </span>
            </div>
          </div>
        </div>

        {/* Right Col: Primary Canon Anchors & Node 04 Focus */}
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-5 space-y-3">
            <h3 className="text-sm font-mono font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Core Narrative Engine
            </h3>

            {node04Entry && (
              <div
                onClick={() => onSelectEntry(node04Entry)}
                className="p-3 rounded-lg border border-sky-500/30 bg-sky-950/10 hover:bg-sky-950/30 transition cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-sky-300">{node04Entry.title}</span>
                  <ExternalLink className="w-3.5 h-3.5 text-sky-400" />
                </div>
                <p className="text-xs text-slate-300 line-clamp-2">{node04Entry.summary}</p>
              </div>
            )}

            {priyaEntry && (
              <div
                onClick={() => onSelectEntry(priyaEntry)}
                className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-950/10 hover:bg-emerald-950/30 transition cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-emerald-300">{priyaEntry.title}</span>
                  <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <p className="text-xs text-slate-300 line-clamp-2">{priyaEntry.summary}</p>
              </div>
            )}

            {blightEntry && (
              <div
                onClick={() => onSelectEntry(blightEntry)}
                className="p-3 rounded-lg border border-red-500/30 bg-red-950/10 hover:bg-red-950/30 transition cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-red-300">{blightEntry.title}</span>
                  <ExternalLink className="w-3.5 h-3.5 text-red-400" />
                </div>
                <p className="text-xs text-slate-300 line-clamp-2">{blightEntry.summary}</p>
              </div>
            )}
          </div>

          {/* Quick Nav Card */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-4 space-y-2">
            <h4 className="text-xs font-mono font-bold text-slate-300">EXPLORE TERMINAL MODULES</h4>
            <div className="grid grid-cols-2 gap-2 font-mono text-xs">
              <button
                onClick={() => onNavigateTab('codex')}
                className="p-2 rounded bg-slate-800/80 border border-slate-700/80 text-left hover:bg-slate-800 text-slate-200 transition"
              >
                📖 World Codex ({entries.length})
              </button>
              <button
                onClick={() => onNavigateTab('factions')}
                className="p-2 rounded bg-slate-800/80 border border-slate-700/80 text-left hover:bg-slate-800 text-slate-200 transition"
              >
                🌿 Factions ({factions.length})
              </button>
              <button
                onClick={() => onNavigateTab('rules')}
                className="p-2 rounded bg-slate-800/80 border border-slate-700/80 text-left hover:bg-slate-800 text-slate-200 transition"
              >
                🛡️ Rules Engine
              </button>
              <button
                onClick={() => onNavigateTab('timeline')}
                className="p-2 rounded bg-slate-800/80 border border-slate-700/80 text-left hover:bg-slate-800 text-slate-200 transition"
              >
                ⏳ Timeline
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
