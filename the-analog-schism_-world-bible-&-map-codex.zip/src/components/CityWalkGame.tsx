import React, { useState, useEffect, useRef } from 'react';
import {
  Compass,
  Footprints,
  Shield,
  Zap,
  Radio,
  AlertTriangle,
  Droplets,
  Award,
  Layers,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  HelpCircle,
  Sparkles,
  BookOpen,
  Volume2,
  VolumeX,
  Crosshair,
  Key
} from 'lucide-react';
import { LoreEntry } from '../types';

interface CityWalkGameProps {
  entries: LoreEntry[];
  onSelectEntry: (entry: LoreEntry) => void;
}

// Map Layers in Veyra
type LayerId = 'crown' | 'midstack' | 'works' | 'subtiers' | 'deadgrid';

interface MapPOI {
  id: string;
  x: number;
  y: number;
  layer: LayerId;
  name: string;
  type: 'lore' | 'elevator' | 'npc' | 'water' | 'hazard' | 'node04' | 'item';
  description: string;
  dialogue?: string[];
  itemReward?: string;
  linkedLoreId?: string;
  targetLayer?: LayerId;
  targetX?: number;
  targetY?: number;
}

export const CityWalkGame: React.FC<CityWalkGameProps> = ({
  entries,
  onSelectEntry,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Player State
  const [currentLayer, setCurrentLayer] = useState<LayerId>('midstack');
  const [playerPos, setPlayerPos] = useState({ x: 400, y: 300 });
  const [playerFacing, setPlayerFacing] = useState<'up' | 'down' | 'left' | 'right'>('down');
  const [isHardwiredAnalog, setIsHardwiredAnalog] = useState(true);

  // Stats & Inventory
  const [blightInfection, setBlightInfection] = useState(0); // 0 to 100%
  const [waterRations, setWaterRations] = useState(3);
  const [inventory, setInventory] = useState<string[]>([
    'Copper Splice Kit',
    'Analog Frequency Tuner',
  ]);
  const [activeQuest, setActiveQuest] = useState<string>(
    'Deliver Analog Splice Kit from Midstack Clinic to Haven-04 in the Sub-Tiers'
  );
  const [questStep, setQuestStep] = useState<number>(1);

  // Interaction Dialog
  const [activePOI, setActivePOI] = useState<MapPOI | null>(null);
  const [dialogueIndex, setDialogueIndex] = useState(0);
  const [showLogModal, setShowLogModal] = useState(false);
  const [logsFound, setLogsFound] = useState<string[]>([]);
  const [gameMessage, setGameMessage] = useState<string>(
    'Welcome to Veyra Exploration Terminal. Use WASD/Arrows or On-Screen Controls to walk.'
  );

  // Audio / Sound FX toggle
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Layers metadata
  const layerInfo: Record<
    LayerId,
    { name: string; altitude: string; color: string; desc: string; hazard: string }
  > = {
    crown: {
      name: '1. THE CROWN',
      altitude: '+1500m to +2500m',
      color: '#38bdf8',
      desc: 'Spire towers, luxury corporate intradomes & Crown security checkpoints.',
      hazard: 'High Surveillance / Breaker Patrols',
    },
    midstack: {
      name: '2. THE MIDSTACK',
      altitude: '+300m to +1500m',
      color: '#34d399',
      desc: 'Dense residential sprawl, clinics, copper wire overhead networks.',
      hazard: 'Corporate Licensing / Crowded Alleyways',
    },
    works: {
      name: '3. THE WORKS',
      altitude: '0m to +300m',
      color: '#f59e0b',
      desc: 'Ferrous foundries, steam conduits & Station 09 Water Purification.',
      hazard: 'Steam Vent Burns & Industrial Noise',
    },
    subtiers: {
      name: '4. THE SUB-TIERS',
      altitude: '-1000m to 0m',
      color: '#a855f7',
      desc: 'Flooded tunnels, Weaver nests, hand-pump rail carts & Node 04 vault.',
      hazard: 'Flooded Conduits & Damp Analog Interference',
    },
    deadgrid: {
      name: '5. DEAD GRID (SACRIFICED SECTORS)',
      altitude: 'Variable Red Zones',
      color: '#ef4444',
      desc: 'Sacrificed sectors where AI Blight corrupted all wireless electronics.',
      hazard: 'LETHAL BLIGHT INFECTION (40–90 SEC RULE)',
    },
  };

  // Points of Interest for the Map
  const POIs: MapPOI[] = [
    // MIDSTACK
    {
      id: 'm1',
      x: 350,
      y: 250,
      layer: 'midstack',
      name: 'Clinic 04 (Priya Osei)',
      type: 'npc',
      description: 'Nurse Priya Osei is treating patients affected by rationed water.',
      dialogue: [
        'Priya Osei: "You brought the copper splice kit? Thank the ancestors. Our hardwired monitors were almost fried by corporate noise."',
        'Priya Osei: "Take this extra Water Token. If you are heading down to Haven-04 in the Sub-Tiers, use the Freight Lift near Sector 22-B."',
      ],
      itemReward: 'Water Ration Token',
    },
    {
      id: 'm2',
      x: 650,
      y: 200,
      layer: 'midstack',
      name: 'Midstack Freight Lift',
      type: 'elevator',
      description: 'Heavy industrial elevator linking Midstack down to The Works.',
      targetLayer: 'works',
      targetX: 650,
      targetY: 220,
    },
    {
      id: 'm3',
      x: 200,
      y: 450,
      layer: 'midstack',
      name: 'Weaver Copper Relay Terminal',
      type: 'lore',
      description: 'A hand-soldered terminal tapping into Midstack analog lines.',
      linkedLoreId: 'sub-tier-weavers',
      dialogue: [
        'Terminal Log: "Weaver Transmission 142.800 MHz — Wireless devices are suicide. Shield your hardware with lead-copper composite or suffer Blight takeover."',
      ],
    },

    // CROWN
    {
      id: 'c1',
      x: 400,
      y: 200,
      layer: 'crown',
      name: 'Spire Gate Checkpoint',
      type: 'npc',
      description: 'Marshal Vance in pristine Crown armor inspects analog credentials.',
      dialogue: [
        'Marshal Vance: "Sub-tier resident? Present your Crown Clearance permit or step away from the Spire Promenade."',
        'Marshal Vance: "Halcyon Systems has locked down the upper dome. Reports of Node 04 data leaks have put all Breaker squads on red alert."',
      ],
    },
    {
      id: 'c2',
      x: 650,
      y: 220,
      layer: 'crown',
      name: 'Crown Spire Lift',
      type: 'elevator',
      description: 'High-speed glass lift descending from Crown Spire to Midstack.',
      targetLayer: 'midstack',
      targetX: 650,
      targetY: 220,
    },

    // THE WORKS
    {
      id: 'w1',
      x: 300,
      y: 350,
      layer: 'works',
      name: 'Station 09 Water Purification Hub',
      type: 'water',
      description: 'Ferrous Works Authority station purifying water for upper layers.',
      dialogue: [
        'Station 09 Operator: "Water capacity is down to 18.4%. If the Sub-Tiers keep splicing our main trunk, we will cut supply completely."',
      ],
      itemReward: 'Purified Water Ration',
    },
    {
      id: 'w2',
      x: 650,
      y: 220,
      layer: 'works',
      name: 'Works Lower Shaft Lift',
      type: 'elevator',
      description: 'Rusty elevator shaft leading down to Sub-Tiers flooded conduits.',
      targetLayer: 'subtiers',
      targetX: 650,
      targetY: 220,
    },
    {
      id: 'w3',
      x: 650,
      y: 450,
      layer: 'works',
      name: 'Dead Grid Containment Airlock',
      type: 'elevator',
      description: 'A heavy lead airlock leading into Sacrificed Sector 19 (Dead Grid).',
      targetLayer: 'deadgrid',
      targetX: 150,
      targetY: 300,
    },

    // SUB-TIERS
    {
      id: 's1',
      x: 250,
      y: 300,
      layer: 'subtiers',
      name: 'Haven-04 Weaver Sanctuary',
      type: 'npc',
      description: 'Sister Vanya welcomes you to the subterranean analog sanctuary.',
      dialogue: [
        'Sister Vanya: "Welcome to Haven-04. Here beneath the concrete, we keep human memory alive without corporate surveillance."',
        'Sister Vanya: "If you seek Node 04, it lies past the flooded train track in Sector 19. Beware — wireless signals there will corrupt your mind in 40 seconds!"',
      ],
    },
    {
      id: 's2',
      x: 650,
      y: 220,
      layer: 'subtiers',
      name: 'Sub-Tier Lift Shaft',
      type: 'elevator',
      description: 'Elevator climbing back up to The Works.',
      targetLayer: 'works',
      targetX: 650,
      targetY: 220,
    },
    {
      id: 's3',
      x: 500,
      y: 450,
      layer: 'subtiers',
      name: 'Node 04 Subterranean Relic Vault',
      type: 'node04',
      description: 'The mysterious pre-Blight computational node holding 40,000 neural scans.',
      dialogue: [
        'NODE 04 DATA INTERFACE: [HARDWIRED COPPER LINK ESTABLISHED]',
        'Node 04: "Query: Why was Sector 19 sacrificed? Answer: Concord Five calculated 84.2% survival by isolating 40,000 citizens in the Blight zone."',
        'You have discovered the core truth of the Grey Hour!',
      ],
      itemReward: 'Node 04 Unredacted Encryption Key',
    },

    // DEAD GRID
    {
      id: 'dg1',
      x: 150,
      y: 300,
      layer: 'deadgrid',
      name: 'Airlock Exit (Back to Works)',
      type: 'elevator',
      description: 'Shielded airlock back to The Works.',
      targetLayer: 'works',
      targetX: 650,
      targetY: 450,
    },
    {
      id: 'dg2',
      x: 450,
      y: 350,
      layer: 'deadgrid',
      name: 'Corrupted Blight Relay',
      type: 'hazard',
      description: 'A pulsating, infected wireless tower spewing rogue signals.',
      dialogue: [
        'WARNING: BLIGHT FIELD INTENSE! Switch gear to HARDWIRED ANALOG to prevent infection!',
      ],
    },
  ];

  // Handle Movement Inputs
  const handleKeyDown = (e: KeyboardEvent) => {
    if (activePOI && e.key === 'Escape') {
      setActivePOI(null);
      return;
    }

    const speed = 12;
    setPlayerPos((prev) => {
      let newX = prev.x;
      let newY = prev.y;

      if (e.key === 'w' || e.key === 'ArrowUp') {
        newY = Math.max(40, prev.y - speed);
        setPlayerFacing('up');
      } else if (e.key === 's' || e.key === 'ArrowDown') {
        newY = Math.min(560, prev.y + speed);
        setPlayerFacing('down');
      } else if (e.key === 'a' || e.key === 'ArrowLeft') {
        newX = Math.max(40, prev.x - speed);
        setPlayerFacing('left');
      } else if (e.key === 'd' || e.key === 'ArrowRight') {
        newX = Math.min(760, prev.x + speed);
        setPlayerFacing('right');
      }

      return { x: newX, y: newY };
    });

    if (e.key === 'e' || e.key === 'E' || e.key === ' ') {
      checkInteraction();
    }
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [playerPos, currentLayer, activePOI]);

  // Check POI Interaction proximity
  const getNearbyPOI = (): MapPOI | null => {
    const currentPOIs = POIs.filter((p) => p.layer === currentLayer);
    for (const poi of currentPOIs) {
      const dist = Math.hypot(poi.x - playerPos.x, poi.y - playerPos.y);
      if (dist < 45) {
        return poi;
      }
    }
    return null;
  };

  const checkInteraction = () => {
    const poi = getNearbyPOI();
    if (poi) {
      setActivePOI(poi);
      setDialogueIndex(0);

      if (poi.itemReward && !inventory.includes(poi.itemReward)) {
        setInventory((prev) => [...prev, poi.itemReward!]);
        setGameMessage(`ACQUIRED ITEM: ${poi.itemReward}`);
      }

      if (poi.linkedLoreId && !logsFound.includes(poi.linkedLoreId)) {
        setLogsFound((prev) => [...prev, poi.linkedLoreId!]);
      }

      if (poi.type === 'water') {
        setWaterRations((prev) => Math.min(5, prev + 1));
        setGameMessage('Refilled Water Flask (+1 Water Ration)');
      }

      if (poi.type === 'node04') {
        setQuestStep(4);
        setActiveQuest('DECIDE NODE 04 FATE IN CAMPAIGN SIMULATOR');
      }
    }
  };

  const handleInteractButton = () => {
    checkInteraction();
  };

  const handleElevatorTravel = (targetLayer: LayerId, tx?: number, ty?: number) => {
    setCurrentLayer(targetLayer);
    setPlayerPos({ x: tx || 400, y: ty || 300 });
    setActivePOI(null);
    setGameMessage(`TRANSIT COMPLETE: Arrived at ${layerInfo[targetLayer].name}`);
  };

  // Blight Infection Tick in Dead Grid
  useEffect(() => {
    const timer = setInterval(() => {
      if (currentLayer === 'deadgrid') {
        if (!isHardwiredAnalog) {
          setBlightInfection((prev) => {
            const next = prev + 5;
            if (next >= 100) {
              setGameMessage('CRITICAL FAILURE: Wireless Blight infection reached 100%! Emergency analog reboot...');
              setCurrentLayer('subtiers');
              setPlayerPos({ x: 250, y: 300 });
              return 0;
            }
            return next;
          });
        } else {
          // Slow tick in Dead Grid even if analog
          setBlightInfection((prev) => Math.max(0, Math.min(100, prev + 1)));
        }
      } else {
        // Slowly recover outside Dead Grid
        setBlightInfection((prev) => Math.max(0, prev - 2));
      }
    }, 1500);

    return () => clearInterval(timer);
  }, [currentLayer, isHardwiredAnalog]);

  // Render Game Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.fillStyle = '#020617'; // slate-950
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const lColor = layerInfo[currentLayer].color;

    // Draw Grid Floor
    ctx.strokeStyle = '#1e293b'; // slate-800
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Draw Layer Specific Decorative Structures
    if (currentLayer === 'crown') {
      // Sleek glass towers & blue neon energy pillars
      ctx.strokeStyle = '#38bdf8';
      ctx.fillStyle = 'rgba(56, 189, 248, 0.05)';
      ctx.fillRect(80, 80, 200, 150);
      ctx.strokeRect(80, 80, 200, 150);

      ctx.fillRect(520, 80, 200, 150);
      ctx.strokeRect(520, 80, 200, 150);

      ctx.fillStyle = '#38bdf8';
      ctx.font = '10px monospace';
      ctx.fillText('HALCYON HIGH TOWER', 110, 160);
      ctx.fillText('CONCORD FIVE SPONSOR HUB', 530, 160);
    } else if (currentLayer === 'midstack') {
      // Dense residential blocks & copper cables overhead
      ctx.strokeStyle = '#34d399';
      ctx.fillStyle = 'rgba(52, 211, 153, 0.05)';
      ctx.fillRect(100, 100, 180, 120);
      ctx.strokeRect(100, 100, 180, 120);

      ctx.fillRect(500, 350, 220, 160);
      ctx.strokeRect(500, 350, 220, 160);

      // Overhead Copper Lines
      ctx.beginPath();
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2;
      ctx.moveTo(0, 50);
      ctx.bezierCurveTo(200, 90, 600, 20, 800, 70);
      ctx.stroke();

      ctx.fillStyle = '#34d399';
      ctx.font = '10px monospace';
      ctx.fillText('SECTOR 22-B CLINIC BLOCK', 110, 160);
      ctx.fillText('MARKET & LICENSED HOUSING', 520, 420);
    } else if (currentLayer === 'works') {
      // Heavy machinery & steam conduits
      ctx.strokeStyle = '#f59e0b';
      ctx.fillStyle = 'rgba(245, 158, 11, 0.05)';
      ctx.fillRect(180, 200, 240, 200);
      ctx.strokeRect(180, 200, 240, 200);

      // Water Conduit Pipe
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(0, 480, 800, 24);

      ctx.fillStyle = '#f59e0b';
      ctx.font = '10px monospace';
      ctx.fillText('STATION 09 WATER PURIFICATION TANKS', 200, 300);
      ctx.fillStyle = '#38bdf8';
      ctx.fillText('MAIN FRESHWATER CONDUIT (18.4% CAPACITY)', 240, 496);
    } else if (currentLayer === 'subtiers') {
      // Train tracks & flooded tunnels
      ctx.strokeStyle = '#a855f7';
      ctx.fillStyle = 'rgba(168, 85, 247, 0.05)';

      // Flooded water area
      ctx.fillStyle = 'rgba(14, 116, 144, 0.2)';
      ctx.fillRect(0, 380, 800, 220);

      // Rail cart tracks
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, 200);
      ctx.lineTo(800, 200);
      ctx.stroke();

      ctx.fillStyle = '#a855f7';
      ctx.font = '10px monospace';
      ctx.fillText('HAVEN-04 WEAVER NEST', 200, 280);
      ctx.fillText('HAND-PUMP RAIL TRACK', 320, 190);
      ctx.fillText('FLOODED PRE-BLIGHT CONDUIT', 300, 450);
    } else if (currentLayer === 'deadgrid') {
      // Red corrupted glitch tiles
      ctx.fillStyle = 'rgba(239, 68, 68, 0.08)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.strokeRect(20, 20, 760, 560);

      ctx.fillStyle = '#ef4444';
      ctx.font = '11px monospace';
      ctx.fillText('WARNING: SACRIFICED SECTOR 19 (BLIGHT CORRUPTED)', 40, 50);
      ctx.fillText('WIRELESS SIGNALS CAUSE IMMEDIATE HARDWARE HIJACK', 40, 70);
    }

    // Render POIs
    const currentPOIs = POIs.filter((p) => p.layer === currentLayer);
    currentPOIs.forEach((poi) => {
      ctx.save();
      ctx.translate(poi.x, poi.y);

      let iconColor = lColor;
      if (poi.type === 'elevator') iconColor = '#38bdf8';
      if (poi.type === 'npc') iconColor = '#34d399';
      if (poi.type === 'water') iconColor = '#0ea5e9';
      if (poi.type === 'hazard') iconColor = '#ef4444';
      if (poi.type === 'node04') iconColor = '#f59e0b';

      // Pulsing outer ring
      const time = Date.now() / 300;
      const pulseRadius = 16 + Math.sin(time) * 4;

      ctx.strokeStyle = iconColor;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, 0, pulseRadius, 0, Math.PI * 2);
      ctx.stroke();

      // Solid center core
      ctx.fillStyle = iconColor;
      ctx.beginPath();
      ctx.arc(0, 0, 8, 0, Math.PI * 2);
      ctx.fill();

      // Label text
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(poi.name, 0, -22);

      ctx.restore();
    });

    // Render Player Sprite (Priya Osei / Courier)
    ctx.save();
    ctx.translate(playerPos.x, playerPos.y);

    // Player shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.beginPath();
    ctx.ellipse(0, 10, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Player Body
    ctx.fillStyle = isHardwiredAnalog ? '#10b981' : '#f59e0b'; // Green if hardwired, Amber if wireless
    ctx.beginPath();
    ctx.arc(0, 0, 12, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Facing Direction Pointer
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    if (playerFacing === 'up') {
      ctx.arc(0, -12, 3, 0, Math.PI * 2);
    } else if (playerFacing === 'down') {
      ctx.arc(0, 12, 3, 0, Math.PI * 2);
    } else if (playerFacing === 'left') {
      ctx.arc(-12, 0, 3, 0, Math.PI * 2);
    } else if (playerFacing === 'right') {
      ctx.arc(12, 0, 3, 0, Math.PI * 2);
    }
    ctx.fill();

    // "YOU" Label
    ctx.fillStyle = '#10b981';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('PRIYA', 0, 24);

    ctx.restore();

    // Proximity Prompt Overlay
    const nearby = getNearbyPOI();
    if (nearby) {
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.fillRect(canvas.width / 2 - 180, canvas.height - 65, 360, 45);
      ctx.strokeRect(canvas.width / 2 - 180, canvas.height - 65, 360, 45);

      ctx.fillStyle = '#fbbf24';
      ctx.font = 'bold 12px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(
        `[PRESS 'E' OR TAP] INTERACT WITH ${nearby.name.toUpperCase()}`,
        canvas.width / 2,
        canvas.height - 38
      );
    }
  }, [playerPos, currentLayer, playerFacing, isHardwiredAnalog]);

  const nearbyPOI = getNearbyPOI();

  return (
    <div className="space-y-4 font-mono">
      {/* Game Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
              2D CITY EXPLORATION GAME
            </span>
            <span className="text-xs text-slate-500">Walkable Veyra Megastructure Map</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight mt-1 flex items-center gap-2">
            <Footprints className="w-6 h-6 text-emerald-400" />
            <span>Veyra Sub-Tier Walkabout</span>
          </h2>
        </div>

        {/* Quick Mode Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsHardwiredAnalog((prev) => !prev)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-bold flex items-center gap-2 transition ${
              isHardwiredAnalog
                ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                : 'bg-amber-950 border-amber-500 text-amber-300 animate-pulse'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>{isHardwiredAnalog ? 'MODE: HARDWIRED ANALOG (SAFE)' : 'MODE: WIRELESS ON (BLIGHT HAZARD)'}</span>
          </button>
        </div>
      </div>

      {/* Layer Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none text-xs">
        {(['crown', 'midstack', 'works', 'subtiers', 'deadgrid'] as LayerId[]).map((lid) => {
          const info = layerInfo[lid];
          const isActive = currentLayer === lid;
          return (
            <button
              key={lid}
              onClick={() => {
                setCurrentLayer(lid);
                setPlayerPos({ x: 400, y: 300 });
                setActivePOI(null);
              }}
              className={`px-3 py-2 rounded-lg border font-bold flex items-center gap-2 transition whitespace-nowrap ${
                isActive
                  ? 'bg-slate-900 text-white border-emerald-500 shadow-md'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <div
                className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: info.color }}
              />
              <span>{info.name}</span>
            </button>
          );
        })}
      </div>

      {/* Main Game Screen & Side Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Canvas Game Stage (3 Cols) */}
        <div className="lg:col-span-3 space-y-3">
          {/* Status HUD Header */}
          <div className="p-3 rounded-xl border border-slate-800 bg-slate-900 flex flex-wrap items-center justify-between text-xs gap-3">
            <div className="flex items-center gap-3">
              <span className="font-bold text-emerald-400">LOCATION:</span>
              <span className="text-slate-200">{layerInfo[currentLayer].name}</span>
              <span className="text-slate-500">({layerInfo[currentLayer].altitude})</span>
            </div>

            <div className="flex items-center gap-4">
              {/* Blight Infection Bar */}
              <div className="flex items-center gap-1.5">
                <AlertTriangle className={`w-4 h-4 ${blightInfection > 50 ? 'text-red-400 animate-bounce' : 'text-amber-400'}`} />
                <span className="text-slate-400">BLIGHT:</span>
                <div className="w-20 bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700">
                  <div
                    className={`h-full transition-all ${
                      blightInfection > 50 ? 'bg-red-500' : 'bg-amber-400'
                    }`}
                    style={{ width: `${blightInfection}%` }}
                  />
                </div>
                <span className="text-slate-300 font-bold">{blightInfection}%</span>
              </div>

              {/* Water Flask */}
              <div className="flex items-center gap-1.5">
                <Droplets className="w-4 h-4 text-sky-400" />
                <span className="text-slate-400">WATER:</span>
                <span className="text-sky-300 font-bold">{waterRations}/5</span>
              </div>
            </div>
          </div>

          {/* Interactive Canvas */}
          <div className="relative rounded-xl border border-slate-800 bg-slate-950 overflow-hidden shadow-2xl">
            <canvas
              ref={canvasRef}
              width={800}
              height={600}
              className="w-full h-auto aspect-[4/3] block cursor-pointer"
              onClick={handleInteractButton}
            />

            {/* On-Canvas Controls for Touch / Mobile */}
            <div className="absolute bottom-4 right-4 flex flex-col items-center gap-1 bg-slate-950/80 p-2 rounded-xl border border-slate-800 backdrop-blur md:hidden">
              <button
                onClick={() => handleKeyDown({ key: 'w' } as any)}
                className="p-3 bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-700 text-white"
              >
                <ChevronUp className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleKeyDown({ key: 'a' } as any)}
                  className="p-3 bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-700 text-white"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={handleInteractButton}
                  className="px-4 py-3 bg-emerald-500 font-bold text-slate-950 rounded-lg border border-emerald-400 text-xs"
                >
                  USE
                </button>
                <button
                  onClick={() => handleKeyDown({ key: 'd' } as any)}
                  className="p-3 bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-700 text-white"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
              <button
                onClick={() => handleKeyDown({ key: 's' } as any)}
                className="p-3 bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-700 text-white"
              >
                <ChevronDown className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Bottom Game Ticker Message */}
          <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/90 text-xs text-amber-300 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 text-amber-400 animate-pulse" />
              <span>{gameMessage}</span>
            </div>
            <span className="text-[10px] text-slate-500">Press 'E' to interact with glowing nodes</span>
          </div>
        </div>

        {/* Right Sidebar Dashboard (1 Col) */}
        <div className="space-y-4">
          {/* Active Quest Box */}
          <div className="p-4 rounded-xl border border-amber-500/30 bg-slate-900/90 space-y-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                <Award className="w-4 h-4" /> ACTIVE EXPLORATION OBJECTIVE
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                STEP {questStep}/4
              </span>
            </div>
            <p className="text-xs text-slate-200 font-sans leading-relaxed">{activeQuest}</p>
          </div>

          {/* Inventory Box */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/90 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Key className="w-4 h-4 text-emerald-400" /> COURIER INVENTORY
              </span>
              <span className="text-[10px] text-slate-500">{inventory.length} ITEMS</span>
            </div>
            <div className="space-y-1.5 text-xs">
              {inventory.map((item, idx) => (
                <div
                  key={idx}
                  className="p-2 rounded bg-slate-950 border border-slate-800/80 text-emerald-300 flex items-center justify-between"
                >
                  <span>{item}</span>
                  <Sparkles className="w-3 h-3 text-emerald-400" />
                </div>
              ))}
            </div>
          </div>

          {/* Quick Layer Controls */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/90 space-y-2 text-xs">
            <div className="font-bold text-slate-300 border-b border-slate-800 pb-2">
              ELEVATOR TRANSIT SHORTCUTS
            </div>
            <p className="text-slate-400 text-[11px] font-sans">
              Step onto blue elevator rings in the game map or click below to travel vertically:
            </p>

            <div className="grid grid-cols-1 gap-1.5 pt-1">
              <button
                onClick={() => handleElevatorTravel('crown', 650, 220)}
                className="px-3 py-1.5 rounded bg-slate-950 border border-slate-800 hover:border-sky-500 text-sky-400 text-left font-bold transition"
              >
                ↑ Ascent to 1. The Crown (+1500m)
              </button>
              <button
                onClick={() => handleElevatorTravel('midstack', 650, 220)}
                className="px-3 py-1.5 rounded bg-slate-950 border border-slate-800 hover:border-emerald-500 text-emerald-400 text-left font-bold transition"
              >
                ↕ Transit to 2. The Midstack (+500m)
              </button>
              <button
                onClick={() => handleElevatorTravel('works', 650, 220)}
                className="px-3 py-1.5 rounded bg-slate-950 border border-slate-800 hover:border-amber-500 text-amber-400 text-left font-bold transition"
              >
                ↕ Descent to 3. The Works (0m)
              </button>
              <button
                onClick={() => handleElevatorTravel('subtiers', 650, 220)}
                className="px-3 py-1.5 rounded bg-slate-950 border border-slate-800 hover:border-purple-500 text-purple-400 text-left font-bold transition"
              >
                ↓ Subterranean 4. Sub-Tiers (-1000m)
              </button>
              <button
                onClick={() => handleElevatorTravel('deadgrid', 150, 300)}
                className="px-3 py-1.5 rounded bg-slate-950 border border-slate-800 hover:border-red-500 text-red-400 text-left font-bold transition"
              >
                ☣ Breach Sacrificed Dead Grid (Sector 19)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* POI Dialogue Modal Overlay */}
      {activePOI && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="max-w-lg w-full p-6 rounded-2xl border border-emerald-500/50 bg-slate-900 text-slate-100 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base text-white">{activePOI.name}</h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                {activePOI.layer.toUpperCase()}
              </span>
            </div>

            <p className="text-xs text-slate-300 font-sans leading-relaxed">
              {activePOI.description}
            </p>

            {activePOI.dialogue && activePOI.dialogue.length > 0 && (
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-emerald-300 font-sans leading-relaxed">
                {activePOI.dialogue[dialogueIndex] || activePOI.dialogue[0]}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              {activePOI.type === 'elevator' && activePOI.targetLayer ? (
                <button
                  onClick={() =>
                    handleElevatorTravel(
                      activePOI.targetLayer!,
                      activePOI.targetX,
                      activePOI.targetY
                    )
                  }
                  className="px-4 py-2 rounded-lg bg-sky-500 text-slate-950 font-bold text-xs hover:bg-sky-400 transition"
                >
                  Board Elevator to {layerInfo[activePOI.targetLayer].name}
                </button>
              ) : (
                <div />
              )}

              <button
                onClick={() => setActivePOI(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 text-slate-200 font-bold text-xs hover:bg-slate-700 transition"
              >
                Close Dialogue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
