import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Plus,
  Tag,
  Link2,
  Edit2,
  Trash2,
  Filter,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  ChevronRight,
  Shield,
  Layers,
  Sparkles
} from 'lucide-react';
import { LoreEntry, LoreCategory, CanonStatus } from '../types';
import { EntryEditorModal } from './EntryEditorModal';

interface LoreCodexProps {
  entries: LoreEntry[];
  onSaveEntry: (entry: Partial<LoreEntry>) => void;
  onDeleteEntry: (id: string) => void;
  selectedEntryId?: string | null;
  onSelectEntryId: (id: string | null) => void;
}

const CATEGORIES: LoreCategory[] = [
  'Factions',
  'Characters',
  'Locations',
  'Technology',
  'History',
  'Culture & Belief',
  'Resources & Economy',
  'The Blight',
  'Concepts',
];

export const LoreCodex: React.FC<LoreCodexProps> = ({
  entries,
  onSaveEntry,
  onDeleteEntry,
  selectedEntryId,
  onSelectEntryId,
}) => {
  const [activeCategory, setActiveCategory] = useState<LoreCategory | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [canonFilter, setCanonFilter] = useState<CanonStatus | 'ALL'>('ALL');

  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<LoreEntry | null>(null);

  // Extract unique tags across all entries
  const allTags = Array.from(new Set(entries.flatMap((e) => e.tags || [])));

  // Filter entries
  const filteredEntries = entries.filter((entry) => {
    if (activeCategory !== 'ALL' && entry.category !== activeCategory) return false;
    if (activeTag && (!entry.tags || !entry.tags.includes(activeTag))) return false;
    if (canonFilter !== 'ALL' && entry.canonStatus !== canonFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = entry.title.toLowerCase().includes(q);
      const matchSummary = entry.summary.toLowerCase().includes(q);
      const matchBody = entry.body.toLowerCase().includes(q);
      const matchTag = entry.tags?.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchSummary && !matchBody && !matchTag) return false;
    }

    return true;
  });

  const selectedEntry = entries.find((e) => e.id === selectedEntryId) || filteredEntries[0] || null;

  const handleCreateNew = () => {
    setEditingEntry(null);
    setIsEditorOpen(true);
  };

  const handleEdit = (entry: LoreEntry) => {
    setEditingEntry(entry);
    setIsEditorOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Permanently delete this Codex entry from local storage?')) {
      onDeleteEntry(id);
      if (selectedEntryId === id) onSelectEntryId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Search & Filter Control Bar */}
      <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/90 space-y-3 font-mono text-xs">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search lore title, body text, or tags..."
              className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:border-emerald-500 focus:outline-none"
            />
          </div>

          {/* Canon Filter */}
          <div className="flex items-center gap-2">
            <select
              value={canonFilter}
              onChange={(e) => setCanonFilter(e.target.value as any)}
              className="px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 focus:border-emerald-500 focus:outline-none"
            >
              <option value="ALL">All Canon Statuses</option>
              <option value="canon">Verified Canon</option>
              <option value="provisional">Provisional</option>
              <option value="in-world-propaganda">Corporate Propaganda</option>
              <option value="restricted">Restricted / Classified</option>
            </select>

            <button
              onClick={handleCreateNew}
              className="px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 transition flex items-center gap-1.5 whitespace-nowrap shadow-md shadow-emerald-950/40"
            >
              <Plus className="w-4 h-4" />
              <span>Add Entry</span>
            </button>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => {
              setActiveCategory('ALL');
              setActiveTag(null);
            }}
            className={`px-3 py-1 rounded transition whitespace-nowrap ${
              activeCategory === 'ALL'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            ALL ({entries.length})
          </button>

          {CATEGORIES.map((cat) => {
            const count = entries.filter((e) => e.category === cat).length;
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => {
                  setActiveCategory(cat);
                  setActiveTag(null);
                }}
                className={`px-3 py-1 rounded transition whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {cat} ({count})
              </button>
            );
          })}
        </div>

        {/* Tags Bar */}
        {allTags.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pt-1 border-t border-slate-800/60 scrollbar-none">
            <span className="text-slate-500 text-[10px] uppercase font-bold pr-1">Filter Tag:</span>
            {allTags.slice(0, 12).map((tag) => (
              <button
                key={tag}
                onClick={() => setActiveTag(activeTag === tag ? null : tag)}
                className={`px-2 py-0.5 rounded text-[11px] transition ${
                  activeTag === tag
                    ? 'bg-sky-500 text-slate-950 font-bold'
                    : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Main Split Layout: Entry List (Left) + Detail Reader (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Entry Cards List (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
            <span>CODEX RECORDS ({filteredEntries.length})</span>
            {activeTag && <span>TAG: #{activeTag}</span>}
          </div>

          <div className="space-y-2 max-h-[650px] overflow-y-auto pr-1">
            {filteredEntries.map((entry) => {
              const isSelected = selectedEntry?.id === entry.id;

              return (
                <div
                  key={entry.id}
                  onClick={() => onSelectEntryId(entry.id)}
                  className={`p-4 rounded-xl border transition cursor-pointer space-y-2 font-mono ${
                    isSelected
                      ? 'bg-slate-900 border-emerald-500/60 shadow-lg shadow-emerald-950/30 ring-1 ring-emerald-500/30'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/90'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase px-2 py-0.5 rounded bg-slate-800 text-emerald-400 border border-slate-700">
                      {entry.category}
                    </span>
                    <span className="text-[10px] text-slate-500">
                      {entry.canonStatus === 'canon' ? 'CANON' : entry.canonStatus.toUpperCase()}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white tracking-tight">{entry.title}</h3>
                  <p className="text-xs text-slate-300 font-sans line-clamp-2 leading-relaxed">
                    {entry.summary}
                  </p>

                  <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                    <div className="flex items-center gap-1 text-emerald-400 font-semibold">
                      <Link2 className="w-3 h-3" />
                      <span>{entry.connections?.length || 0} Connected</span>
                    </div>

                    <ChevronRight className={`w-4 h-4 transition ${isSelected ? 'text-emerald-400 translate-x-1' : 'text-slate-600'}`} />
                  </div>
                </div>
              );
            })}

            {filteredEntries.length === 0 && (
              <div className="p-8 text-center rounded-xl border border-dashed border-slate-800 text-slate-500 font-mono text-xs space-y-2">
                <BookOpen className="w-8 h-8 mx-auto text-slate-600" />
                <p>No Codex entries found matching query.</p>
                <button
                  onClick={handleCreateNew}
                  className="px-3 py-1.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30 transition"
                >
                  Create New Record
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Selected Entry Reader View (7 Cols) */}
        <div className="lg:col-span-7">
          {selectedEntry ? (
            <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-6 space-y-5 shadow-xl">
              {/* Entry Header Controls */}
              <div className="flex items-start justify-between border-b border-slate-800 pb-4 gap-4 font-mono">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2.5 py-0.5 rounded font-bold uppercase bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                      {selectedEntry.category}
                    </span>
                    <span className="text-xs text-slate-500">
                      STATUS: {selectedEntry.canonStatus.toUpperCase()}
                    </span>
                  </div>
                  <h2 className="text-xl md:text-2xl font-bold text-white">{selectedEntry.title}</h2>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleEdit(selectedEntry)}
                    className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    title="Edit Record"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(selectedEntry.id)}
                    className="p-2 rounded bg-slate-800 hover:bg-red-900/40 text-slate-400 hover:text-red-400 transition"
                    title="Delete Record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Summary Callout Box */}
              <div className="p-4 rounded-lg border border-sky-500/20 bg-sky-950/20 text-sky-200 text-xs font-mono leading-relaxed">
                <span className="font-bold text-sky-400 uppercase">SUMMARY: </span>
                {selectedEntry.summary}
              </div>

              {/* Body Lore Text */}
              <div className="text-slate-200 text-sm font-sans leading-relaxed space-y-3 whitespace-pre-line">
                {selectedEntry.body}
              </div>

              {/* Tags Section */}
              {selectedEntry.tags && selectedEntry.tags.length > 0 && (
                <div className="pt-3 border-t border-slate-800/80 flex items-center gap-2 flex-wrap font-mono text-xs">
                  <Tag className="w-3.5 h-3.5 text-slate-500" />
                  <span className="text-slate-400">Tags:</span>
                  {selectedEntry.tags.map((t) => (
                    <span
                      key={t}
                      onClick={() => setActiveTag(t)}
                      className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-emerald-300 cursor-pointer transition"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              )}

              {/* Connected Lore Entries Cross-Links */}
              <div className="pt-4 border-t border-slate-800 space-y-2 font-mono text-xs">
                <div className="text-slate-400 font-bold flex items-center gap-1.5">
                  <Link2 className="w-4 h-4 text-emerald-400" />
                  <span>CONNECTED CANON ENTRIES ({selectedEntry.connections?.length || 0}):</span>
                </div>

                <div className="flex flex-wrap gap-2">
                  {selectedEntry.connections?.map((connId) => {
                    const connEntry = entries.find((e) => e.id === connId);
                    if (!connEntry) return null;

                    return (
                      <button
                        key={connId}
                        onClick={() => onSelectEntryId(connId)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800/90 border border-slate-700 hover:border-emerald-500/50 text-slate-200 hover:text-emerald-300 transition flex items-center gap-2 group"
                      >
                        <span className="font-bold">{connEntry.title}</span>
                        <span className="text-[10px] text-slate-500 uppercase">({connEntry.category})</span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition" />
                      </button>
                    );
                  })}

                  {(!selectedEntry.connections || selectedEntry.connections.length === 0) && (
                    <span className="text-slate-500 italic">No cross-links configured.</span>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center rounded-xl border border-slate-800 bg-slate-900/50 text-slate-500 font-mono text-xs space-y-2">
              <BookOpen className="w-10 h-10 mx-auto text-slate-600" />
              <p>Select a Codex entry from the left list to read details.</p>
            </div>
          )}
        </div>
      </div>

      {/* Editor Modal */}
      <EntryEditorModal
        isOpen={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        onSave={onSaveEntry}
        existingEntry={editingEntry}
        allEntries={entries}
      />
    </div>
  );
};
