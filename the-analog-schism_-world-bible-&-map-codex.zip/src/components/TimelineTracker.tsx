import React from 'react';
import { Clock, AlertTriangle, ExternalLink, ShieldAlert, Sparkles } from 'lucide-react';
import { TimelineEvent, LoreEntry } from '../types';

interface TimelineTrackerProps {
  events: TimelineEvent[];
  entries: LoreEntry[];
  onSelectEntry: (entry: LoreEntry) => void;
}

export const TimelineTracker: React.FC<TimelineTrackerProps> = ({
  events,
  entries,
  onSelectEntry,
}) => {
  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-purple-500/10 border border-purple-500/30 text-purple-400 font-mono text-xs font-bold">
              HISTORICAL CHRONOLOGY
            </span>
            <span className="text-xs font-mono text-slate-500">From Pre-Blight to Present Day</span>
          </div>
          <h2 className="text-xl md:text-2xl font-mono font-bold text-white tracking-tight mt-1">
            Timeline of the Schism & Grey Hour
          </h2>
        </div>
      </div>

      {/* Timeline Vertical Track */}
      <div className="relative border-l-2 border-purple-500/30 ml-4 md:ml-8 pl-6 space-y-8 font-mono">
        {events.map((evt, idx) => (
          <div key={evt.id} className="relative group">
            {/* Timeline Node Point */}
            <div className="absolute -left-[31px] top-1.5 w-4 h-4 rounded-full bg-slate-950 border-2 border-purple-400 group-hover:bg-purple-400 transition shadow-[0_0_8px_rgba(192,132,252,0.8)]" />

            <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-5 space-y-3 shadow-lg hover:border-purple-500/50 transition">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs px-2.5 py-0.5 rounded font-bold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/40">
                    {evt.era}
                  </span>
                  <span className="text-xs text-slate-400 font-bold">{evt.yearOffset}</span>
                </div>

                <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                  evt.impactLevel === 'Cataclysmic'
                    ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                }`}>
                  {evt.impactLevel} IMPACT
                </span>
              </div>

              <h3 className="text-lg font-bold text-white">{evt.title}</h3>
              <p className="text-xs text-sky-200 font-sans leading-relaxed">{evt.summary}</p>
              <p className="text-xs text-slate-300 font-sans leading-relaxed border-t border-slate-800/80 pt-2">
                {evt.details}
              </p>

              {/* Linked Entries */}
              {evt.linkedEntryIds && evt.linkedEntryIds.length > 0 && (
                <div className="pt-2 flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-slate-500 text-[10px] uppercase font-bold pr-1">LINKED CANON:</span>
                  {evt.linkedEntryIds.map((id) => {
                    const entry = entries.find((e) => e.id === id);
                    if (!entry) return null;
                    return (
                      <button
                        key={id}
                        onClick={() => onSelectEntry(entry)}
                        className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-purple-300 hover:text-white hover:border-purple-500 transition flex items-center gap-1 text-[11px]"
                      >
                        <span>{entry.title}</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
