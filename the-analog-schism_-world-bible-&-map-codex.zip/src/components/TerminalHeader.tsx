import React from 'react';
import {
  Terminal,
  Shield,
  Zap,
  Download,
  Upload,
  RotateCcw,
  SlidersHorizontal,
  Search,
  Radio,
  MapPin,
  BookOpen,
  GitFork,
  CheckCircle2,
  Clock,
  Swords,
  Footprints
} from 'lucide-react';
import { exportBackupData, restoreBackupData, resetToSeedCanon } from '../lib/storage';

interface TerminalHeaderProps {
  activeTab: 'dashboard' | 'map' | 'codex' | 'factions' | 'rules' | 'timeline' | 'campaign' | 'walk';
  setActiveTab: (tab: 'dashboard' | 'map' | 'codex' | 'factions' | 'rules' | 'timeline' | 'campaign' | 'walk') => void;
  theme: 'emerald' | 'cyan' | 'amber';
  setTheme: (t: 'emerald' | 'cyan' | 'amber') => void;
  scanlines: boolean;
  setScanlines: (s: boolean | ((prev: boolean) => boolean)) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onRefreshData: () => void;
}

export const TerminalHeader: React.FC<TerminalHeaderProps> = ({
  activeTab,
  setActiveTab,
  theme,
  setTheme,
  scanlines,
  setScanlines,
  searchQuery,
  setSearchQuery,
  onRefreshData,
}) => {
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const data = exportBackupData();
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analog_schism_codex_${new Date().toISOString().slice(0, 10)}.schism.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        restoreBackupData(parsed);
        onRefreshData();
        alert('Codex data restored successfully!');
      } catch (err) {
        alert('Failed to parse backup file. Please ensure it is a valid .schism.json file.');
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (confirm('Reset entire Codex to 100% canonical seed state? Custom edits will be overwritten.')) {
      resetToSeedCanon();
      onRefreshData();
    }
  };

  const themeClasses = {
    emerald: 'border-emerald-500/40 text-emerald-400 bg-emerald-950/20 shadow-emerald-900/20',
    cyan: 'border-sky-500/40 text-sky-400 bg-sky-950/20 shadow-sky-900/20',
    amber: 'border-amber-500/40 text-amber-400 bg-amber-950/20 shadow-amber-900/20',
  }[theme];

  const glowText = {
    emerald: 'text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.5)]',
    cyan: 'text-sky-400 drop-shadow-[0_0_8px_rgba(56,189,248,0.5)]',
    amber: 'text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]',
  }[theme];

  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-50">
      {/* Top Bar Status */}
      <div className="px-4 py-2 border-b border-slate-800/80 flex flex-wrap items-center justify-between text-xs font-mono text-slate-400 gap-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-slate-300 font-bold">NODE_04: ACTIVE</span>
          </div>
          <span className="hidden sm:inline text-slate-500">|</span>
          <span className="hidden sm:inline text-slate-400">SIGNAL: HARDWIRED_COPPER</span>
          <span className="hidden md:inline text-slate-500">|</span>
          <span className="hidden md:inline text-slate-400">FREQ: 142.800 MHz (ANALOG_ONLY)</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Theme selectors */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-800">
            <button
              onClick={() => setTheme('emerald')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition ${
                theme === 'emerald' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Weaver Emerald Theme"
            >
              WEAVER
            </button>
            <button
              onClick={() => setTheme('cyan')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition ${
                theme === 'cyan' ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Crown Corporate Cyan Theme"
            >
              CROWN
            </button>
            <button
              onClick={() => setTheme('amber')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition ${
                theme === 'amber' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Dead Grid Amber Theme"
            >
              DEAD_GRID
            </button>
          </div>

          <button
            onClick={() => setScanlines((prev) => !prev)}
            className={`px-2 py-1 rounded border text-xs flex items-center gap-1 font-mono transition ${
              scanlines ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400' : 'border-slate-800 text-slate-500 hover:text-slate-300'
            }`}
            title="Toggle CRT Scanline Effect"
          >
            <Radio className="w-3 h-3" />
            <span>CRT</span>
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1 hidden sm:block" />

          {/* Backup & Restore controls */}
          <button
            onClick={handleExport}
            className="p-1.5 rounded border border-slate-800 hover:border-slate-700 text-slate-300 hover:bg-slate-900 transition"
            title="Export .schism.json Backup"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleImportClick}
            className="p-1.5 rounded border border-slate-800 hover:border-slate-700 text-slate-300 hover:bg-slate-900 transition"
            title="Import .schism.json Backup"
          >
            <Upload className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleReset}
            className="p-1.5 rounded border border-slate-800 hover:border-red-900/50 text-slate-400 hover:text-red-400 hover:bg-slate-900 transition"
            title="Reset to Canon Seed Data"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".json" className="hidden" />
        </div>
      </div>

      {/* Main Header Title & Navigation */}
      <div className="px-4 py-3 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-lg border ${themeClasses}`}>
            <Terminal className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className={`text-lg md:text-xl font-mono font-bold tracking-tight ${glowText}`}>
                THE ANALOG SCHISM
              </h1>
              <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                VEYRA_CODEX v1.0
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Terminal Node 04 // Interactive Canon Bible & 100% Lore Map
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none font-mono text-xs">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium transition whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('map')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium transition whitespace-nowrap ${
              activeTab === 'map'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <MapPin className="w-3.5 h-3.5 text-emerald-400" />
            <span>Lore Maps (100%)</span>
          </button>

          <button
            onClick={() => setActiveTab('codex')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium transition whitespace-nowrap ${
              activeTab === 'codex'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-sky-400" />
            <span>World Codex</span>
          </button>

          <button
            onClick={() => setActiveTab('factions')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium transition whitespace-nowrap ${
              activeTab === 'factions'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <GitFork className="w-3.5 h-3.5 text-indigo-400" />
            <span>Faction Network</span>
          </button>

          <button
            onClick={() => setActiveTab('rules')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium transition whitespace-nowrap ${
              activeTab === 'rules'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span>Rules Engine</span>
          </button>

          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium transition whitespace-nowrap ${
              activeTab === 'timeline'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-purple-400" />
            <span>Timeline</span>
          </button>

          <button
            onClick={() => setActiveTab('campaign')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium transition whitespace-nowrap ${
              activeTab === 'campaign'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Swords className="w-3.5 h-3.5 text-rose-400" />
            <span>Priya & Node 04</span>
          </button>

          <button
            onClick={() => setActiveTab('walk')}
            className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 font-medium transition whitespace-nowrap ${
              activeTab === 'walk'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Footprints className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Walk Veyra Game</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
