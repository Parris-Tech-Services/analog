import {
  LoreEntry,
  DistrictZone,
  TransitRoute,
  FactionNode,
  WorldRule,
  TimelineEvent,
  WorldState
} from '../types';
import {
  SEED_ENTRIES,
  SEED_ZONES,
  SEED_ROUTES,
  SEED_FACTIONS,
  SEED_RULES,
  SEED_TIMELINE,
  INITIAL_WORLD_STATE
} from '../data/seedData';

const STORAGE_KEYS = {
  ENTRIES: 'schism_entries_v1',
  ZONES: 'schism_zones_v1',
  ROUTES: 'schism_routes_v1',
  FACTIONS: 'schism_factions_v1',
  RULES: 'schism_rules_v1',
  TIMELINE: 'schism_timeline_v1',
  WORLD_STATE: 'schism_world_state_v1',
  THEME_MODE: 'schism_terminal_theme',
  SCANLINES_ENABLED: 'schism_scanlines',
};

export interface SchismBackupData {
  version: string;
  exportedAt: string;
  worldState: WorldState;
  entries: LoreEntry[];
  zones: DistrictZone[];
  routes: TransitRoute[];
  factions: FactionNode[];
  rules: WorldRule[];
  timeline: TimelineEvent[];
}

export function loadEntries(): LoreEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ENTRIES);
    if (!raw) {
      saveEntries(SEED_ENTRIES);
      return SEED_ENTRIES;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load entries from storage:', e);
    return SEED_ENTRIES;
  }
}

export function saveEntries(entries: LoreEntry[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
  } catch (e) {
    console.error('Failed to save entries:', e);
  }
}

export function loadZones(): DistrictZone[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ZONES);
    if (!raw) {
      saveZones(SEED_ZONES);
      return SEED_ZONES;
    }
    return JSON.parse(raw);
  } catch (e) {
    return SEED_ZONES;
  }
}

export function saveZones(zones: DistrictZone[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ZONES, JSON.stringify(zones));
  } catch (e) {
    console.error('Failed to save zones:', e);
  }
}

export function loadRoutes(): TransitRoute[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ROUTES);
    if (!raw) {
      saveRoutes(SEED_ROUTES);
      return SEED_ROUTES;
    }
    return JSON.parse(raw);
  } catch (e) {
    return SEED_ROUTES;
  }
}

export function saveRoutes(routes: TransitRoute[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ROUTES, JSON.stringify(routes));
  } catch (e) {
    console.error('Failed to save routes:', e);
  }
}

export function loadFactions(): FactionNode[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FACTIONS);
    if (!raw) {
      saveFactions(SEED_FACTIONS);
      return SEED_FACTIONS;
    }
    return JSON.parse(raw);
  } catch (e) {
    return SEED_FACTIONS;
  }
}

export function saveFactions(factions: FactionNode[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.FACTIONS, JSON.stringify(factions));
  } catch (e) {
    console.error('Failed to save factions:', e);
  }
}

export function loadRules(): WorldRule[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RULES);
    if (!raw) {
      saveRules(SEED_RULES);
      return SEED_RULES;
    }
    return JSON.parse(raw);
  } catch (e) {
    return SEED_RULES;
  }
}

export function saveRules(rules: WorldRule[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(rules));
  } catch (e) {
    console.error('Failed to save rules:', e);
  }
}

export function loadTimeline(): TimelineEvent[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TIMELINE);
    if (!raw) {
      saveTimeline(SEED_TIMELINE);
      return SEED_TIMELINE;
    }
    return JSON.parse(raw);
  } catch (e) {
    return SEED_TIMELINE;
  }
}

export function saveTimeline(events: TimelineEvent[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TIMELINE, JSON.stringify(events));
  } catch (e) {
    console.error('Failed to save timeline:', e);
  }
}

export function loadWorldState(): WorldState {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WORLD_STATE);
    if (!raw) {
      saveWorldState(INITIAL_WORLD_STATE);
      return INITIAL_WORLD_STATE;
    }
    return JSON.parse(raw);
  } catch (e) {
    return INITIAL_WORLD_STATE;
  }
}

export function saveWorldState(state: WorldState): void {
  try {
    localStorage.setItem(STORAGE_KEYS.WORLD_STATE, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save world state:', e);
  }
}

export function exportBackupData(): SchismBackupData {
  return {
    version: '1.0.0',
    exportedAt: new Date().toISOString(),
    worldState: loadWorldState(),
    entries: loadEntries(),
    zones: loadZones(),
    routes: loadRoutes(),
    factions: loadFactions(),
    rules: loadRules(),
    timeline: loadTimeline(),
  };
}

export function restoreBackupData(data: SchismBackupData): void {
  if (!data || !Array.isArray(data.entries)) {
    throw new Error('Invalid backup schema');
  }
  if (data.worldState) saveWorldState(data.worldState);
  if (data.entries) saveEntries(data.entries);
  if (data.zones) saveZones(data.zones);
  if (data.routes) saveRoutes(data.routes);
  if (data.factions) saveFactions(data.factions);
  if (data.rules) saveRules(data.rules);
  if (data.timeline) saveTimeline(data.timeline);
}

export function resetToSeedCanon(): void {
  saveEntries(SEED_ENTRIES);
  saveZones(SEED_ZONES);
  saveRoutes(SEED_ROUTES);
  saveFactions(SEED_FACTIONS);
  saveRules(SEED_RULES);
  saveTimeline(SEED_TIMELINE);
  saveWorldState(INITIAL_WORLD_STATE);
}
