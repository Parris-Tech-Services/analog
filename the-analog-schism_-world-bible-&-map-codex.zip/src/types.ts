export type LoreCategory =
  | 'Factions'
  | 'Characters'
  | 'Locations'
  | 'Technology'
  | 'History'
  | 'Culture & Belief'
  | 'Resources & Economy'
  | 'The Blight'
  | 'Concepts';

export type CanonStatus = 'canon' | 'provisional' | 'in-world-propaganda' | 'restricted';

export interface LoreEntry {
  id: string;
  category: LoreCategory;
  title: string;
  summary: string;
  body: string;
  tags: string[];
  connections: string[]; // Linked LoreEntry IDs
  canonStatus: CanonStatus;
  createdAt: string;
  updatedAt: string;
  layerLocationId?: string;
  zoneId?: string;
}

export type MapLayerId =
  | 'crown'
  | 'midstack'
  | 'works'
  | 'sub-tiers'
  | 'floodline'
  | 'dead-grid'
  | 'outside';

export interface MapLayer {
  id: MapLayerId;
  name: string;
  altitudeRange: string; // e.g. "+500m to +2000m"
  description: string;
  surveillanceLevel: 'Total' | 'High' | 'Moderate' | 'Low' | 'None' | 'Blight-Corrupted';
  techEnvironment: string;
  populationShare: string;
  primaryFaction: string;
  hazardRating: 'Min' | 'Moderate' | 'High' | 'Critical' | 'Lethal';
  accentColor: string;
}

export interface DistrictZone {
  id: string;
  name: string;
  layerId: MapLayerId;
  type: 'corporate' | 'residential' | 'industrial' | 'sub-tier' | 'dead-grid' | 'outside' | 'tribute';
  controllingFaction: string;
  surveillanceLevel: 'Total' | 'High' | 'Moderate' | 'Low' | 'None' | 'Blight-Corrupted';
  techLevel: 'wireless-modern' | 'hybrid' | 'hardwired-analog' | 'dead';
  populationEstimate: string;
  waterStatus: 'Abundant' | 'Rationed' | 'Contaminated' | 'Tapped-Spliced' | 'Critical Shortage';
  riskLevel: 'Safe' | 'Monitored' | 'Hazardous' | 'Lethal';
  description: string;
  linkedEntryIds: string[];
  isSacrificialTribute: boolean;
  coordinates: { x: number; y: number }; // percentage 0-100 on schematic map
}

export interface TransitRoute {
  id: string;
  name: string;
  originZoneId: string;
  destZoneId: string;
  routeType: 'vertical-lift' | 'rail-line' | 'freight-corridor' | 'maintenance-tunnel' | 'water-conduit' | 'secret-fiber-run' | 'checkpoint';
  status: 'active' | 'restricted' | 'damaged' | 'sealed' | 'covert';
  clearanceRequired: string;
  dangerLevel: 'Low' | 'Moderate' | 'High' | 'Extreme';
  controlledBy: string;
  isCovert: boolean;
  description: string;
}

export interface FactionNode {
  id: string;
  name: string;
  category: 'Concord Megacorp' | 'Weaver Movement' | 'AI Entity' | 'Independent';
  ideology: string;
  motto: string;
  primaryLayer: MapLayerId;
  controlledDistricts: string[];
  relationships: {
    targetFactionId: string;
    relationType: 'allied' | 'cold-war' | 'hostile' | 'proxy-war' | 'secret-tribute' | 'uneasy-truce';
    notes: string;
  }[];
  unforgivableAct: string;
  endgameGoal: string;
  linkedEntryId: string;
}

export interface WorldRule {
  id: string;
  title: string;
  domain: 'Technology' | 'Blight' | 'Resource' | 'Society & Law' | 'Geography';
  hardConstraint: string;
  consequences: string;
  exceptionsOrLoopholes: string;
}

export interface TimelineEvent {
  id: string;
  era: 'Pre-Blight' | 'The Grey Hour' | 'Grid Collapse' | 'Emergency Powers' | 'Sub-Tier Rise' | 'First Conflict' | 'Present Day';
  yearOffset: string; // e.g. "11 Years Ago" or "Present Day"
  title: string;
  summary: string;
  details: string;
  impactLevel: 'Cataclysmic' | 'Major' | 'Regional' | 'Local';
  linkedEntryIds: string[];
}

export interface WorldState {
  cleanWaterCapacity: number; // percentage 0-100 (e.g. 18.4% critical)
  node04Status: 'Discovered - Unverified' | 'Decrypted by Archivists' | 'Targeted by Halcyon' | 'Fracturing Weavers';
  sacrificedDistrictCount: number; // e.g. 4 zones
  activeConflictsCount: number;
}
