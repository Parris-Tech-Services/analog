/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TerminalHeader } from './components/TerminalHeader';
import { Dashboard } from './components/Dashboard';
import { MapHub } from './components/MapHub';
import { LoreCodex } from './components/LoreCodex';
import { FactionGraph } from './components/FactionGraph';
import { RulesEngine } from './components/RulesEngine';
import { TimelineTracker } from './components/TimelineTracker';
import { CampaignView } from './components/CampaignView';
import { CityWalkGame } from './components/CityWalkGame';

import {
  LoreEntry,
  DistrictZone,
  TransitRoute,
  FactionNode,
  WorldRule,
  TimelineEvent,
  WorldState
} from './types';

import {
  loadEntries,
  saveEntries,
  loadZones,
  saveZones,
  loadRoutes,
  saveRoutes,
  loadFactions,
  saveFactions,
  loadRules,
  saveRules,
  loadTimeline,
  saveTimeline,
  loadWorldState,
  saveWorldState
} from './lib/storage';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'map' | 'codex' | 'factions' | 'rules' | 'timeline' | 'campaign' | 'walk'>('walk');
  const [theme, setTheme] = useState<'emerald' | 'cyan' | 'amber'>('emerald');
  const [scanlines, setScanlines] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState('');

  // Loaded State
  const [entries, setEntries] = useState<LoreEntry[]>([]);
  const [zones, setZones] = useState<DistrictZone[]>([]);
  const [routes, setRoutes] = useState<TransitRoute[]>([]);
  const [factions, setFactions] = useState<FactionNode[]>([]);
  const [rules, setRules] = useState<WorldRule[]>([]);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [worldState, setWorldState] = useState<WorldState>({
    cleanWaterCapacity: 18.4,
    node04Status: 'Discovered - Unverified',
    sacrificedDistrictCount: 4,
    activeConflictsCount: 7,
  });

  const [selectedEntryId, setSelectedEntryId] = useState<string | null>(null);

  const refreshAllData = () => {
    setEntries(loadEntries());
    setZones(loadZones());
    setRoutes(loadRoutes());
    setFactions(loadFactions());
    setRules(loadRules());
    setTimeline(loadTimeline());
    setWorldState(loadWorldState());
  };

  useEffect(() => {
    refreshAllData();
  }, []);

  const handleSaveEntry = (updated: Partial<LoreEntry>) => {
    if (!updated.id) return;

    const existingIdx = entries.findIndex((e) => e.id === updated.id);
    let next: LoreEntry[];

    if (existingIdx >= 0) {
      next = [...entries];
      next[existingIdx] = { ...next[existingIdx], ...updated } as LoreEntry;
    } else {
      next = [updated as LoreEntry, ...entries];
    }

    setEntries(next);
    saveEntries(next);
    setSelectedEntryId(updated.id);
  };

  const handleDeleteEntry = (id: string) => {
    const next = entries.filter((e) => e.id !== id);
    setEntries(next);
    saveEntries(next);
  };

  const handleSelectEntryObject = (entry: LoreEntry) => {
    setSelectedEntryId(entry.id);
    setActiveTab('codex');
  };

  const themeWrapperBg = {
    emerald: 'bg-slate-950 text-slate-100 selection:bg-emerald-500 selection:text-slate-950',
    cyan: 'bg-slate-950 text-slate-100 selection:bg-sky-500 selection:text-slate-950',
    amber: 'bg-slate-950 text-slate-100 selection:bg-amber-500 selection:text-slate-950',
  }[theme];

  return (
    <div className={`min-h-screen font-sans ${themeWrapperBg} relative antialiased`}>
      {/* Optional CRT Scanlines Effect Overlay */}
      {scanlines && (
        <div
          className="fixed inset-0 pointer-events-none z-50 opacity-[0.03] mix-blend-overlay"
          style={{
            backgroundImage:
              'linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06))',
            backgroundSize: '100% 3px, 6px 100%',
          }}
        />
      )}

      {/* Terminal Header */}
      <TerminalHeader
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        theme={theme}
        setTheme={setTheme}
        scanlines={scanlines}
        setScanlines={setScanlines}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onRefreshData={refreshAllData}
      />

      {/* Main View Area */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === 'dashboard' && (
          <Dashboard
            worldState={worldState}
            entries={entries}
            zones={zones}
            factions={factions}
            onNavigateTab={setActiveTab}
            onSelectEntry={handleSelectEntryObject}
          />
        )}

        {activeTab === 'map' && (
          <MapHub
            zones={zones}
            routes={routes}
            entries={entries}
            onSelectEntry={handleSelectEntryObject}
          />
        )}

        {activeTab === 'codex' && (
          <LoreCodex
            entries={entries}
            onSaveEntry={handleSaveEntry}
            onDeleteEntry={handleDeleteEntry}
            selectedEntryId={selectedEntryId}
            onSelectEntryId={setSelectedEntryId}
          />
        )}

        {activeTab === 'factions' && (
          <FactionGraph
            factions={factions}
            entries={entries}
            onSelectEntry={handleSelectEntryObject}
          />
        )}

        {activeTab === 'rules' && <RulesEngine rules={rules} />}

        {activeTab === 'timeline' && (
          <TimelineTracker
            events={timeline}
            entries={entries}
            onSelectEntry={handleSelectEntryObject}
          />
        )}

        {activeTab === 'campaign' && (
          <CampaignView
            entries={entries}
            onSelectEntry={handleSelectEntryObject}
          />
        )}

        {activeTab === 'walk' && (
          <CityWalkGame
            entries={entries}
            onSelectEntry={handleSelectEntryObject}
          />
        )}
      </main>

      {/* Terminal Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 font-mono text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="space-y-0.5">
            <p className="text-slate-400 font-bold">THE ANALOG SCHISM // TERMINAL NODE 04</p>
            <p className="text-[11px] text-slate-500">
              Recovered Veyra World Bible & 100% Lore Map System. Hardwired Analog Connection.
            </p>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>CANON: VERIFIED</span>
            <span>BLIGHT: CONTAINED</span>
            <span>WATER: 18.4%</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
