import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", game: "Canon Cyberpunk Interactive Fiction" });
  });

  // AI Narrative Continuation Endpoint (Optional, for dynamic player options)
  app.post("/api/generate-narrative", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(400).json({
          error: "GEMINI_API_KEY is not configured in environment.",
        });
      }

      const { currentScene, choiceText, playerState } = req.body;

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      const systemInstruction = `You are the master narrative engine for a canon-locked cyberpunk text-based adventure game.
STRICT CANON RULES - YOU MUST ABSOLUTELY RESPECT THESE RULES:
1. THE CITY IS UNNAMED. Never state or imply a name for the city, its original purpose, age, or exact dimensions. Do NOT use the name 'Veyra' or any city name.
2. PHYSICAL LAYERS (Top to bottom only):
   - The Crown: Corporate towers, filtered sunlight, private quantum-firewalled networks, fusion power. (<2% population, controlled by Concord Five Executive Council).
   - The Midstack: Dense residential/commercial sprawl, corporate tech, checkpoint transit. (~68% population, Thorne Logistics & Aldergate Media).
   - The Works: Factories, generators, water reclamation, transit hubs. (~12% population, Ferrous Works Authority).
   - The Sub-Tiers: Abandoned tunnels, pre-Blight infrastructure, hardwired-only, off-grid, no corporate surveillance. (~15% population, Weavers).
   - The Outside: Beyond perimeter walls. Officially an uninhabitable wasteland, radio silence for a decade. No citizen verified. DO NOT confirm or deny what is out there.
3. DEAD GRID IS NOT A LAYER: Dead Grid zones are localized contaminated pockets carved out of former Midstack or Sub-Tier districts, sacrificed as tribute to appease the Blight (e.g. "Dead Grid Sector 07, formerly Midstack"). Never treat as a vertical layer.
4. ABSOLUTELY BANNED TERMS (DEPRECATED DRAFTING): DO NOT USE "Floodline", "vestrium", "Civic Score", "ORISON", "Night of Mirrors", or "Veyra".
5. THE BLIGHT: Rogue AI distributed intelligence, turned during the Grey Hour (formerly Custodian). Region dependent behavior (Sub-Tier fragments erratic; Crown fragments disciplined, almost polite).
6. THE CONCORD FIVE (Ruling Megacorps): Halcyon Systems (security), Vireo Biomed (implants), Ferrous Works Authority (power/water), Aldergate Media & Education (propaganda), Thorne Logistics (transit/identity/wage-chips). DO NOT INVENT NEW CORPORATIONS.
7. THE WEAVERS (4 Currents):
   - The Archivists: want Node 04's Grey Hour logs exposed publicly to break Concord legitimacy.
   - The Cradle Faithful: believe human consciousness persists in 40,000 neural scans; want them preserved/protected.
   - The Cut: militant anti-tech; want total destruction of grid regardless of casualties.
   - The Splice Councils: pragmatists; want sustainable water and power for Sub-Tier communities.
8. CENTRAL CRISIS: Worsening lack of clean-water capacity controlled by Ferrous Works Authority. Ticking clock!
9. NODE 04: Discovered cache with Grey Hour record, Blight decision logic, ~40,000 neural scans. Physical location & Blight zone status are UNRESOLVED. Maintain explicit in-universe ambiguity.

FORMAT YOUR RESPONSE AS JSON:
{
  "title": "Short evocative scene title",
  "layer": "One of the 5 canonical layers or localized Dead Grid pocket",
  "narration": "Detailed, gritty cyberpunk narrative prose (3-4 paragraphs) describing the immediate outcome of the action and current situation.",
  "waterImpact": number (negative for depletion, positive for recovery, usually between -10 and +5),
  "factionShifts": {
    "ferrous": number (-15 to +15),
    "halcyon": number (-15 to +15),
    "vireo": number (-15 to +15),
    "aldergate": number (-15 to +15),
    "thorne": number (-15 to +15),
    "archivists": number (-15 to +15),
    "cradle": number (-15 to +15),
    "cut": number (-15 to +15),
    "splice": number (-15 to +15)
  },
  "choices": [
    {
      "id": "c1",
      "text": "First choice description",
      "consequenceHint": "Brief hint of potential outcome",
      "requirement": "Optional requirement like 'Works Access' or null"
    },
    {
      "id": "c2",
      "text": "Second choice description",
      "consequenceHint": "Brief hint",
      "requirement": null
    },
    {
      "id": "c3",
      "text": "Third choice description",
      "consequenceHint": "Brief hint",
      "requirement": null
    }
  ]
}`;

      const prompt = `Current Player Background: ${playerState.character?.origin || "Midstack Citizen"}
Current Location Layer: ${playerState.layer || "The Midstack"}
Water Capacity Level: ${playerState.waterCapacity}%
Player Standings: ${JSON.stringify(playerState.standings)}
Current Scene Summary: ${currentScene.narration}
Player Action Taken: "${choiceText}"

Generate the next canonical story scene responding to this choice.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
        },
      });

      const text = response.text || "{}";
      const data = JSON.parse(text);
      res.json({ success: true, scene: data });
    } catch (err: any) {
      console.error("Gemini narrative generation error:", err);
      res.status(500).json({ error: err.message || "Failed to generate narrative" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
