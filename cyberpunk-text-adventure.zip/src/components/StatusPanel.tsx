import React from 'react';
import { X, Shield, Droplet, Cpu, Package, Users, FileText } from 'lucide-react';
import { FactionStanding, CharacterState, Layer } from '../types';

interface StatusPanelProps {
  isOpen: boolean;
  onClose: () => void;
  character: CharacterState | null;
  currentLayer: Layer;
  waterCapacity: number;
  standings: FactionStanding;
}

export const StatusPanel: React.FC<StatusPanelProps> = ({
  isOpen,
  onClose,
  character,
  currentLayer,
  waterCapacity,
  standings,
}) => {
  if (!isOpen) return null;

  const getStandingBadge = (val: number) => {
    if (val >= 20) return { text: 'LOYAL', color: 'bg-[#00FF41]/10 border-[#00FF41]/40 text-[#00FF41]' };
    if (val >= 10) return { text: 'FAVORABLE', color: 'bg-[#4CC9F0]/10 border-[#4CC9F0]/40 text-[#4CC9F0]' };
    if (val >= 0) return { text: 'NEUTRAL', color: 'bg-[#1A1D24] border-[#2D333D] text-[#707880]' };
    if (val >= -15) return { text: 'SUSPICIOUS', color: 'bg-[#F27D26]/10 border-[#F27D26]/40 text-[#F27D26]' };
    return { text: 'HOSTILE', color: 'bg-[#FF3B3B]/10 border-[#FF3B3B]/40 text-[#FF3B3B]' };
  };

  const concordFiveList = [
    { key: 'ferrous', name: 'Ferrous Works Authority', role: 'Power & Water Reclamation', val: standings.ferrous },
    { key: 'halcyon', name: 'Halcyon Systems', role: 'Security & Enforcers', val: standings.halcyon },
    { key: 'vireo', name: 'Vireo Biomed', role: 'Neural Implants & Bio-tech', val: standings.vireo },
    { key: 'aldergate', name: 'Aldergate Media & Education', role: 'Propaganda & Censorship', val: standings.aldergate },
    { key: 'thorne', name: 'Thorne Logistics', role: 'Transit, Identity & Wage-Chips', val: standings.thorne },
  ];

  const weaverCurrentsList = [
    { key: 'archivists', name: 'The Archivists', goal: 'Expose Node 04 Grey Hour Logs', val: standings.archivists },
    { key: 'cradle', name: 'The Cradle Faithful', goal: 'Protect 40,000 Neural Scans', val: standings.cradle },
    { key: 'cut', name: 'The Cut', goal: 'Militant Total Grid Destruction', val: standings.cut },
    { key: 'splice', name: 'The Splice Councils', goal: 'Sustainable Sub-Tier Water & Power', val: standings.splice },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-[#0A0B0E]/90 backdrop-blur-md flex items-center justify-center p-4 font-mono select-none">
      <div className="w-full max-w-4xl max-h-[90vh] bg-[#12141A] border border-[#2D333D] rounded-sm shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-[#0A0B0E] border-b border-[#2D333D] flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Shield className="w-5 h-5 text-[#4CC9F0]" />
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              CHARACTER & CITY STATUS MONITOR
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#707880] hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Character Summary */}
          {character && (
            <div className="bg-[#0A0B0E] border border-[#2D333D] p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] text-[#4CC9F0] uppercase tracking-widest font-bold">
                  OPERATIVE DOSSIER
                </span>
                <h3 className="text-lg font-bold text-slate-100">{character.name}</h3>
                <p className="text-xs text-[#F27D26]">{character.title}</p>
              </div>
              <div className="border-t md:border-t-0 md:border-l border-[#2D333D] pt-3 md:pt-0 md:pl-4 max-w-md">
                <span className="text-[10px] text-[#707880] uppercase">ACTIVE PERK:</span>
                <p className="text-xs text-slate-300 mt-1">{character.perk}</p>
              </div>
            </div>
          )}

          {/* Water Crisis & Layer Readout */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Water Meter Detail */}
            <div className="bg-[#0A0B0E] border border-[#2D333D] p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-[#FF3B3B] uppercase font-bold flex items-center space-x-1.5">
                  <Droplet className="w-4 h-4 text-[#FF3B3B]" />
                  <span>CLEAN-WATER CAPACITY</span>
                </span>
                <span className="text-sm font-bold text-[#FF3B3B]">{waterCapacity}%</span>
              </div>
              <div className="w-full h-2.5 bg-[#1A1D24] border border-[#2D333D] overflow-hidden mb-3">
                <div
                  className={`h-full transition-all duration-500 ${
                    waterCapacity >= 60
                      ? 'bg-[#4CC9F0]'
                      : waterCapacity >= 35
                      ? 'bg-[#F27D26]'
                      : 'bg-[#FF3B3B] animate-pulse'
                  }`}
                  style={{ width: `${Math.max(0, Math.min(100, waterCapacity))}%` }}
                />
              </div>
              <p className="text-xs text-[#707880]">
                Controlled by Ferrous Works Authority. If clean water capacity falls below critical threshold, public rationing fails and filtration membranes calcify permanently.
              </p>
            </div>

            {/* Current Layer Detail */}
            <div className="bg-[#0A0B0E] border border-[#2D333D] p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-[#4CC9F0] uppercase font-bold flex items-center space-x-1.5">
                  <Cpu className="w-4 h-4 text-[#4CC9F0]" />
                  <span>CURRENT PHYSICAL LOCATION</span>
                </span>
              </div>
              <p className="text-base font-bold text-slate-100 uppercase mb-1">{currentLayer}</p>
              <p className="text-xs text-[#707880]">
                {currentLayer.includes('Crown') && 'Filtered sunlight, private quantum firewalls, executive towers (<2% pop).'}
                {currentLayer.includes('Midstack') && 'Dense residential sprawl, corporate tech, checkpoint transit (~68% pop).'}
                {currentLayer.includes('Works') && 'Factories, water reclamation plants, heavy turbines (~12% pop).'}
                {currentLayer.includes('Sub-Tiers') && 'Hardwired-only tunnels, pre-Blight infrastructure, off the grid (~15% pop).'}
                {currentLayer.includes('Dead Grid') && 'Localized contaminated pocket sacrificed as tribute to appease the Blight.'}
                {currentLayer.includes('Outside') && 'Beyond perimeter walls. Radio silence for a decade.'}
              </p>
            </div>
          </div>

          {/* Faction Standings Grid */}
          <div className="space-y-4">
            <h4 className="text-xs text-[#4CC9F0] uppercase tracking-widest font-bold flex items-center space-x-2">
              <Users className="w-4 h-4 text-[#4CC9F0]" />
              <span>FACTION STANDING MATRIX</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Concord Five */}
              <div className="bg-[#0A0B0E] border border-[#2D333D] p-4 space-y-3">
                <h5 className="text-xs text-[#4CC9F0] uppercase font-bold border-b border-[#2D333D] pb-2">
                  THE CONCORD FIVE (RULING MEGACORPS)
                </h5>
                <div className="space-y-2.5">
                  {concordFiveList.map((corp) => {
                    const badge = getStandingBadge(corp.val);
                    return (
                      <div key={corp.key} className="flex items-center justify-between text-xs">
                        <div>
                          <p className="text-slate-200 font-bold">{corp.name}</p>
                          <p className="text-[#707880] text-[10px]">{corp.role}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-[#707880] text-[11px]">{corp.val > 0 ? `+${corp.val}` : corp.val}</span>
                          <span className={`px-2 py-0.5 border text-[10px] font-bold ${badge.color}`}>
                            {badge.text}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Weaver Currents */}
              <div className="bg-[#0A0B0E] border border-[#2D333D] p-4 space-y-3">
                <h5 className="text-xs text-[#00FF41] uppercase font-bold border-b border-[#2D333D] pb-2">
                  THE WEAVERS (RESISTANCE CURRENTS)
                </h5>
                <div className="space-y-2.5">
                  {weaverCurrentsList.map((weaver) => {
                    const badge = getStandingBadge(weaver.val);
                    return (
                      <div key={weaver.key} className="flex items-center justify-between text-xs">
                        <div>
                          <p className="text-slate-200 font-bold">{weaver.name}</p>
                          <p className="text-[#707880] text-[10px]">{weaver.goal}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-[#707880] text-[11px]">{weaver.val > 0 ? `+${weaver.val}` : weaver.val}</span>
                          <span className={`px-2 py-0.5 border text-[10px] font-bold ${badge.color}`}>
                            {badge.text}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Inventory Items */}
          <div className="space-y-3">
            <h4 className="text-xs text-[#4CC9F0] uppercase tracking-widest font-bold flex items-center space-x-2">
              <Package className="w-4 h-4 text-[#4CC9F0]" />
              <span>ACQUIRED EQUIPMENT & DATA FRAGMENTS</span>
            </h4>

            {character?.inventory.length === 0 ? (
              <p className="text-xs text-[#707880] italic bg-[#0A0B0E] p-4 border border-[#2D333D]">
                No inventory items carried.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {character?.inventory.map((item) => (
                  <div
                    key={item.id}
                    className="bg-[#0A0B0E] border border-[#2D333D] p-3 flex items-start space-x-3"
                  >
                    <div className="p-2 bg-[#1A1D24] border border-[#4CC9F0]/30 text-[#4CC9F0]">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <p className="text-xs font-bold text-slate-200">{item.name}</p>
                        <span className="px-1.5 py-0.2 bg-[#1A1D24] text-[#707880] text-[9px]">
                          {item.tag}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#707880] mt-1">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

