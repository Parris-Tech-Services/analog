import React, { useState } from 'react';
import { StoryNode, Choice, ChoiceRequirement, LogEntry, CharacterState } from '../types';
import { ChevronRight, Lock, AlertCircle, History, Sparkles, Droplet, ArrowRight, BookOpen } from 'lucide-react';
import { audioSynth } from '../utils/AudioSynth';

interface StoryNarratorProps {
  currentNode: StoryNode;
  waterCapacity: number;
  standings: Record<string, number>;
  character: CharacterState | null;
  onSelectChoice: (choice: Choice) => void;
  logs: LogEntry[];
  isAiLoading: boolean;
  isAiMode: boolean;
  onDynamicAiChoice: (userPrompt: string) => void;
  onOpenCodex: () => void;
  onOpenSave: () => void;
  onRestart: () => void;
}

export const StoryNarrator: React.FC<StoryNarratorProps> = ({
  currentNode,
  waterCapacity,
  standings,
  character,
  onSelectChoice,
  logs,
  isAiLoading,
  isAiMode,
  onDynamicAiChoice,
  onOpenCodex,
  onOpenSave,
  onRestart,
}) => {
  const [showLogDrawer, setShowLogDrawer] = useState(false);
  const [customAiPrompt, setCustomAiPrompt] = useState('');

  // Requirement check helper
  const checkRequirement = (req?: ChoiceRequirement): { met: boolean; reason: string } => {
    if (!req) return { met: true, reason: '' };

    if (req.type === 'water') {
      const requiredVal = Number(req.value || 0);
      const met = waterCapacity >= requiredVal;
      return {
        met,
        reason: met ? '' : `Requires Clean-Water Capacity ≥ ${requiredVal}% (Current: ${waterCapacity}%)`,
      };
    }

    if (req.type === 'faction' && req.key) {
      const currentVal = standings[req.key] || 0;
      const requiredVal = Number(req.value || 0);
      const met = currentVal >= requiredVal;
      return {
        met,
        reason: met ? '' : `Requires ${req.label} (Current: ${currentVal})`,
      };
    }

    if (req.type === 'origin' && req.key) {
      const met = character?.origin === req.key;
      return {
        met,
        reason: met ? '' : `Requires Background Origin: ${req.label}`,
      };
    }

    return { met: true, reason: '' };
  };

  const handleCustomAiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customAiPrompt.trim() || isAiLoading) return;
    audioSynth.playChoiceBeep();
    onDynamicAiChoice(customAiPrompt.trim());
    setCustomAiPrompt('');
  };

  // Calculations for Concord progress bars & status
  const getCorpStatus = (val: number) => {
    if (val >= 15) return { status: 'LOYAL', color: 'text-[#00FF41]', barColor: 'bg-[#00FF41]', width: '88%' };
    if (val >= 5) return { status: 'FAVORABLE', color: 'text-[#4CC9F0]', barColor: 'bg-[#4CC9F0]', width: '65%' };
    if (val >= -5) return { status: 'NEUTRAL', color: 'text-[#707880]', barColor: 'bg-[#707880]', width: '45%' };
    if (val >= -15) return { status: 'SUSPECT', color: 'text-[#F27D26]', barColor: 'bg-[#F27D26]', width: '72%' };
    return { status: 'ALERT', color: 'text-[#FF3B3B]', barColor: 'bg-[#FF3B3B]', width: '90%' };
  };

  // Weaver standing block matrix count (0-5 blocks)
  const getWeaverBlocks = (val: number) => {
    const blocks = Math.max(0, Math.min(5, Math.floor((val + 10) / 4)));
    return blocks;
  };

  // Water meter SVG calculations
  // Circumference of r=58 circle is 2 * PI * 58 ≈ 364.42
  const circumference = 364.42;
  const strokeDashoffset = circumference - (circumference * Math.max(0, Math.min(100, waterCapacity))) / 100;
  const isWaterCritical = waterCapacity < 35;
  const waterColor = isWaterCritical ? '#FF3B3B' : waterCapacity >= 60 ? '#4CC9F0' : '#F27D26';

  return (
    <div className="w-full font-mono text-[#B0B8C1] flex flex-col gap-4 select-none">
      {/* 3-COLUMN HIGH DENSITY MAIN GRID */}
      <div className="flex flex-col lg:flex-row gap-4 items-stretch">
        
        {/* LEFT SIDEBAR: FACTIONS */}
        <div className="w-full lg:w-56 flex flex-col gap-4 shrink-0">
          {/* CONCORD FIVE INFLUENCE */}
          <div className="border border-[#2D333D] bg-[#12141A] p-3 rounded-sm">
            <h3 className="text-[10px] text-[#4CC9F0] font-bold mb-3 border-b border-[#2D333D] pb-1 uppercase tracking-wider">
              CONCORD FIVE INFLUENCE
            </h3>
            <div className="space-y-3">
              {[
                { name: 'HALCYON', key: 'halcyon', baseVal: 0 },
                { name: 'VIREO BIOMED', key: 'vireo', baseVal: 0 },
                { name: 'FERROUS WORKS', key: 'ferrous', baseVal: 0 },
                { name: 'ALDERGATE', key: 'aldergate', baseVal: 0 },
                { name: 'THORNE LOGS.', key: 'thorne', baseVal: 0 },
              ].map((corp) => {
                const val = standings[corp.key] || corp.baseVal;
                const info = getCorpStatus(val);
                return (
                  <div key={corp.key} className="group">
                    <div className="flex justify-between text-[9px] mb-1">
                      <span className="text-slate-200">{corp.name}</span>
                      <span className={`font-bold ${info.color}`}>{info.status}</span>
                    </div>
                    <div className="h-1.5 bg-[#1A1D24] w-full rounded-xs overflow-hidden">
                      <div className={`h-full transition-all duration-500 ${info.barColor}`} style={{ width: info.width }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* WEAVER STANDING */}
          <div className="border border-[#2D333D] bg-[#12141A] p-3 rounded-sm flex-1">
            <h3 className="text-[10px] text-[#00FF41] font-bold mb-3 border-b border-[#2D333D] pb-1 uppercase tracking-wider">
              WEAVER STANDING
            </h3>
            <div className="space-y-3.5">
              {[
                { name: 'ARCHIVISTS', key: 'archivists' },
                { name: 'CRADLE FAITHFUL', key: 'cradle' },
                { name: 'THE CUT', key: 'cut' },
                { name: 'SPLICE COUNCILS', key: 'splice' },
              ].map((weaver) => {
                const val = standings[weaver.key] || 0;
                const blockCount = getWeaverBlocks(val);
                return (
                  <div key={weaver.key}>
                    <div className="flex justify-between text-[9px] text-[#707880] mb-1 italic">
                      <span>{weaver.name}</span>
                      <span className="text-[#00FF41]">{val > 0 ? `+${val}` : val}</span>
                    </div>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((idx) => (
                        <div
                          key={idx}
                          className={`h-2 flex-1 rounded-xs transition-colors ${
                            idx <= blockCount
                              ? weaver.key === 'cut'
                                ? 'bg-[#FF3B3B]'
                                : 'bg-[#00FF41]'
                              : 'bg-[#1A1D24]'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* CENTER: NARRATIVE & DECISIONS */}
        <div className="flex-1 border border-[#2D333D] bg-[#0A0B0E] flex flex-col p-5 sm:p-6 gap-6 relative rounded-sm shadow-xl min-h-[480px]">
          {/* Decorative Corner Brackets */}
          <div className="absolute top-0 right-0 w-16 h-16 border-t border-r border-[#4CC9F0] opacity-20 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-16 h-16 border-b border-l border-[#4CC9F0] opacity-20 pointer-events-none" />

          {/* Scene Header Rail */}
          <div className="flex items-center justify-between border-b border-[#2D333D] pb-3">
            <div className="flex items-center space-x-2 text-xs">
              <span className="w-2 h-2 rounded-full bg-[#4CC9F0] animate-pulse" />
              <span className="text-[#4CC9F0] font-bold uppercase">{currentNode.layer}</span>
              <span className="text-[#707880]">•</span>
              <span className="text-[#F27D26]">ACT {currentNode.act}</span>
            </div>
            <button
              onClick={() => {
                audioSynth.playKeyClick();
                setShowLogDrawer(true);
              }}
              className="flex items-center space-x-1.5 px-2 py-1 bg-[#12141A] border border-[#2D333D] hover:border-[#4CC9F0] text-[10px] text-[#B0B8C1] transition-colors"
            >
              <History className="w-3.5 h-3.5 text-[#F27D26]" />
              <span>LOG HISTORY ({logs.length})</span>
            </button>
          </div>

          {/* Scene Title */}
          <h2 className="text-lg sm:text-xl font-bold text-[#D0D7DE] uppercase tracking-wide border-b border-[#2D333D] pb-2">
            {currentNode.title}
          </h2>

          {/* Narrative Prose */}
          <div className="flex-1 font-serif text-base sm:text-lg leading-relaxed text-[#D0D7DE] space-y-4">
            {currentNode.narration.map((paragraph, idx) => (
              <p key={idx} className="leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Choices Grid */}
          <div className="grid grid-cols-1 gap-3 pt-4 border-t border-[#2D333D]">
            {isAiLoading ? (
              <div className="p-6 border border-purple-500/40 bg-purple-950/20 text-center space-y-2 rounded-sm">
                <Sparkles className="w-6 h-6 text-purple-400 animate-spin mx-auto" />
                <p className="text-xs text-purple-300 animate-pulse font-mono">
                  GEMINI AI IS GENERATING CANON-LOCKED CONTINUATION...
                </p>
              </div>
            ) : (
              currentNode.choices.map((choice, index) => {
                const reqStatus = checkRequirement(choice.requirement);
                const indexNum = String(index + 1).padStart(2, '0');

                return (
                  <button
                    key={choice.id}
                    disabled={!reqStatus.met}
                    onClick={() => {
                      audioSynth.playChoiceBeep();
                      onSelectChoice(choice);
                    }}
                    className={`p-3.5 text-left border transition-all flex items-center justify-between group font-mono text-xs sm:text-sm rounded-sm ${
                      reqStatus.met
                        ? 'border-[#2D333D] hover:border-[#4CC9F0] bg-[#12141A] hover:bg-[#4CC9F0]/10 text-[#D0D7DE] cursor-pointer'
                        : 'border-[#FF3B3B]/40 bg-[#FF3B3B]/5 text-[#707880] opacity-60 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-start space-x-3 flex-1 pr-2">
                      <span className="text-[#4CC9F0] font-bold text-xs shrink-0 mt-0.5">[{indexNum}]</span>
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          {!reqStatus.met && <Lock className="w-3.5 h-3.5 text-[#FF3B3B] shrink-0" />}
                          <span className="group-hover:text-white transition-colors">{choice.text}</span>
                        </div>
                        {!reqStatus.met && (
                          <p className="text-[10px] text-[#FF3B3B] flex items-center space-x-1">
                            <AlertCircle className="w-3 h-3" />
                            <span>{reqStatus.reason}</span>
                          </p>
                        )}
                      </div>
                    </div>

                    {choice.consequenceHint && reqStatus.met && (
                      <span className="text-[10px] text-[#F27D26] uppercase opacity-80 group-hover:opacity-100 hidden sm:inline shrink-0">
                        {choice.consequenceHint}
                      </span>
                    )}
                  </button>
                );
              })
            )}

            {/* AI Custom Action Input */}
            {isAiMode && (
              <form onSubmit={handleCustomAiSubmit} className="mt-2 p-3 border border-purple-500/40 bg-purple-950/20 space-y-2 rounded-sm">
                <div className="flex items-center space-x-2 text-xs text-purple-300 font-bold">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>AI GEMINI FREEFORM DIRECTIVE PROMPT</span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customAiPrompt}
                    onChange={(e) => setCustomAiPrompt(e.target.value)}
                    placeholder="Type custom action directive..."
                    className="flex-1 px-3 py-1.5 bg-[#0A0B0E] border border-purple-900 text-xs font-mono text-slate-100 focus:outline-none focus:border-purple-400"
                  />
                  <button
                    type="submit"
                    disabled={!customAiPrompt.trim()}
                    className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs"
                  >
                    SUBMIT
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* RIGHT SIDEBAR: RESOURCES & STATUS */}
        <div className="w-full lg:w-64 flex flex-col gap-4 shrink-0">
          
          {/* WATER METER (CIRCULAR GAUGE FROM HIGH DENSITY SPEC) */}
          <div className="border border-[#2D333D] bg-[#12141A] p-4 flex flex-col items-center rounded-sm">
            <h3 className="text-[10px] text-[#FF3B3B] font-bold mb-3 tracking-widest uppercase">
              CLEAN WATER CAPACITY
            </h3>
            <div className="relative w-32 h-32 flex items-center justify-center border-4 border-[#1A1D24] rounded-full">
              <svg className="absolute w-full h-full transform -rotate-90">
                <circle cx="64" cy="64" r="58" fill="transparent" stroke="#1A1D24" strokeWidth="8" />
                <circle
                  cx="64"
                  cy="64"
                  r="58"
                  fill="transparent"
                  stroke={waterColor}
                  strokeWidth="8"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  className="transition-all duration-700"
                />
              </svg>
              <div className="text-center">
                <div className="text-3xl font-bold" style={{ color: waterColor }}>
                  {waterCapacity}%
                </div>
                <div className="text-[8px] opacity-60 uppercase font-bold tracking-wider">
                  {isWaterCritical ? 'CRITICAL' : waterCapacity >= 60 ? 'OPTIMAL' : 'DEGRADED'}
                </div>
              </div>
            </div>
            <div className="mt-3 text-[9px] text-[#FF3B3B] animate-pulse uppercase tracking-tight text-center">
              Estimated Zero-Point: {Math.max(1, Math.floor(waterCapacity / 2))} Cycles
            </div>
          </div>

          {/* CURRENT PROFILE */}
          <div className="border border-[#2D333D] bg-[#12141A] p-4 flex-1 rounded-sm space-y-3">
            <h3 className="text-[10px] text-[#707880] font-bold mb-2 border-b border-[#2D333D] pb-1 uppercase tracking-wider">
              CURRENT PROFILE
            </h3>

            <div>
              <div className="text-[8px] uppercase opacity-40 mb-0.5">Operative / Class</div>
              <div className="text-xs font-bold text-slate-100">{character?.name || 'Unregistered Operative'}</div>
              <div className="text-[10px] text-[#F27D26]">{character?.title || 'Sub-Tier Wanderer'}</div>
            </div>

            <div>
              <div className="text-[8px] uppercase opacity-40 mb-1">Equipped Shards & Items</div>
              {character?.inventory.length === 0 ? (
                <div className="text-[10px] text-[#707880] italic">No items equipped</div>
              ) : (
                <ul className="text-[10px] space-y-1">
                  {character?.inventory.slice(0, 4).map((item) => (
                    <li key={item.id} className="flex items-center gap-1.5 text-slate-200">
                      <span className="text-[#00FF41]">•</span>
                      <span className="truncate">{item.name}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div>
              <div className="text-[8px] uppercase opacity-40 mb-1 flex justify-between">
                <span>Neural Load</span>
                <span className="text-[#4CC9F0]">42%</span>
              </div>
              <div className="w-full bg-[#1A1D24] h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#4CC9F0] h-full w-[42%]" />
              </div>
            </div>
          </div>

          {/* MINI MAP / LOCAL GRID MAP FROM SPEC */}
          <div className="border border-[#2D333D] bg-[#12141A] p-3 h-32 flex flex-col rounded-sm">
            <div className="text-[8px] uppercase opacity-40 mb-2 font-bold tracking-wider">
              LOCAL GRID MAP ({currentNode.layer.toUpperCase()})
            </div>
            <div className="flex-1 grid grid-cols-5 grid-rows-3 gap-1">
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#4CC9F0]/20" />
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#4CC9F0] ring-1 ring-[#4CC9F0] animate-pulse" />
              <div className="bg-[#4CC9F0]/20" />
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#FF3B3B]/40" />
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#4CC9F0]/20" />
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#1A1D24]" />
              <div className="bg-[#1A1D24]" />
            </div>
          </div>

        </div>
      </div>

      {/* FOOTER: COMMAND LINE INTERFACE RAIL FROM HIGH DENSITY SPEC */}
      <div className="h-8 border border-[#2D333D] bg-[#12141A] flex items-center px-4 text-[10px] gap-4 rounded-sm">
        <span className="text-[#00FF41] font-bold">C:\SYSTEM\USR\RUN &gt;</span>
        <span className="animate-pulse text-[#00FF41] font-bold">_</span>
        <div className="ml-auto text-[#707880] hidden sm:flex gap-4">
          <button onClick={onOpenCodex} className="hover:text-[#4CC9F0] transition-colors">[F1] CODEX</button>
          <button onClick={onOpenSave} className="hover:text-[#4CC9F0] transition-colors">[F5] SAVE STATE</button>
          <button onClick={onRestart} className="hover:text-[#FF3B3B] transition-colors">[ESC] LOGOUT</button>
        </div>
      </div>

      {/* LOG HISTORY ARCHIVE DRAWER MODAL */}
      {showLogDrawer && (
        <div className="fixed inset-0 z-50 bg-[#0A0B0E]/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-3xl max-h-[85vh] bg-[#12141A] border border-[#2D333D] rounded-sm shadow-2xl flex flex-col overflow-hidden">
            <div className="px-6 py-4 bg-[#0A0B0E] border-b border-[#2D333D] flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm font-bold text-[#F27D26] uppercase">
                <History className="w-4 h-4" />
                <span>TERMINAL LOG HISTORY ARCHIVE</span>
              </div>
              <button
                onClick={() => setShowLogDrawer(false)}
                className="text-[#707880] hover:text-white text-xs font-mono"
              >
                [ CLOSE ]
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-3">
              {logs.length === 0 ? (
                <p className="text-xs text-[#707880] italic">No log history recorded yet.</p>
              ) : (
                logs.map((log) => (
                  <div key={log.id} className="bg-[#0A0B0E] border border-[#2D333D] p-3 space-y-1">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-[#4CC9F0] font-bold uppercase">{log.title}</span>
                      <span className="text-[#707880]">{log.timestamp}</span>
                    </div>
                    <p className="text-xs text-[#B0B8C1]">{log.text}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

