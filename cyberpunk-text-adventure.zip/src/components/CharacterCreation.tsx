import React, { useState } from 'react';
import { User, Sparkles, ChevronRight } from 'lucide-react';
import { CHARACTER_ORIGINS, OriginDefinition } from '../data/origins';
import { CharacterState, Layer } from '../types';
import { audioSynth } from '../utils/AudioSynth';

interface CharacterCreationProps {
  onStartGame: (character: CharacterState, startLayer: Layer, startNodeId: string) => void;
}

export const CharacterCreation: React.FC<CharacterCreationProps> = ({ onStartGame }) => {
  const [characterName, setCharacterName] = useState('Kaelen Vance');
  const [selectedOrigin, setSelectedOrigin] = useState<OriginDefinition>(CHARACTER_ORIGINS[0]);

  const handleStart = () => {
    audioSynth.playChoiceBeep();
    const character: CharacterState = {
      name: characterName.trim() || 'Unregistered Citizen',
      origin: selectedOrigin.origin,
      title: selectedOrigin.title,
      perk: selectedOrigin.perk,
      description: selectedOrigin.description,
      inventory: selectedOrigin.startingInventory,
    };

    onStartGame(character, selectedOrigin.startLayer as Layer, selectedOrigin.startNodeId);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4 select-none font-mono">
      <div className="w-full max-w-4xl bg-[#12141A] border border-[#2D333D] rounded-sm shadow-2xl p-6 sm:p-8 space-y-8">
        {/* Header */}
        <div className="border-b border-[#2D333D] pb-6 text-center space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#1A1D24] border border-[#4CC9F0]/40 text-[#4CC9F0] text-xs font-bold rounded-xs">
            <Sparkles className="w-3.5 h-3.5" />
            <span>CHARACTER DOSSIER GENERATION</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-100 uppercase tracking-wider">
            INITIALIZE CITIZEN IDENTITY
          </h1>
          <p className="text-xs text-[#707880] max-w-xl mx-auto">
            Select your character background and origin layer within the stratified city. Your background grants starting equipment, unique options, and initial faction standing.
          </p>
        </div>

        {/* Character Name Input */}
        <div className="space-y-2 max-w-md mx-auto">
          <label className="block text-xs font-bold text-[#4CC9F0] uppercase tracking-wider">
            CITIZEN IDENTIFIER / NAME
          </label>
          <div className="relative">
            <User className="w-4 h-4 text-[#707880] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={characterName}
              onChange={(e) => setCharacterName(e.target.value)}
              placeholder="Enter character name..."
              className="w-full pl-10 pr-4 py-2 bg-[#0A0B0E] border border-[#2D333D] text-sm text-slate-100 focus:outline-none focus:border-[#4CC9F0]"
            />
          </div>
        </div>

        {/* Origin Grid */}
        <div className="space-y-4">
          <label className="block text-xs font-bold text-[#B0B8C1] uppercase tracking-wider text-center">
            SELECT BACKGROUND ORIGIN & LAYER
          </label>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {CHARACTER_ORIGINS.map((origin) => {
              const isSelected = selectedOrigin.origin === origin.origin;

              return (
                <div
                  key={origin.origin}
                  onClick={() => {
                    audioSynth.playKeyClick();
                    setSelectedOrigin(origin);
                  }}
                  className={`p-5 rounded-xs border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#4CC9F0]/10 border-[#4CC9F0] shadow-[0_0_12px_rgba(76,201,240,0.2)]'
                      : 'bg-[#0A0B0E] border-[#2D333D] hover:border-[#707880] hover:bg-[#1A1D24]'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <span className="text-[10px] uppercase text-[#4CC9F0] font-bold px-2 py-0.5 bg-[#1A1D24] border border-[#4CC9F0]/40">
                        {origin.startLayer}
                      </span>
                      <h3 className="text-base font-bold text-slate-100 mt-2">{origin.name}</h3>
                      <p className="text-xs text-[#F27D26]">{origin.title}</p>
                    </div>
                    {isSelected && <Sparkles className="w-5 h-5 text-[#4CC9F0] animate-pulse" />}
                  </div>

                  <p className="text-xs text-[#B0B8C1] mb-3 leading-relaxed">{origin.description}</p>

                  {/* Perk */}
                  <div className="bg-[#1A1D24] p-2.5 border border-[#2D333D] text-[11px] text-[#707880]">
                    <span className="text-[#00FF41] font-bold">PERK: </span>
                    <span className="text-slate-300">{origin.perk}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Summary & Confirm Button */}
        <div className="border-t border-[#2D333D] pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-[#707880]">
            <span>SELECTED: </span>
            <span className="text-[#4CC9F0] font-bold">{selectedOrigin.name}</span>
            <span className="mx-2">•</span>
            <span>LAYER: </span>
            <span className="text-[#F27D26] font-bold">{selectedOrigin.startLayer}</span>
          </div>

          <button
            onClick={handleStart}
            className="w-full sm:w-auto px-8 py-3 bg-[#4CC9F0] hover:bg-[#4CC9F0]/80 text-[#0A0B0E] font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition-all shadow-md"
          >
            <span>ENTER THE CITY</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

