import React, { useState, useEffect } from 'react';
import { X, Save, Download, Trash2, Clock, Droplet, Cpu } from 'lucide-react';
import { GameState, SaveSlot } from '../types';

interface SaveLoadModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentState: GameState;
  onLoadState: (loadedState: GameState) => void;
}

const STORAGE_KEY = 'cyberpunk_text_adventure_saves_v1';

export const SaveLoadModal: React.FC<SaveLoadModalProps> = ({
  isOpen,
  onClose,
  currentState,
  onLoadState,
}) => {
  const [slots, setSlots] = useState<Record<string, SaveSlot>>({});
  const [notification, setNotification] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadSlotsFromStorage();
    }
  }, [isOpen]);

  const loadSlotsFromStorage = () => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        setSlots(JSON.parse(raw));
      }
    } catch (e) {
      console.error('Failed to parse saved slots', e);
    }
  };

  const saveToSlot = (slotId: string) => {
    const newSlot: SaveSlot = {
      slotId,
      timestamp: new Date().toLocaleString(),
      characterName: currentState.character?.name || 'Unregistered Citizen',
      act: currentState.act,
      nodeTitle: currentState.currentNodeId,
      waterCapacity: currentState.waterCapacity,
      state: currentState,
    };

    const updated = { ...slots, [slotId]: newSlot };
    setSlots(updated);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      showToast(`Saved session to Slot ${slotId.toUpperCase()}`);
    } catch (e) {
      showToast('Failed to write save to LocalStorage.');
    }
  };

  const loadFromSlot = (slotId: string) => {
    const slot = slots[slotId];
    if (!slot) return;
    onLoadState(slot.state);
    showToast(`Loaded session from Slot ${slotId.toUpperCase()}`);
    onClose();
  };

  const deleteSlot = (slotId: string) => {
    const updated = { ...slots };
    delete updated[slotId];
    setSlots(updated);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      showToast(`Deleted Slot ${slotId.toUpperCase()}`);
    } catch (e) {}
  };

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  if (!isOpen) return null;

  const slotIds = ['auto', 'slot_1', 'slot_2', 'slot_3'];

  return (
    <div className="fixed inset-0 z-50 bg-[#0A0B0E]/90 backdrop-blur-md flex items-center justify-center p-4 font-mono select-none">
      <div className="w-full max-w-2xl bg-[#12141A] border border-[#2D333D] rounded-sm shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-[#0A0B0E] border-b border-[#2D333D] flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Save className="w-5 h-5 text-[#4CC9F0]" />
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              TERMINAL SESSION STORAGE
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#707880] hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notification Banner */}
        {notification && (
          <div className="bg-[#4CC9F0]/10 border-b border-[#4CC9F0]/40 text-[#4CC9F0] text-xs px-4 py-2 text-center">
            {notification}
          </div>
        )}

        {/* Slot List */}
        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {slotIds.map((slotId) => {
            const slot = slots[slotId];
            const isAuto = slotId === 'auto';

            return (
              <div
                key={slotId}
                className="bg-[#0A0B0E] border border-[#2D333D] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-[#4CC9F0] uppercase">
                      {isAuto ? '[ AUTO-SAVE SLOT ]' : `[ MANUAL SLOT ${slotId.replace('slot_', '')} ]`}
                    </span>
                    {slot && (
                      <span className="text-[10px] text-[#707880] flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{slot.timestamp}</span>
                      </span>
                    )}
                  </div>

                  {slot ? (
                    <div className="mt-2 space-y-1 text-xs text-slate-300">
                      <p className="font-bold text-slate-100">
                        {slot.characterName} (Act {slot.act})
                      </p>
                      <div className="flex items-center space-x-3 text-[11px] text-[#707880]">
                        <span className="flex items-center space-x-1">
                          <Cpu className="w-3 h-3 text-[#4CC9F0]" />
                          <span>{slot.state.currentLayer}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Droplet className="w-3 h-3 text-[#FF3B3B]" />
                          <span>Water: {slot.waterCapacity}%</span>
                        </span>
                      </div>
                    </div>
                  ) : (
                    <p className="mt-2 text-xs text-[#707880] italic">
                      Empty Slot — No saved session recorded.
                    </p>
                  )}
                </div>

                {/* Slot Action Buttons */}
                <div className="flex items-center space-x-2 shrink-0">
                  {!isAuto && (
                    <button
                      onClick={() => saveToSlot(slotId)}
                      className="flex items-center space-x-1 px-3 py-1.5 border border-[#4CC9F0]/40 bg-[#4CC9F0]/10 hover:bg-[#4CC9F0]/20 text-[#4CC9F0] text-xs font-bold transition-colors"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>SAVE</span>
                    </button>
                  )}

                  {slot && (
                    <button
                      onClick={() => loadFromSlot(slotId)}
                      className="flex items-center space-x-1 px-3 py-1.5 border border-[#00FF41]/40 bg-[#00FF41]/10 hover:bg-[#00FF41]/20 text-[#00FF41] text-xs font-bold transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>LOAD</span>
                    </button>
                  )}

                  {slot && !isAuto && (
                    <button
                      onClick={() => deleteSlot(slotId)}
                      className="p-1.5 border border-[#2D333D] hover:border-[#FF3B3B] bg-[#12141A] text-[#707880] hover:text-[#FF3B3B] transition-colors"
                      title="Delete Save Slot"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

