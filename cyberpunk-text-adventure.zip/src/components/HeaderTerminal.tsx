import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Save, BookOpen, RotateCcw, Sparkles, Shield, Cpu, Droplet } from 'lucide-react';
import { Layer } from '../types';
import { audioSynth } from '../utils/AudioSynth';

interface HeaderTerminalProps {
  layer: Layer;
  waterCapacity: number;
  characterName: string;
  act: number;
  isAudioMuted: boolean;
  onToggleAudio: () => void;
  isAiMode: boolean;
  onToggleAiMode: () => void;
  onOpenSaveModal: () => void;
  onOpenCodexModal: () => void;
  onOpenStatusModal: () => void;
  onRestart: () => void;
}

export const HeaderTerminal: React.FC<HeaderTerminalProps> = ({
  layer,
  waterCapacity,
  characterName,
  act,
  isAudioMuted,
  onToggleAudio,
  isAiMode,
  onToggleAiMode,
  onOpenSaveModal,
  onOpenCodexModal,
  onOpenStatusModal,
  onRestart,
}) => {
  const [systemTime, setSystemTime] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setSystemTime(now.toTimeString().split(' ')[0]);
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const getWaterColor = (cap: number) => {
    if (cap >= 60) return 'text-[#4CC9F0] border-[#4CC9F0]/40 bg-[#4CC9F0]/10';
    if (cap >= 35) return 'text-[#F27D26] border-[#F27D26]/40 bg-[#F27D26]/10';
    return 'text-[#FF3B3B] border-[#FF3B3B]/50 bg-[#FF3B3B]/10 animate-pulse';
  };

  return (
    <header id="header-terminal" className="w-full bg-[#0A0B0E] border-b border-[#2D333D] text-[#B0B8C1] font-mono select-none sticky top-0 z-30 shadow-md">
      {/* TOP STATUS RAIL FROM DESIGN SPEC */}
      <div className="px-4 py-2 bg-[#12141A] border-b border-[#2D333D] flex flex-wrap justify-between items-center text-[10px] tracking-[0.15em] uppercase gap-2">
        <div className="flex flex-wrap items-center gap-4 sm:gap-6">
          <div className="flex items-center gap-2 text-[#FF3B3B] font-bold">
            <span className="w-2 h-2 bg-[#FF3B3B] animate-pulse rounded-full"></span>
            <span>GRID STATUS: COMPROMISED [BLIGHT ACTIVITY DETECTED]</span>
          </div>
          <div className="text-[#707880] hidden md:inline">ENCLAVE WALLS: SEALED</div>
          <div className="text-[#707880] hidden lg:inline">OUTSIDE: NO SIGNAL</div>
        </div>

        <div className="flex items-center gap-4">
          <span className="text-[#4CC9F0]">{systemTime ? `SYSTEM TIME: ${systemTime}` : 'SYSTEM TIME: ONLINE'}</span>
          <span className="bg-[#4CC9F0] text-[#0A0B0E] px-2 py-0.5 font-bold rounded-sm">
            LAYER: {layer.toUpperCase()}
          </span>
        </div>
      </div>

      {/* MAIN TOOLBAR & CONTROLS */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        {/* Title & Citizen Info */}
        <div className="flex items-center space-x-3">
          <div className="h-8 w-8 bg-[#12141A] border border-[#4CC9F0] text-[#4CC9F0] font-bold flex items-center justify-center text-xs shadow-[0_0_8px_rgba(76,201,240,0.3)]">
            A{act}
          </div>
          <div>
            <div className="flex items-center space-x-2 text-[10px] uppercase tracking-wider text-[#707880]">
              <span>CYBERPUNK TEXT ADVENTURE</span>
              <span>•</span>
              <span className="text-[#F27D26] font-semibold">{characterName || 'UNREGISTERED CITIZEN'}</span>
            </div>
            <h1 className="text-sm font-bold text-slate-100 tracking-wider uppercase">
              THE UNSPOKEN GRID
            </h1>
          </div>
        </div>

        {/* Readouts & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Water Readout */}
          <button
            onClick={onOpenStatusModal}
            className={`flex items-center space-x-2 px-2.5 py-1 rounded-sm border text-xs font-mono transition-all ${getWaterColor(waterCapacity)}`}
            title="Clean-Water Capacity Level"
          >
            <Droplet className="w-3.5 h-3.5" />
            <span className="font-bold">WATER: {waterCapacity}%</span>
          </button>

          {/* AI Continuation Mode Toggle */}
          <button
            onClick={() => {
              audioSynth.playKeyClick();
              onToggleAiMode();
            }}
            title={isAiMode ? "AI Dynamic Mode Active (Gemini Narrative)" : "Classic Branching Narrative Mode"}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded-sm border text-[11px] font-mono transition-all ${
              isAiMode
                ? 'bg-purple-950/80 border-purple-400 text-purple-300 shadow-[0_0_8px_rgba(168,85,247,0.4)]'
                : 'bg-[#12141A] border-[#2D333D] text-[#707880] hover:text-slate-200'
            }`}
          >
            <Sparkles className={`w-3.5 h-3.5 ${isAiMode ? 'text-purple-400 animate-spin-slow' : ''}`} />
            <span>{isAiMode ? 'AI GEMINI' : 'CLASSIC'}</span>
          </button>

          {/* Audio Toggle */}
          <button
            onClick={onToggleAudio}
            title={isAudioMuted ? "Unmute Terminal Sound Effects" : "Mute Sound Effects"}
            className="p-1 rounded-sm border border-[#2D333D] bg-[#12141A] hover:bg-[#1A1D24] text-[#B0B8C1] transition-colors"
          >
            {isAudioMuted ? <VolumeX className="w-4 h-4 text-[#FF3B3B]" /> : <Volume2 className="w-4 h-4 text-[#4CC9F0]" />}
          </button>

          {/* Codex Button */}
          <button
            onClick={() => {
              audioSynth.playKeyClick();
              onOpenCodexModal();
            }}
            title="Open Canon World Codex"
            className="flex items-center space-x-1 px-2.5 py-1 rounded-sm border border-[#2D333D] bg-[#12141A] hover:bg-[#1A1D24] text-[#B0B8C1] text-[11px] font-mono transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5 text-[#F27D26]" />
            <span className="hidden sm:inline">CODEX</span>
          </button>

          {/* Status Modal */}
          <button
            onClick={() => {
              audioSynth.playKeyClick();
              onOpenStatusModal();
            }}
            title="View Faction Standings & Inventory"
            className="flex items-center space-x-1 px-2.5 py-1 rounded-sm border border-[#2D333D] bg-[#12141A] hover:bg-[#1A1D24] text-[#B0B8C1] text-[11px] font-mono transition-colors"
          >
            <Shield className="w-3.5 h-3.5 text-[#4CC9F0]" />
            <span className="hidden sm:inline">STATUS</span>
          </button>

          {/* Save / Load Modal */}
          <button
            onClick={() => {
              audioSynth.playKeyClick();
              onOpenSaveModal();
            }}
            title="Save or Load Game Session"
            className="flex items-center space-x-1 px-2.5 py-1 rounded-sm border border-[#4CC9F0]/40 bg-[#4CC9F0]/10 hover:bg-[#4CC9F0]/20 text-[#4CC9F0] text-[11px] font-mono transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">SAVES</span>
          </button>

          {/* Restart */}
          <button
            onClick={() => {
              audioSynth.playKeyClick();
              onRestart();
            }}
            title="Restart Session"
            className="p-1 rounded-sm border border-[#2D333D] bg-[#12141A] hover:bg-[#FF3B3B]/20 text-[#707880] hover:text-[#FF3B3B] transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

