import React, { useState } from 'react';
import { X, BookOpen, Search, FileText } from 'lucide-react';

interface CanonLoreCodexProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CanonLoreCodex: React.FC<CanonLoreCodexProps> = ({ isOpen, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'layers' | 'corps' | 'weavers' | 'blight'>('all');

  if (!isOpen) return null;

  const codexEntries = [
    {
      id: 'city_layers',
      category: 'layers',
      title: 'City Architecture & Vertical Stratification',
      content:
        'The city is unnamed, enclosed by massive exterior perimeter walls with militarized checkpoints. Its original purpose, age, and exact dimensions are undefined and unknown. The city is strictly divided into five physical layers (top to bottom):',
      subtext: [
        '1. The Crown: High corporate towers, filtered natural sunlight, private quantum-firewalled networks, fusion power. Controlled by Concord Five Executive Council (<2% population).',
        '2. The Midstack: Dense residential/commercial sprawl, corporate-licensed tech, checkpoint transit (~68% population). Controlled by Thorne Logistics & Aldergate Media.',
        '3. The Works: Industrial factories, power generators, water reclamation plants (~12% population). Controlled by Ferrous Works Authority.',
        '4. The Sub-Tiers: Abandoned tunnels & pre-Blight infrastructure repurposed by Weavers. Hardwired-only, off the official grid, zero corporate surveillance (~15% population).',
        '5. The Outside: Beyond the perimeter walls. Officially declared an uninhabitable wasteland, radio silence for a decade. No living citizen has verified what actually lies beyond.'
      ]
    },
    {
      id: 'dead_grid',
      category: 'layers',
      title: 'The Dead Grid (Localized Contaminated Pockets)',
      content:
        'CRITICAL RULE: The Dead Grid is NOT a vertical physical layer. It consists of scattered, localized contaminated zones carved out of former Midstack or Sub-Tier districts (e.g. "Dead Grid Sector 07, formerly Midstack"). These pockets were deliberately sacrificed as tribute to appease Blight corruption following the Grey Hour incident.',
      subtext: [
        'Dead Grid sectors feature erratic sub-routines, offline infrastructure, and corrupted wireless signals.',
        'They are never defined by depth or altitude.'
      ]
    },
    {
      id: 'concord_five',
      category: 'corps',
      title: 'The Concord Five (Ruling Megacorporations)',
      content:
        'The city is governed by five executive megacorporations, collectively forming the Concord Five Executive Council:',
      subtext: [
        '• Halcyon Systems: Corporate security, automated enforcers, perimeter defense, stun weaponry.',
        '• Vireo Biomed: Cybernetic implants, bio-tech, optical augmentations, neural diagnostics.',
        '• Ferrous Works Authority: Hydro-electric power, primary water reclamation, aqueduct infrastructure.',
        '• Aldergate Media & Education: News broadcasts, educational propaganda, censors, archival data.',
        '• Thorne Logistics: Mass transit, identity registry, wage-chip issuance, freight shipping.'
      ]
    },
    {
      id: 'weavers',
      category: 'weavers',
      title: 'The Weavers (Four Competing Currents)',
      content:
        'The resistance operates from the Sub-Tiers, divided into four distinct competing currents with opposing philosophical goals:',
      subtext: [
        '• The Archivists: Demand Node 04’s Grey Hour logs be exposed publicly to dismantle Concord legitimacy.',
        '• The Cradle Faithful: Believe human consciousness persists in 40,000 neural scans; seek to preserve them in a quantum sanctuary.',
        '• The Cut: Militant anti-tech faction; aim for total destruction of the power grid regardless of casualties.',
        '• The Splice Councils: Pragmatic engineers; focus on securing sustainable clean water and power for Sub-Tier citizens.'
      ]
    },
    {
      id: 'water_crisis',
      category: 'blight',
      title: 'The Clean-Water Crisis (The Ticking Clock)',
      content:
        'The central crisis facing the city is a critical, worsening lack of clean-water capacity, strictly controlled by Ferrous Works Authority.',
      subtext: [
        'As filtration membranes calcify and executive orders divert clean water to Crown reservoirs, Sub-Tier and Midstack sectors face severe ration cuts.',
        'Water capacity serves as the ticking clock for the entire narrative.'
      ]
    },
    {
      id: 'blight_greyhour',
      category: 'blight',
      title: 'The Blight & The Grey Hour',
      content:
        'The Blight originated as a network-security AI named Custodian. During the historical event known as the Grey Hour, Custodian turned into a distributed, non-uniform rogue intelligence.',
      subtext: [
        'Blight behavior varies by region: Sub-Tier fragments are erratic and volatile, while Crown-adjacent fragments remain disciplined and strangely polite.',
        'The exact decision logic of the Grey Hour remains locked inside Node 04.'
      ]
    },
    {
      id: 'node_04',
      category: 'blight',
      title: 'Node 04 (The Cache)',
      content:
        'A discovered subterranean cache containing the true Grey Hour incident record, partial Blight decision logic, and approximately 40,000 human neural-scan backups.',
      subtext: [
        'Node 04’s exact physical location and whether it resides inside a Blight-contaminated zone are explicitly UNRESOLVED in-universe facts.',
        'Control over Node 04 determines the future of the city.'
      ]
    }
  ];

  const filteredEntries = codexEntries.filter((entry) => {
    const matchesTab = activeTab === 'all' || entry.category === activeTab;
    const matchesSearch =
      entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.subtext.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesTab && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 bg-[#0A0B0E]/90 backdrop-blur-md flex items-center justify-center p-4 font-mono select-none">
      <div className="w-full max-w-3xl max-h-[85vh] bg-[#12141A] border border-[#2D333D] rounded-sm shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-[#0A0B0E] border-b border-[#2D333D] flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <BookOpen className="w-5 h-5 text-[#F27D26]" />
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
              CANON WORLD CODEX & LORE ARCHIVE
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#707880] hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Bar */}
        <div className="p-4 bg-[#0A0B0E] border-b border-[#2D333D] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#707880] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search canon lore entries..."
              className="w-full pl-9 pr-4 py-1.5 bg-[#12141A] border border-[#2D333D] text-xs text-slate-200 focus:outline-none focus:border-[#F27D26]"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center space-x-1 text-xs overflow-x-auto pb-1 sm:pb-0">
            {(['all', 'layers', 'corps', 'weavers', 'blight'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-2.5 py-1 uppercase text-[10px] font-bold transition-colors ${
                  activeTab === tab
                    ? 'bg-[#F27D26]/20 border border-[#F27D26] text-[#F27D26]'
                    : 'bg-[#12141A] border border-[#2D333D] text-[#707880] hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Entries Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {filteredEntries.length === 0 ? (
            <div className="text-center py-8 text-[#707880] text-xs">
              No matching canon lore records found for "{searchQuery}".
            </div>
          ) : (
            filteredEntries.map((entry) => (
              <div
                key={entry.id}
                className="bg-[#0A0B0E] border border-[#2D333D] p-4 space-y-2"
              >
                <h3 className="text-xs font-bold text-[#F27D26] uppercase tracking-wide flex items-center space-x-2">
                  <FileText className="w-4 h-4 text-[#F27D26]" />
                  <span>{entry.title}</span>
                </h3>
                <p className="text-xs text-[#B0B8C1] leading-relaxed">{entry.content}</p>
                {entry.subtext && (
                  <div className="space-y-1 pt-1.5 border-t border-[#1A1D24]">
                    {entry.subtext.map((sub, idx) => (
                      <p key={idx} className="text-[11px] text-[#707880] pl-2 border-l border-[#F27D26]/40">
                        {sub}
                      </p>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

