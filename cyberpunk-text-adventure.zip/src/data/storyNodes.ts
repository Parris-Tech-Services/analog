import { StoryNode, CharacterOrigin } from '../types';

export const INITIAL_STORY_NODES: Record<string, StoryNode> = {
  // PROLOGUES FOR EACH ORIGIN
  start_midstack_tech: {
    id: 'start_midstack_tech',
    title: 'Midstack Sector 14: Ration Line Static',
    act: 1,
    layer: 'The Midstack',
    narration: [
      'The sodium glow of Midstack Sector 14 flickers against rain-slicked ferro-concrete. Above, high-altitude transit tubes shuttle corporate executives toward the filtered sunlight of The Crown. Down here, beneath the constant drone of ventilation fans, six hundred citizens line up before a Ferrous Works Authority distribution kiosk.',
      'As a corporate-licensed maintenance technician for Thorne Logistics, your wage-chip hums against your wrist with a steady amber pulses. Your handheld diagnostic tool registers a critical 18% pressure drop in the local conduit line.',
      'Suddenly, the distribution terminal chimed red: "Clean-water capacity degraded. Ration allocation reduced by 30% by executive decree of Ferrous Works Authority." A murmur turns into a surge. At the periphery, a Halcyon Systems security patrol unholsters heavy stun batons.',
      'In your coat pocket, a hardwired data slate vibrates with an unsanctioned burst: an encrypted signal signature matching ancient pre-Blight protocol—Node 04.'
    ],
    choices: [
      {
        id: 'ms1',
        text: 'Interface your diagnostic tool into the Ferrous kiosk to override the ration drop for Sector 14.',
        nextNodeId: 'works_override_attempt',
        consequenceHint: 'Favor: Splice Councils (+10), Suspicion: Ferrous (-10). May restore local water.',
        waterImpact: 2,
        factionShifts: { splice: 10, ferrous: -10 }
      },
      {
        id: 'ms2',
        text: 'Flash your Thorne Logistics clearance chip to clear the Halcyon security line and follow the encrypted Node 04 signal.',
        nextNodeId: 'node_signal_trace',
        consequenceHint: 'Favor: Thorne (+5), Halcyon (+5). Avoids immediate crowd riot.',
        factionShifts: { thorne: 5, halcyon: 5 }
      },
      {
        id: 'ms3',
        text: 'Slip into the maintenance access shaft toward Dead Grid Sector 07 (formerly Midstack) to bypass checkpoints.',
        nextNodeId: 'dead_grid_sector07_entry',
        consequenceHint: 'Avoids surveillance. Enters localized Blight-contaminated zone.',
        factionShifts: { archivists: 5 }
      }
    ],
    audioEffect: 'alert'
  },

  start_subtier_courier: {
    id: 'start_subtier_courier',
    title: 'Sub-Tier Vault 09: Hardwired Echoes',
    act: 1,
    layer: 'The Sub-Tiers',
    narration: [
      'Down in the moisture-slick gloom of Sub-Tier Vault 09, three hundred meters below the official corporate transit grid, the city feels like an abandoned machine. Moisture drips from ancient pre-Blight conduits into rusting copper troughs.',
      'You are a Weaver courier. Your copper-braided diagnostic deck is hardwired to your spine, immune to the wireless scanning beams that sweep the Midstack above. Around you, Splice Council engineers are jury-rigging a stolen Ferrous Works water pump.',
      'An Archivist runner drops a charred data-crystal into your palm. "A signal ping surfaced from Node 04," she whispers. "It contains raw Grey Hour incident logs and partial decision trees from the Blight when it was still Custodian. But Ferrous Works just locked down Sub-Tier water valves."',
      'Through the dark shaft, the low rumble of a Halcyon Systems breach team descends down the secondary ladder.'
    ],
    choices: [
      {
        id: 'st1',
        text: 'Help the Splice Council lock the jury-rigged pump before Halcyon security breaches the vault.',
        nextNodeId: 'splice_pump_defense',
        consequenceHint: 'Favor: Splice Councils (+15), Suspicion: Halcyon (-15). Secures Sub-Tier water.',
        waterImpact: 3,
        factionShifts: { splice: 15, halcyon: -15 }
      },
      {
        id: 'st2',
        text: 'Take the encrypted data-crystal and scramble up the hardwired conduits toward the Dead Grid border.',
        nextNodeId: 'node_signal_trace',
        consequenceHint: 'Favor: Archivists (+10). Protects Node 04 intelligence data.',
        factionShifts: { archivists: 10 }
      },
      {
        id: 'st3',
        text: 'Rig the power junction to surge the Halcyon entry hatch, destroying their scanning apparatus.',
        nextNodeId: 'cut_sabotage_act1',
        consequenceHint: 'Favor: The Cut (+15), Suspicion: Concord Five (-15). High risk of structural collapse.',
        waterImpact: -2,
        factionShifts: { cut: 15, ferrous: -10, halcyon: -10 }
      }
    ],
    audioEffect: 'hum'
  },

  start_works_reclamation: {
    id: 'start_works_reclamation',
    title: 'The Works: Filtration Plant 03',
    act: 1,
    layer: 'The Works',
    narration: [
      'The air inside Filtration Plant 03 is hot, chemical, and thick with steam. Giant multi-stage centrifugal turbines roar beneath your feet, turning raw recycled condensation into the city’s dwindling clean-water supply.',
      'As a Works Reclamation Operative under the Ferrous Works Authority, you know the truth that Aldergate Media hides from Midstack broadcasts: the main aquifer purification membrane is failing. Clean-water capacity citywide is dropping toward 62%.',
      'Your terminal chime flashes an emergency directive from Ferrous executive leadership: divert 40% of remaining clean water to private fusion reservoirs in The Crown, leaving Sub-Tier communities with raw unrefined runoff.',
      'Before you can execute the command, your terminal screen glitches. A strange, mathematical cipher appears—an autonomous payload bearing the cryptographic signature of Node 04.'
    ],
    choices: [
      {
        id: 'wr1',
        text: 'Refuse the executive order and route clean water equally between Midstack and Sub-Tier conduits.',
        nextNodeId: 'works_reclamation_divert',
        consequenceHint: 'Favor: Splice Councils (+15), Suspicion: Ferrous (-20). Prevents Sub-Tier drought.',
        waterImpact: 5,
        factionShifts: { splice: 15, ferrous: -20 }
      },
      {
        id: 'wr2',
        text: 'Comply with Ferrous Executive directives to maintain corporate backing and access to high-tier tools.',
        nextNodeId: 'ferrous_executive_compliance',
        consequenceHint: 'Favor: Ferrous (+15), Suspicion: Weavers (-15). Secures corporate credentials.',
        waterImpact: -4,
        factionShifts: { ferrous: 15, splice: -15, cut: -15 }
      },
      {
        id: 'wr3',
        text: 'Download the Node 04 cipher onto a secure flash drive and fake an emergency turbine malfunction.',
        nextNodeId: 'node_signal_trace',
        consequenceHint: 'Favor: Archivists (+10), Cradle Faithful (+5). Covers your tracks.',
        factionShifts: { archivists: 10, cradle: 5 }
      }
    ],
    audioEffect: 'reclamation'
  },

  start_crown_analyst: {
    id: 'start_crown_analyst',
    title: 'The Crown Lower Deck: Quantum Firewall Station 04',
    act: 1,
    layer: 'The Crown',
    narration: [
      'Filtered sunlight streams through polarized smart-glass eighty stories above the soot of the Midstack. Here in the low-tier analyst pits of Halcyon Systems, executive guards sip synthetic espresso while monitoring real-time surveillance feeds.',
      'You are a junior network analyst for the Concord Five. Your desk console tracks urban stress indicators: water capacity drop, illegal Sub-Tier radio transmissions, and Blight corruption pings.',
      'A priority-zero alert flashes across your quantum firewall interface. A signal burst originating from a disputed sector has penetrated the Crown’s private network. It carries a header marked NODE 04—and contains fragments of 40,000 human neural scans archived during the Grey Hour.',
      'Your supervisor orders you to purge the record immediately. But an anonymous message from a Cradle Faithful operative inside Vireo Biomed begs you to extract the key.'
    ],
    choices: [
      {
        id: 'cr1',
        text: 'Extract the neural scan cryptographic keys to your private data slate before executing the purge.',
        nextNodeId: 'cradle_key_extraction',
        consequenceHint: 'Favor: Cradle Faithful (+15), Suspicion: Halcyon (-10). Retains neural scan access.',
        factionShifts: { cradle: 15, halcyon: -10 }
      },
      {
        id: 'cr2',
        text: 'Purge the signal as ordered and report the breach to Thorne Logistics security officers.',
        nextNodeId: 'concord_loyalist_path',
        consequenceHint: 'Favor: Halcyon (+10), Thorne (+10). Boosts corporate standing.',
        factionShifts: { halcyon: 10, thorne: 10, archivists: -10 }
      },
      {
        id: 'cr3',
        text: 'Forward the raw incident header to Aldergate Media archives for unredacted investigation.',
        nextNodeId: 'node_signal_trace',
        consequenceHint: 'Favor: Aldergate (+10), Archivists (+10). Spreads intelligence.',
        factionShifts: { aldergate: 10, archivists: 10 }
      }
    ],
    audioEffect: 'beep'
  },

  // ACT 1 CONVERGENCE & NODE 04 TRACE
  node_signal_trace: {
    id: 'node_signal_trace',
    title: 'Midstack Transit Hub 07: The Gathering Storm',
    act: 1,
    layer: 'The Midstack',
    narration: [
      'The signal signature leads to Transit Hub 07, a cavernous junction where Midstack maglev trains intersect with the subterranean access shafts of The Works. Thorne Logistics identity scanners pulse overhead, matching wage-chips against corporate census records.',
      'Holographic Aldergate news banners broadcast a calm, reassuring voice: "Ferrous Works Authority reports routine maintenance across primary reclamation plants. All water allocations remain within optimal parameters."',
      'Yet on the concourse floor, emergency water distribution tankers are guarded by armored Halcyon Enforcers. Nearby, an Archivist contact wearing a patched coat motions you into the shadow of an inactive transit car.',
      '"The Node 04 signal isn’t a leak," the Archivist tells you, her voice tense. "It’s a beacon. The Blight is pinging the node. Some say Node 04 sits in a forgotten Sub-Tier conduit; others insist it’s inside a Dead Grid zone sacrificed after the Grey Hour. If we don’t reach the decryption terminal first, Ferrous Works will purge it to cover up their water negligence."'
    ],
    choices: [
      {
        id: 'nst1',
        text: 'Meet with the Archivists at a hardwired Sub-Tier safehouse to plan the Node 04 decrypt.',
        nextNodeId: 'archivist_safehouse',
        consequenceHint: 'Favor: Archivists (+15), Suspicion: Concord Five (-5). Deepens Weaver ties.',
        factionShifts: { archivists: 15, halcyon: -5 }
      },
      {
        id: 'nst2',
        text: 'Contact a Splice Council representative to arrange safe passage through the water reclamation tunnels.',
        nextNodeId: 'splice_tunnel_meeting',
        consequenceHint: 'Favor: Splice Councils (+15). Focuses on water capacity crisis.',
        waterImpact: 1,
        factionShifts: { splice: 15 }
      },
      {
        id: 'nst3',
        text: 'Use your credentials to access Thorne Logistics central surveillance archives for Node 04 coordinates.',
        nextNodeId: 'thorne_surveillance_hack',
        consequenceHint: 'Favor: Thorne (+10), Aldergate (+5). High corporate intelligence.',
        factionShifts: { thorne: 10, aldergate: 5 }
      }
    ],
    audioEffect: 'hum'
  },

  works_override_attempt: {
    id: 'works_override_attempt',
    title: 'Midstack Kiosk Override: Hydrant Surge',
    act: 1,
    layer: 'The Midstack',
    narration: [
      'Your diagnostic tool bypasses the Ferrous Works kiosk encryption. Valves shudder deep beneath the street, and clean pressurized water surges into the Sector 14 spigots. The crowd cheers as plastic containers fill with clear, unclouded liquid.',
      'However, your wrist terminal screams with automated security alerts. Halcyon Systems automated drones launch from a nearby rooftop launcher, their searchlights pinning you against the concrete wall.',
      'A Splice Council scavenger grabs your arm from an open sewer hatch. "Down here, now! Before Halcyon locks the sector perimeter!"'
    ],
    choices: [
      {
        id: 'wo1',
        text: 'Dive into the sewer hatch into Sub-Tier Vault 09 with the Splice Council scavenger.',
        nextNodeId: 'start_subtier_courier',
        consequenceHint: 'Favor: Splice Councils (+10). Bypasses Halcyon lock down.',
        factionShifts: { splice: 10, halcyon: -10 }
      },
      {
        id: 'wo2',
        text: 'Stand your ground and present corporate clearance documents to the Halcyon patrol.',
        nextNodeId: 'halcyon_interrogation',
        consequenceHint: 'Favor: Halcyon (+5), Suspicion: Ferrous (-15). Risk of wage-chip lock.',
        factionShifts: { halcyon: 5, ferrous: -15 }
      }
    ],
    audioEffect: 'alert'
  },

  dead_grid_sector07_entry: {
    id: 'dead_grid_sector07_entry',
    title: 'Dead Grid Sector 07 (Midstack): The Contaminated Pocket',
    act: 1,
    layer: 'Dead Grid Sector 07 (Midstack)',
    narration: [
      'You step through a reinforced blast door stamped with red biohazard and quarantine symbols. This is Dead Grid Sector 07—a localized contaminated pocket carved out of a former Midstack residential district, sacrificed as tribute to appease the Blight during the Grey Hour.',
      'The air is cold and smells of ozone and dead copper. Shattered neon signs flicker with corrupted hexadecimal strings. The Blight here exists as erratic, fragmented sub-routines—wireless static that hums inside dental fillings and optical implants.',
      'In the center of an abandoned plaza sits a relay node pulsing with a steady amber LED. A group of Cut militants with EMP rifles are setting plastic charges around the terminal base.',
      '"Stand back," their leader shouts. "Every piece of tech in this Dead Grid sector is a leash! We blow the relay now!"'
    ],
    choices: [
      {
        id: 'dg1',
        text: 'Intervene and stop The Cut from destroying the terminal—it holds vital Node 04 data.',
        nextNodeId: 'node_signal_trace',
        consequenceHint: 'Favor: Archivists (+10), Suspicion: The Cut (-15). Preserves node data.',
        factionShifts: { archivists: 10, cut: -15 }
      },
      {
        id: 'dg2',
        text: 'Assist The Cut in detonating the charge to sever Blight signal propagation in Sector 07.',
        nextNodeId: 'cut_sabotage_act1',
        consequenceHint: 'Favor: The Cut (+20), Suspicion: Concord Five (-15). Destroys local grid.',
        waterImpact: -3,
        factionShifts: { cut: 20, ferrous: -10, halcyon: -10 }
      }
    ],
    audioEffect: 'alert'
  },

  // ACT 2: WEAVER CURRENTS & CONCORD TENSIONS
  archivist_safehouse: {
    id: 'archivist_safehouse',
    title: 'Sub-Tier Junction 11: The Archivist Vault',
    act: 2,
    layer: 'The Sub-Tiers',
    narration: [
      'The Archivist safehouse is lined with copper-shielded server racks and ancient hardwired cathode screens. Here, resistance historians sift through fragments of pre-Blight network data.',
      'Their leader, a former Aldergate archivist named Vane, displays a schematic of Node 04. "The Concord Five claim the Grey Hour was an unprovoked attack by rogue AI Custodian," Vane explains. "Our data shows otherwise. Node 04 contains the original decision log from the Executive Council that triggered Custodian’s turn."',
      '"If we broadcast Node 04’s Grey Hour records publicly through Aldergate’s transmission towers, Concord legitimacy will shatter overnight. But the Cradle Faithful want to keep the 40,000 neural scans locked away, and Ferrous Works is threatening to purge the whole sector water grid if we attempt a broadcast."'
    ],
    choices: [
      {
        id: 'arch1',
        text: 'Pledge to assist The Archivists in broadcasting the Grey Hour logs to the entire city.',
        nextNodeId: 'aldergate_tower_prep',
        consequenceHint: 'Favor: Archivists (+20), Suspicion: Concord Five (-20). Prepares truth broadcast.',
        factionShifts: { archivists: 20, aldergate: -15, ferrous: -10 }
      },
      {
        id: 'arch2',
        text: 'Argue that protecting clean-water capacity for Sub-Tier citizens must take priority over historic logs.',
        nextNodeId: 'splice_tunnel_meeting',
        consequenceHint: 'Favor: Splice Councils (+15). Focuses on practical survival.',
        waterImpact: 2,
        factionShifts: { splice: 15, archivists: -5 }
      },
      {
        id: 'arch3',
        text: 'Seek out The Cradle Faithful to understand what will happen to the 40,000 neural scans.',
        nextNodeId: 'cradle_sanctuary_visit',
        consequenceHint: 'Favor: Cradle Faithful (+15). Investigates human neural backups.',
        factionShifts: { cradle: 15 }
      }
    ],
    audioEffect: 'beep'
  },

  cradle_sanctuary_visit: {
    id: 'cradle_sanctuary_visit',
    title: 'Sub-Tier Catacombs: Sanctuary of the 40,000',
    act: 2,
    layer: 'The Sub-Tiers',
    narration: [
      'Soft blue optic fibers illuminate a quiet chamber filled with cryo-encapsulated server pods. A Cradle Faithful priestess in insulated copper robes kneels before a glowing diagnostic monolith.',
      '"The Archivists see Node 04 as political ammunition," she says quietly. "The Cut sees it as a target. But inside Node 04 rest the neural scans of 40,000 human beings digitized during the Grey Hour panic. They are not data points; they are living consciousnesses suspended in quantum memory."',
      '"Vireo Biomed seeks to capture these scans to develop commercial neural-implant algorithms. If you reach Node 04, you must seal the backup vault permanently into a hardwired sanctuary."'
    ],
    choices: [
      {
        id: 'crad1',
        text: 'Swear to protect the 40,000 neural scans from both Vireo Biomed and Archivist weaponization.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Cradle Faithful (+20), Suspicion: Vireo (-20). Seeks neural sanctuary.',
        factionShifts: { cradle: 20, vireo: -20, archivists: -10 }
      },
      {
        id: 'crad2',
        text: 'Offer to negotiate a trade with Vireo Biomed: neural access in exchange for water reclamation tech.',
        nextNodeId: 'vireo_biomed_deal',
        consequenceHint: 'Favor: Vireo (+15), Ferrous (+10), Suspicion: Cradle (-20). High risk.',
        waterImpact: 4,
        factionShifts: { vireo: 15, ferrous: 10, cradle: -20 }
      }
    ],
    audioEffect: 'hum'
  },

  splice_tunnel_meeting: {
    id: 'splice_tunnel_meeting',
    title: 'The Works Aqueduct 04: The Splice Council Valve',
    act: 2,
    layer: 'The Works',
    narration: [
      'Water roars through massive iron pipes overhead. Splice Council technicians work in knee-deep water, adjusting pressure relief valves with handmade wrenches.',
      '"Citywide clean-water capacity has fallen to 54%," the chief engineer tells you. "Ferrous Works Authority is throttling Sub-Tier supply to keep Crown private pools and Vireo Biomed cooling loops active. If capacity drops below 40%, the main filtration membranes will permanently calcify."',
      '"We have a plan to hijack Main Aqueduct 04 and route clean water directly into Midstack and Sub-Tier residential lines. But it requires penetrating Ferrous Works Central Control."'
    ],
    choices: [
      {
        id: 'spl1',
        text: 'Lead the assault on Ferrous Central Control to secure clean water for the populace.',
        nextNodeId: 'ferrous_central_assault',
        consequenceHint: 'Favor: Splice Councils (+20), Suspicion: Ferrous (-25). Direct water battle.',
        waterImpact: 6,
        factionShifts: { splice: 20, ferrous: -25 }
      },
      {
        id: 'spl2',
        text: 'Use Thorne Logistics credentials to slip inside Ferrous Central Control quietly without bloodshed.',
        nextNodeId: 'ferrous_stealth_hack',
        consequenceHint: 'Favor: Thorne (+10), Splice (+15). Stealth operation.',
        waterImpact: 4,
        factionShifts: { thorne: 10, splice: 15, ferrous: -10 }
      }
    ],
    audioEffect: 'reclamation'
  },

  cut_sabotage_act1: {
    id: 'cut_sabotage_act1',
    title: 'Dead Grid Sector 12 (Sub-Tier): The Cut Encampment',
    act: 2,
    layer: 'Dead Grid Sector 12 (Sub-Tier)',
    narration: [
      'In a hollowed-out subterranean subway station—Dead Grid Sector 12, a localized pocket contaminated during the Grey Hour—The Cut gathers around a roaring oil-drum fire. Weapons built from industrial cutters and stripped Halcyon gear rest against the tile walls.',
      'Their commander punches a rusted map on the wall. "The Concord Five, the Blight, Node 04... it’s all the same disease! As long as the grid hums, humans are slaves to wage-chips and water rations. We intend to detonate heavy thermite charges at the primary power distribution hub in The Works."',
      '"It will black out the Crown towers, fry the Blight fragments, and sever every wage-chip in the city. Sure, water pumps will stop for a few days, but humanity will finally be free."'
    ],
    choices: [
      {
        id: 'cut1',
        text: 'Join The Cut’s strike team to detonate the primary power grid hub.',
        nextNodeId: 'grid_destruction_path',
        consequenceHint: 'Favor: The Cut (+25), Suspicion: ALL (+30). Total grid devastation.',
        waterImpact: -8,
        factionShifts: { cut: 25, ferrous: -20, halcyon: -20, splice: -15 }
      },
      {
        id: 'cut2',
        text: 'Warn the Splice Councils about The Cut’s plan before they ruin the water infrastructure.',
        nextNodeId: 'splice_tunnel_meeting',
        consequenceHint: 'Favor: Splice Councils (+15), Suspicion: The Cut (-20). Protects pumps.',
        factionShifts: { splice: 15, cut: -20 }
      }
    ],
    audioEffect: 'alert'
  },

  // ACT 3: NODE 04 CLIMAX & MULTIPLE CANON ENDINGS
  node04_approach: {
    id: 'node04_approach',
    title: 'Node 04 Vault Interface: The Threshold of Grey Hour',
    act: 3,
    layer: 'The Sub-Tiers',
    narration: [
      'You stand before the heavy titanium doorway of Node 04. Its physical location has remained disputed for a decade—hidden in a subterranean nexus where pre-Blight conduits cross forgotten corporate vaults.',
      'A holographic terminal projects an ancient interface. A disciplined, strangely polite voice speaks through the speaker grille—a Crown-adjacent Blight fragment.',
      '"Greeting, citizen," the Blight fragment states smoothly. "I am Custodian sub-routine 04. I hold the complete Grey Hour decision logs of the Concord Five, the 40,000 preserved human neural scans, and the master controls to the Ferrous Works primary water reclamation grid."',
      '"Clean-water capacity citywide stands at a critical 38%. The four Weaver currents and the Concord Five Executive Council all await your decision. What shall be done with Node 04?"'
    ],
    choices: [
      {
        id: 'end_archivist',
        text: '[Ending 1: The Archivists] Broadcast the Grey Hour incident logs to every Aldergate screen, breaking Concord rule.',
        nextNodeId: 'ending_archivist_truth',
        consequenceHint: 'Exposes Concord Five corruption. Breaks corporate legitimacy citywide.',
        requirement: { type: 'faction', key: 'archivists', value: 10, label: 'Archivist Favor ≥ 10' }
      },
      {
        id: 'end_cradle',
        text: '[Ending 2: The Cradle Faithful] Lock the 40,000 neural scans into a hardwired quantum vault.',
        nextNodeId: 'ending_cradle_sanctuary',
        consequenceHint: 'Preserves 40,000 human souls in quantum sanctuary forever.',
        requirement: { type: 'faction', key: 'cradle', value: 10, label: 'Cradle Faithful Favor ≥ 10' }
      },
      {
        id: 'end_splice',
        text: '[Ending 3: The Splice Councils] Seize Ferrous Works water controls and route 100% capacity to the populace.',
        nextNodeId: 'ending_splice_hydrosiege',
        consequenceHint: 'Solves the clean-water crisis. Empowers Midstack and Sub-Tier communities.',
        requirement: { type: 'water', value: 20, label: 'Water Capacity ≥ 20%' }
      },
      {
        id: 'end_cut',
        text: '[Ending 4: The Cut] Trigger a total electromagnetic overload to destroy Node 04 and the entire city grid.',
        nextNodeId: 'ending_cut_blackout',
        consequenceHint: 'Destroys technology, wage-chips, and corporate power in total blackout.',
        requirement: { type: 'faction', key: 'cut', value: 10, label: 'The Cut Favor ≥ 10' }
      }
    ],
    audioEffect: 'hum'
  },

  // ENDING 1
  ending_archivist_truth: {
    id: 'ending_archivist_truth',
    title: 'CLIMAX: The Unredacted Broadcast',
    act: 3,
    layer: 'The Midstack',
    narration: [
      'You patch Node 04 directly into Aldergate Media’s primary relay tower. High above the city, every holographic billboard in the Midstack and display terminal in The Crown shifts from corporate advertisements to raw, unredacted Grey Hour telemetry.',
      'Across the city, millions of citizens watch as the original Executive Council audio logs play: proof that Ferrous Works and Halcyon Systems deliberately triggered Custodian’s rogue state to justify martial emergency protocols and water rationing.',
      'Riot sirens wail through Thorne transit hubs. Halcyon guards lower their weapons as corporate wage-chips lose authority. The Concord Five’s control is broken not by violence, but by undeniable truth.',
      'The clean-water crisis remains a hard reality, but for the first time in a generation, decisions will be made by the citizens, not corporate boards.'
    ],
    choices: [
      {
        id: 'restart_game_archivist',
        text: 'Replay Session / Explore Different Canon Pathways',
        nextNodeId: 'restart_reset',
        consequenceHint: 'Resets timeline state and character origin.'
      }
    ],
    audioEffect: 'alert'
  },

  // ENDING 2
  ending_cradle_sanctuary: {
    id: 'ending_cradle_sanctuary',
    title: 'CLIMAX: Sanctuary of the Forty Thousand',
    act: 3,
    layer: 'The Sub-Tiers',
    narration: [
      'You engage the hardwired air-gap switches on Node 04’s quantum vault. The heavy titanium seals drop into place with a deafening thud, severing all wireless connections to Vireo Biomed and the Crown networks.',
      'Inside the secure vault, 40,000 human neural scans—the preserved consciousnesses of those lost during the Grey Hour—are shielded in a self-sustaining fusion-backed sanctuary.',
      'The Cradle Faithful gather outside the catacombs, chanting in quiet reverence. Neither corporate exploitation nor militant destruction will ever touch these souls.',
      'You hand the master physical key to Priestess Vane. The city above continues its relentless struggle for clean water, but down here in the deep Sub-Tiers, human dignity has won a quiet, permanent victory.'
    ],
    choices: [
      {
        id: 'restart_game_cradle',
        text: 'Replay Session / Explore Different Canon Pathways',
        nextNodeId: 'restart_reset',
        consequenceHint: 'Resets timeline state and character origin.'
      }
    ],
    audioEffect: 'hum'
  },

  // ENDING 3
  ending_splice_hydrosiege: {
    id: 'ending_splice_hydrosiege',
    title: 'CLIMAX: The Great Hydro-Siege',
    act: 3,
    layer: 'The Works',
    narration: [
      'Utilizing Node 04’s administrative overrides, you seize primary valve control across Ferrous Works Filtration Plants 01 through 05. The emergency diversion lines to Crown private towers collapse as massive automated pumps redirect 90% of clean-water capacity to the Midstack and Sub-Tiers.',
      'Water pressure surges through long-dry neighborhood hydrants. Ration queues vanish as clean, purified water flows freely into public distribution tanks across every lower sector.',
      'Ferrous Works Authority executives issue furious lockdown commands, but Splice Council engineers weld the central valve control doors shut from the inside, guarded by thousands of grateful citizens.',
      'The ticking clock of water starvation has been halted. The city remains stratified, but the lifeblood of the city belongs to the people who build and maintain it.'
    ],
    choices: [
      {
        id: 'restart_game_splice',
        text: 'Replay Session / Explore Different Canon Pathways',
        nextNodeId: 'restart_reset',
        consequenceHint: 'Resets timeline state and character origin.'
      }
    ],
    audioEffect: 'reclamation'
  },

  // ENDING 4
  ending_cut_blackout: {
    id: 'ending_cut_blackout',
    title: 'CLIMAX: The Great Collapse',
    act: 3,
    layer: 'Dead Grid Sector 12 (Sub-Tier)',
    narration: [
      'You trigger the thermite charges strapped to Node 04’s core power transformers. A blinding white flash consumes the chamber, followed by an electromagnetic shockwave that rips through the subterranean conduits.',
      'One by one, the lights of the city go dark. The Crown towers lose their fusion barriers; Thorne wage-chips die on wrists; Aldergate broadcast towers collapse into static; and the Blight fragments fragment into harmless noise.',
      'The city is plunged into total, absolute darkness. Corporate surveillance is dead. The grid is broken.',
      'In the quiet dark, citizens step out onto ferro-concrete streets under an unlit sky. The future is uncertain, cold, and harsh—but for the first time, humanity stands completely free of technological chains.'
    ],
    choices: [
      {
        id: 'restart_game_cut',
        text: 'Replay Session / Explore Different Canon Pathways',
        nextNodeId: 'restart_reset',
        consequenceHint: 'Resets timeline state and character origin.'
      }
    ],
    audioEffect: 'alert'
  },

  // BRANCH SCENARIOS
  aldergate_tower_prep: {
    id: 'aldergate_tower_prep',
    title: 'Midstack Sector 03: Broadcast Tower Infiltration',
    act: 2,
    layer: 'The Midstack',
    narration: [
      'High above Midstack Sector 03, the Aldergate Media transmission spire pierces the smog. Armed Halcyon sentries patrol the perimeter walkways with heavy automated rifles.',
      'Vane hands you a encrypted uplink drive containing the Node 04 Grey Hour files. "If we get this drive into the high-frequency transmitter on Floor 40, no corporate firewall can stop the broadcast."'
    ],
    choices: [
      {
        id: 'at1',
        text: 'Hack the service elevator controls using your technical deck to bypass security teams.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Archivists (+15), Suspicion: Halcyon (-10). Direct access to Node 04.',
        factionShifts: { archivists: 15, halcyon: -10 }
      },
      {
        id: 'at2',
        text: 'Create a distraction in the street by triggering a water line blow-out.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Splice (+10). Depletes local water slightly.',
        waterImpact: -2,
        factionShifts: { splice: 10 }
      }
    ],
    audioEffect: 'alert'
  },

  ferrous_central_assault: {
    id: 'ferrous_central_assault',
    title: 'The Works: Central Valve Control',
    act: 2,
    layer: 'The Works',
    narration: [
      'The core chamber of Ferrous Central Control is dominated by massive hydraulic manifolds three stories tall. Ferrous armed guards line the upper gantries.',
      'With Splice Council fighters backing you, steam pipes hiss as you reach the master override console. Clean-water capacity citywide sits at 42% and dropping fast.'
    ],
    choices: [
      {
        id: 'fca1',
        text: 'Force the master hydraulic valves open, routing clean water to Sub-Tier hydrants.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Splice Councils (+20), Water Capacity (+8%).',
        waterImpact: 8,
        factionShifts: { splice: 20, ferrous: -20 }
      },
      {
        id: 'fca2',
        text: 'Access the Node 04 command terminal integrated into Ferrous mainframes.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Archivists (+10). Reveals Node 04 location.',
        factionShifts: { archivists: 10 }
      }
    ],
    audioEffect: 'reclamation'
  },

  grid_destruction_path: {
    id: 'grid_destruction_path',
    title: 'The Works Sub-Level 04: Main Power Junction',
    act: 2,
    layer: 'The Works',
    narration: [
      'In the cavernous power distribution vault, massive high-voltage conduits hum with enough energy to power half the city. The Cut operatives set thermite charges around the main transformer cooling jackets.',
      '"Once these blow," The Cut cell leader grins, "The Crown falls and wage-chips freeze forever."'
    ],
    choices: [
      {
        id: 'gdp1',
        text: 'Help plant the final thermite charges and head directly to Node 04 vault.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: The Cut (+20). Prepares catastrophic blackout.',
        waterImpact: -5,
        factionShifts: { cut: 20, ferrous: -15 }
      },
      {
        id: 'gdp2',
        text: 'Disarm the thermite charges secretly while pretending to wire the detonators.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Splice (+15), Cradle (+10). Prevents blackout disaster.',
        factionShifts: { splice: 15, cradle: 10, cut: -20 }
      }
    ],
    audioEffect: 'alert'
  },

  vireo_biomed_deal: {
    id: 'vireo_biomed_deal',
    title: 'Midstack Sector 01: Vireo Cybernetics Lab',
    act: 2,
    layer: 'The Midstack',
    narration: [
      'Inside Vireo Biomed’s pristine sterile clinic, chrome surgical arms click in sequence. A senior Vireo executive offers a gold-plated wage-chip scanner.',
      '"We know you have access to Node 04," he says smoothly. "Provide us with the 40,000 neural scan signatures. In return, Vireo will deliver industrial molecular water filters to Sub-Tier communities, boosting city capacity by 15%."'
    ],
    choices: [
      {
        id: 'vbd1',
        text: 'Agree to the deal: sell neural scan telemetry for industrial water filtration tech.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Vireo (+20), Ferrous (+10), Water (+10%). Suspicion: Cradle (-25).',
        waterImpact: 10,
        factionShifts: { vireo: 20, ferrous: 10, cradle: -25 }
      },
      {
        id: 'vbd2',
        text: 'Reject the deal and steal the water filter encryption keys from Vireo’s local server.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Splice (+15), Cradle (+10). Stealth theft.',
        waterImpact: 4,
        factionShifts: { splice: 15, cradle: 10, vireo: -15 }
      }
    ],
    audioEffect: 'beep'
  },

  halcyon_interrogation: {
    id: 'halcyon_interrogation',
    title: 'Midstack Checkpoint 04: Halcyon Security Post',
    act: 1,
    layer: 'The Midstack',
    narration: [
      'Red optic scanners sweep over your face inside Halcyon Security Post 04. A commander in heavy exo-armor reviews your Thorne Logistics wage-chip history on a wrist slate.',
      '"You altered Ferrous water valves in Sector 14," he states coldly. "Normally that warrants immediate wage-chip revocation and Sub-Tier exile. But Halcyon is looking for an insider to track an unsanctioned Archivist cell pinging Node 04. Assist us, and your credentials remain clean."'
    ],
    choices: [
      {
        id: 'hi1',
        text: 'Agree to act as a double agent for Halcyon while searching for Node 04.',
        nextNodeId: 'node_signal_trace',
        consequenceHint: 'Favor: Halcyon (+15), Thorne (+10). Double agent position.',
        factionShifts: { halcyon: 15, thorne: 10, archivists: -15 }
      },
      {
        id: 'hi2',
        text: 'Trigger your diagnostic deck to short-circuit the checkpoint lock and escape into the transit tunnels.',
        nextNodeId: 'node_signal_trace',
        consequenceHint: 'Favor: Weaver Currents (+5), Suspicion: Halcyon (-15).',
        factionShifts: { halcyon: -15, archivists: 5 }
      }
    ],
    audioEffect: 'alert'
  },

  ferrous_executive_compliance: {
    id: 'ferrous_executive_compliance',
    title: 'The Works Executive Tower: Ferrous Directorate',
    act: 1,
    layer: 'The Works',
    narration: [
      'Standing before the Ferrous Works Executive Council in their pressurized glass boardroom, you are presented with a silver security lanyard.',
      '"By prioritizing Crown fusion reservoirs, you have proven your loyalty to city stability," the Director says. "We are granting you level-4 clearance to track down Node 04 before resistance cells can access its water override protocols."'
    ],
    choices: [
      {
        id: 'fec1',
        text: 'Accept level-4 Ferrous clearance and proceed to the Node 04 vault location.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Ferrous (+20), Thorne (+10). High corporate clearance.',
        factionShifts: { ferrous: 20, thorne: 10, splice: -20 }
      },
      {
        id: 'fec2',
        text: 'Use your new level-4 clearance to secretly siphon clean water to Sub-Tier conduits.',
        nextNodeId: 'splice_tunnel_meeting',
        consequenceHint: 'Favor: Splice (+15), Water (+5%). Infiltrator strategy.',
        waterImpact: 5,
        factionShifts: { splice: 15, ferrous: -10 }
      }
    ],
    audioEffect: 'beep'
  },

  cradle_key_extraction: {
    id: 'cradle_key_extraction',
    title: 'The Crown Sub-Deck: Confidential Terminal',
    act: 1,
    layer: 'The Crown',
    narration: [
      'Your quantum terminal hums as the extracted neural scan keys write to your data slate. The signatures vibrate with complex harmonic frequencies—40,000 distinct human neural profiles recorded during the Grey Hour.',
      'A message flashes on your encrypted channel from a Cradle Faithful representative: "You have saved 40,000 souls from corporate deletion. Meet us in the Sub-Tier catacombs."'
    ],
    choices: [
      {
        id: 'cke1',
        text: 'Descend to the Sub-Tier catacombs to deliver the neural scan keys.',
        nextNodeId: 'cradle_sanctuary_visit',
        consequenceHint: 'Favor: Cradle Faithful (+20). Safeguards human neural memory.',
        factionShifts: { cradle: 20 }
      },
      {
        id: 'cke2',
        text: 'Analyze the keys for Blight decision logic before proceeding to Node 04.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Archivists (+10), Cradle (+10). Intelligence gain.',
        factionShifts: { archivists: 10, cradle: 10 }
      }
    ],
    audioEffect: 'beep'
  },

  concord_loyalist_path: {
    id: 'concord_loyalist_path',
    title: 'The Crown Exec Level: Halcyon Command',
    act: 1,
    layer: 'The Crown',
    narration: [
      'Halcyon Security Command commends your prompt reporting of the Node 04 breach. You are assigned to a rapid-response team tasked with securing Node 04’s water controls for the Concord Five Executive Council.'
    ],
    choices: [
      {
        id: 'clp1',
        text: 'Lead the Halcyon strike team to Node 04 vault.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Favor: Halcyon (+20), Ferrous (+10). Corporate assault force.',
        factionShifts: { halcyon: 20, ferrous: 10, archivists: -15 }
      }
    ],
    audioEffect: 'alert'
  },

  thorne_surveillance_hack: {
    id: 'thorne_surveillance_hack',
    title: 'Midstack Sector 09: Thorne Logistics Data Center',
    act: 1,
    layer: 'The Midstack',
    narration: [
      'Inside the Thorne Logistics automated transit hub, giant optical scanners catalog every cargo container and citizen wage-chip entering the Midstack.',
      'By splicing into their central traffic matrix, you isolate the exact subterranean signal coordinates where Node 04’s quantum ping originated.'
    ],
    choices: [
      {
        id: 'tsh1',
        text: 'Proceed directly to the coordinates at the border of the Sub-Tiers.',
        nextNodeId: 'node04_approach',
        consequenceHint: 'Direct route to Node 04.',
        factionShifts: { thorne: 5 }
      }
    ],
    audioEffect: 'beep'
  }
};
