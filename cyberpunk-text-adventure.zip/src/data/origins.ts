import { CharacterOrigin, CharacterState, FactionStanding } from '../types';

export interface OriginDefinition {
  origin: CharacterOrigin;
  name: string;
  title: string;
  startNodeId: string;
  startLayer: string;
  perk: string;
  description: string;
  startingStandings: FactionStanding;
  startingInventory: Array<{
    id: string;
    name: string;
    description: string;
    icon: string;
    tag: string;
  }>;
}

export const CHARACTER_ORIGINS: OriginDefinition[] = [
  {
    origin: 'midstack_tech',
    name: 'Midstack Licensed Tech',
    title: 'Thorne Logistics Maintenance Specialist',
    startNodeId: 'start_midstack_tech',
    startLayer: 'The Midstack',
    perk: 'Corporate License: Bypasses basic Thorne transit checkpoints; diagnostic tool restores minor water pressure.',
    description: 'You live among the 68% in the dense Midstack sprawl. You hold a corporate license for tech maintenance, giving you access to commercial conduits and wage-chip readers.',
    startingStandings: {
      ferrous: 5,
      halcyon: 5,
      vireo: 0,
      aldergate: 5,
      thorne: 15,
      archivists: 0,
      cradle: 0,
      cut: -5,
      splice: 5
    },
    startingInventory: [
      {
        id: 'thorne_wage_chip',
        name: 'Thorne License Wage-Chip',
        description: 'Standard corporate wrist implant verifying Midstack residency and tech credentials.',
        icon: 'CreditCard',
        tag: 'Identity'
      },
      {
        id: 'diagnostic_deck',
        name: 'Multi-Conduit Diagnostic Deck',
        description: 'Handheld diagnostic tool for probing electrical junctions and water conduits.',
        icon: 'Wrench',
        tag: 'Tool'
      }
    ]
  },
  {
    origin: 'subtier_courier',
    name: 'Sub-Tier Weaver Courier',
    title: 'Hardwired Information Runner',
    startNodeId: 'start_subtier_courier',
    startLayer: 'The Sub-Tiers',
    perk: 'Off-Grid Stealth: Immune to standard wireless surveillance sweeps; starts with Weaver trust.',
    description: 'Raised in the subterranean tunnels of the Sub-Tiers. You carry hardwired data-crystals through forgotten pre-Blight shafts outside corporate monitoring.',
    startingStandings: {
      ferrous: -15,
      halcyon: -15,
      vireo: -10,
      aldergate: -10,
      thorne: -15,
      archivists: 15,
      cradle: 10,
      cut: 10,
      splice: 20
    },
    startingInventory: [
      {
        id: 'spinal_hardwire_deck',
        name: 'Braided Copper Neural Deck',
        description: 'Hardwired deck connected to your spine. Cannot be scanned wirelessly by Halcyon towers.',
        icon: 'Cpu',
        tag: 'Hardware'
      },
      {
        id: 'subtier_valve_wrench',
        name: 'Splice Valve Key',
        description: 'Heavy steel key for manually overriding Sub-Tier water reclamation hydrants.',
        icon: 'Key',
        tag: 'Tool'
      }
    ]
  },
  {
    origin: 'works_reclamation',
    name: 'Works Reclamation Tech',
    title: 'Ferrous Works Authority Specialist',
    startNodeId: 'start_works_reclamation',
    startLayer: 'The Works',
    perk: 'Hydro-Engine Insights: Deep understanding of filtration plants; gains extra water capacity from overrides.',
    description: 'Stationed in the hot, steam-filled industrial expanse of The Works (~12% pop). You oversee primary water filtration turbines and know exactly how scarce clean water really is.',
    startingStandings: {
      ferrous: 20,
      halcyon: 5,
      vireo: 5,
      aldergate: 0,
      thorne: 5,
      archivists: -5,
      cradle: 0,
      cut: -15,
      splice: 10
    },
    startingInventory: [
      {
        id: 'ferrous_clearance_lanyard',
        name: 'Ferrous Level-3 Lanyard',
        description: 'Security keycard granting access to Filtration Plants 01-05 and turbine halls.',
        icon: 'Shield',
        tag: 'Clearance'
      },
      {
        id: 'water_salinity_gauge',
        name: 'High-Precision Salinity Tester',
        description: 'Measures heavy metal contamination and Blight particulate levels in clean-water lines.',
        icon: 'Droplet',
        tag: 'Sensor'
      }
    ]
  },
  {
    origin: 'crown_analyst',
    name: 'Crown Low-Tier Analyst',
    title: 'Halcyon Systems Junior Security Analyst',
    startNodeId: 'start_crown_analyst',
    startLayer: 'The Crown',
    perk: 'Quantum Firewall Access: Can decrypt corporate security headers; high initial corporate standing.',
    description: 'Working eighty stories above the soot in lower Crown offices (<2% pop). You analyze quantum firewall breaches and urban stress metrics for the Concord Five.',
    startingStandings: {
      ferrous: 10,
      halcyon: 20,
      vireo: 10,
      aldergate: 15,
      thorne: 15,
      archivists: -10,
      cradle: -5,
      cut: -20,
      splice: -10
    },
    startingInventory: [
      {
        id: 'halcyon_quantum_slate',
        name: 'Halcyon Encryption Slate',
        description: 'Encrypted tablet with private quantum firewall credentials for lower Crown sectors.',
        icon: 'Smartphone',
        tag: 'Quantum'
      },
      {
        id: 'grey_hour_header_fragment',
        name: 'Node 04 Decryption Header',
        description: 'Intercepted fragment of pre-Blight signal header containing Node 04 cryptographic signatures.',
        icon: 'FileCode',
        tag: 'Data'
      }
    ]
  }
];
