/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameState, StoryNode, Choice, CharacterState, Layer, LogEntry } from './types';
import { INITIAL_STORY_NODES } from './data/storyNodes';
import { HeaderTerminal } from './components/HeaderTerminal';
import { StatusPanel } from './components/StatusPanel';
import { CanonLoreCodex } from './components/CanonLoreCodex';
import { SaveLoadModal } from './components/SaveLoadModal';
import { CharacterCreation } from './components/CharacterCreation';
import { StoryNarrator } from './components/StoryNarrator';
import { audioSynth } from './utils/AudioSynth';

const AUTO_SAVE_KEY = 'cyberpunk_text_adventure_autosave_v1';

export default function App() {
  const [gameState, setGameState] = useState<GameState>({
    character: null,
    currentLayer: 'The Midstack',
    waterCapacity: 75,
    standings: {
      ferrous: 0,
      halcyon: 0,
      vireo: 0,
      aldergate: 0,
      thorne: 0,
      archivists: 0,
      cradle: 0,
      cut: 0,
      splice: 0,
    },
    currentNodeId: 'start_midstack_tech',
    historyNodeIds: [],
    logs: [],
    act: 1,
    isAiMode: false,
    endingReached: null,
  });

  const [storyNodes, setStoryNodes] = useState<Record<string, StoryNode>>(INITIAL_STORY_NODES);
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Modal States
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const [isCodexOpen, setIsCodexOpen] = useState(false);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);

  // Restore auto-save on initial mount if present
  useEffect(() => {
    try {
      const saved = localStorage.getItem(AUTO_SAVE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.character) {
          setGameState(parsed);
        }
      }
    } catch (e) {
      console.warn('Could not restore auto-save session', e);
    }
  }, []);

  // Auto-save whenever game state changes
  useEffect(() => {
    if (gameState.character) {
      try {
        localStorage.setItem(AUTO_SAVE_KEY, JSON.stringify(gameState));
      } catch (e) {}
    }
  }, [gameState]);

  // Handle Character Creation Start
  const handleStartGame = (character: CharacterState, startLayer: Layer, startNodeId: string) => {
    const initialNode = storyNodes[startNodeId] || INITIAL_STORY_NODES.start_midstack_tech;

    // Set origin standings
    const newStandings = {
      ferrous: 0,
      halcyon: 0,
      vireo: 0,
      aldergate: 0,
      thorne: 0,
      archivists: 0,
      cradle: 0,
      cut: 0,
      splice: 0,
    };

    const newLogs: LogEntry[] = [
      {
        id: `log_${Date.now()}`,
        timestamp: new Date().toLocaleTimeString(),
        type: 'narrative',
        title: 'IDENTITY INITIALIZED',
        text: `Citizen Dossier established: ${character.name} (${character.title}) starting at ${startLayer}.`,
      },
    ];

    setGameState({
      character,
      currentLayer: startLayer,
      waterCapacity: 75,
      standings: newStandings,
      currentNodeId: startNodeId,
      historyNodeIds: [startNodeId],
      logs: newLogs,
      act: 1,
      isAiMode: false,
      endingReached: null,
    });
  };

  // Handle Player Choice Selection
  const handleChoiceSelect = (choice: Choice) => {
    if (!gameState.character) return;

    // Apply sound effect
    if (choice.nextNodeId && storyNodes[choice.nextNodeId]?.audioEffect === 'alert') {
      audioSynth.playAlert();
    } else if (choice.nextNodeId && storyNodes[choice.nextNodeId]?.audioEffect === 'reclamation') {
      audioSynth.playReclamationHum();
    } else {
      audioSynth.playChoiceBeep();
    }

    // 1. Water Capacity Impact
    let newWater = gameState.waterCapacity;
    if (choice.waterImpact) {
      newWater = Math.max(0, Math.min(100, newWater + choice.waterImpact));
    }

    // 2. Faction Shift Calculations
    const newStandings = { ...gameState.standings };
    if (choice.factionShifts) {
      Object.entries(choice.factionShifts).forEach(([key, val]) => {
        if (val !== undefined && key in newStandings) {
          (newStandings as any)[key] += val;
        }
      });
    }

    // 3. Inventory Item Add
    const updatedInventory = [...gameState.character.inventory];
    if (choice.addItem && !updatedInventory.some((i) => i.id === choice.addItem!.id)) {
      updatedInventory.push(choice.addItem);
    }

    const updatedCharacter = {
      ...gameState.character,
      inventory: updatedInventory,
    };

    // 4. Next Node Resolution
    const nextNodeId = choice.nextNodeId || gameState.currentNodeId;
    const nextNode = storyNodes[nextNodeId];

    // Check ending
    let endingReached = gameState.endingReached;
    if (nextNodeId.startsWith('ending_')) {
      endingReached = nextNodeId;
    }

    // 5. Append Log History
    const newLog: LogEntry = {
      id: `log_${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      type: 'narrative',
      title: nextNode ? nextNode.title : 'ACTION EXECUTED',
      text: `Decision taken: "${choice.text}". Water Capacity ${
        choice.waterImpact ? (choice.waterImpact > 0 ? `+${choice.waterImpact}%` : `${choice.waterImpact}%`) : 'unchanged'
      }.`,
    };

    // Reset action if choice is restart
    if (nextNodeId === 'restart_reset') {
      handleRestart();
      return;
    }

    setGameState({
      ...gameState,
      character: updatedCharacter,
      waterCapacity: newWater,
      standings: newStandings,
      currentLayer: nextNode ? nextNode.layer : gameState.currentLayer,
      currentNodeId: nextNodeId,
      historyNodeIds: [...gameState.historyNodeIds, nextNodeId],
      logs: [newLog, ...gameState.logs],
      act: nextNode ? nextNode.act : gameState.act,
      endingReached,
    });
  };

  // Handle Dynamic Gemini AI Narrative Generation
  const handleDynamicAiChoice = async (customPrompt: string) => {
    if (!gameState.character) return;
    setIsAiLoading(true);

    try {
      const currentScene = storyNodes[gameState.currentNodeId] || INITIAL_STORY_NODES.start_midstack_tech;

      const res = await fetch('/api/generate-narrative', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentScene,
          choiceText: customPrompt,
          playerState: gameState,
        }),
      });

      const data = await res.json();
      if (data.success && data.scene) {
        const generatedId = `ai_node_${Date.now()}`;
        const newScene: StoryNode = {
          id: generatedId,
          title: data.scene.title || 'Dynamic Canon Echo',
          act: gameState.act,
          layer: (data.scene.layer as Layer) || gameState.currentLayer,
          narration: Array.isArray(data.scene.narration) ? data.scene.narration : [data.scene.narration],
          choices: (data.scene.choices || []).map((c: any, i: number) => ({
            id: `ai_c_${i}_${Date.now()}`,
            text: c.text,
            nextNodeId: 'node04_approach', // converges smoothly to canon climax
            consequenceHint: c.consequenceHint || 'Proceeds through narrative',
          })),
        };

        // Update story nodes map
        setStoryNodes((prev) => ({ ...prev, [generatedId]: newScene }));

        // Apply changes
        handleChoiceSelect({
          id: `custom_${Date.now()}`,
          text: customPrompt,
          nextNodeId: generatedId,
          consequenceHint: 'Dynamic Action Executed',
          waterImpact: data.scene.waterImpact || 0,
          factionShifts: data.scene.factionShifts || {},
        });
      }
    } catch (err) {
      console.error('Failed to generate AI narrative choice', err);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleRestart = () => {
    localStorage.removeItem(AUTO_SAVE_KEY);
    setGameState({
      character: null,
      currentLayer: 'The Midstack',
      waterCapacity: 75,
      standings: {
        ferrous: 0,
        halcyon: 0,
        vireo: 0,
        aldergate: 0,
        thorne: 0,
        archivists: 0,
        cradle: 0,
        cut: 0,
        splice: 0,
      },
      currentNodeId: 'start_midstack_tech',
      historyNodeIds: [],
      logs: [],
      act: 1,
      isAiMode: false,
      endingReached: null,
    });
  };

  const currentNode = storyNodes[gameState.currentNodeId] || INITIAL_STORY_NODES.start_midstack_tech;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-cyan-900 selection:text-cyan-200 flex flex-col relative overflow-x-hidden">
      {/* Background Subtle CRT Grid Overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#06b6d4_1px,transparent_1px)] [background-size:24px_24px] z-0" />

      {/* Header Bar */}
      <HeaderTerminal
        layer={gameState.currentLayer}
        waterCapacity={gameState.waterCapacity}
        characterName={gameState.character?.name || ''}
        act={gameState.act}
        isAudioMuted={isAudioMuted}
        onToggleAudio={() => {
          const muted = audioSynth.toggleMute();
          setIsAudioMuted(muted);
        }}
        isAiMode={gameState.isAiMode}
        onToggleAiMode={() => setGameState({ ...gameState, isAiMode: !gameState.isAiMode })}
        onOpenSaveModal={() => setIsSaveModalOpen(true)}
        onOpenCodexModal={() => setIsCodexOpen(true)}
        onOpenStatusModal={() => setIsStatusOpen(true)}
        onRestart={handleRestart}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-[1400px] w-full mx-auto px-3 sm:px-6 py-4 z-10">
        {!gameState.character ? (
          <CharacterCreation onStartGame={handleStartGame} />
        ) : (
          <StoryNarrator
            currentNode={currentNode}
            waterCapacity={gameState.waterCapacity}
            standings={gameState.standings}
            character={gameState.character}
            onSelectChoice={handleChoiceSelect}
            logs={gameState.logs}
            isAiLoading={isAiLoading}
            isAiMode={gameState.isAiMode}
            onDynamicAiChoice={handleDynamicAiChoice}
            onOpenCodex={() => setIsCodexOpen(true)}
            onOpenSave={() => setIsSaveModalOpen(true)}
            onRestart={handleRestart}
          />
        )}
      </main>

      {/* Modals */}
      <StatusPanel
        isOpen={isStatusOpen}
        onClose={() => setIsStatusOpen(false)}
        character={gameState.character}
        currentLayer={gameState.currentLayer}
        waterCapacity={gameState.waterCapacity}
        standings={gameState.standings}
      />

      <CanonLoreCodex isOpen={isCodexOpen} onClose={() => setIsCodexOpen(false)} />

      <SaveLoadModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        currentState={gameState}
        onLoadState={(loaded) => setGameState(loaded)}
      />
    </div>
  );
}
