export type Layer =
  | 'The Crown'
  | 'The Midstack'
  | 'The Works'
  | 'The Sub-Tiers'
  | 'The Outside'
  | 'Dead Grid Sector 07 (Midstack)'
  | 'Dead Grid Sector 12 (Sub-Tier)';

export type ConcordCorp =
  | 'Halcyon Systems'
  | 'Vireo Biomed'
  | 'Ferrous Works Authority'
  | 'Aldergate Media & Education'
  | 'Thorne Logistics';

export type WeaverCurrent =
  | 'The Archivists'
  | 'The Cradle Faithful'
  | 'The Cut'
  | 'The Splice Councils';

export interface FactionStanding {
  // Concord Five
  ferrous: number; // Ferrous Works Authority (power/water)
  halcyon: number; // Halcyon Systems (security)
  vireo: number; // Vireo Biomed (implants)
  aldergate: number; // Aldergate Media & Education (propaganda)
  thorne: number; // Thorne Logistics (transit/identity)
  // Weaver Currents
  archivists: number; // The Archivists (Node 04 Grey Hour logs)
  cradle: number; // The Cradle Faithful (40,000 neural scans)
  cut: number; // The Cut (militant anti-tech)
  splice: number; // The Splice Councils (sub-tier water/power pragmatists)
}

export type CharacterOrigin =
  | 'midstack_tech'
  | 'subtier_courier'
  | 'works_reclamation'
  | 'crown_analyst';

export interface InventoryItem {
  id: string;
  name: string;
  description: string;
  icon: string; // Lucide icon name
  tag: string;
}

export interface CharacterState {
  name: string;
  origin: CharacterOrigin;
  title: string;
  perk: string;
  description: string;
  inventory: InventoryItem[];
}

export interface ChoiceRequirement {
  type: 'water' | 'faction' | 'item' | 'origin';
  key?: string; // e.g. 'ferrous', 'midstack_tech', 'node_decryption_key'
  value?: number | string;
  label: string;
}

export interface Choice {
  id: string;
  text: string;
  nextNodeId?: string;
  consequenceHint: string;
  requirement?: ChoiceRequirement;
  waterImpact?: number; // e.g. -5 for -5% clean water capacity
  factionShifts?: Partial<FactionStanding>;
  addItem?: InventoryItem;
  removeItem?: string;
  dynamicAiTrigger?: boolean;
}

export interface StoryNode {
  id: string;
  title: string;
  act: number;
  layer: Layer;
  narration: string[];
  choices: Choice[];
  isCheckpoint?: boolean;
  audioEffect?: 'alert' | 'beep' | 'hum' | 'reclamation';
}

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'narrative' | 'system' | 'water' | 'faction' | 'audio';
  title: string;
  text: string;
}

export interface SaveSlot {
  slotId: string;
  timestamp: string;
  characterName: string;
  act: number;
  nodeTitle: string;
  waterCapacity: number;
  state: GameState;
}

export interface GameState {
  character: CharacterState | null;
  currentLayer: Layer;
  waterCapacity: number; // 0% to 100%
  standings: FactionStanding;
  currentNodeId: string;
  historyNodeIds: string[];
  logs: LogEntry[];
  act: number;
  isAiMode: boolean;
  endingReached?: string | null;
}
